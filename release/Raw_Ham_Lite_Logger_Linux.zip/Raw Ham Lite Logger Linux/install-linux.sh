#!/usr/bin/env bash
# The Raw Ham's Lite Logger - Linux installer
# Run from the folder you unzipped:   bash install-linux.sh
# Safe to run again to update - your log and settings are kept.
set -u

APPDIR="$HOME/.local/share/rawham-lite-logger"
BINDIR="$HOME/.local/bin"
DESKDIR="$HOME/.local/share/applications"
SRC="$(cd "$(dirname "$0")" && pwd)"
YES=0
[ "${1:-}" = "-y" ] && YES=1

say() { printf '\n\033[1;32m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m  ! %s\033[0m\n' "$*"; }
ask() { # ask "question" -> 0 for yes
    [ $YES = 1 ] && return 0
    read -r -p "  $1 [Y/n] " a
    case "$a" in [nN]*) return 1 ;; *) return 0 ;; esac
}
SUDO=""
[ "$(id -u)" != 0 ] && command -v sudo >/dev/null && SUDO="sudo"

# which package manager?
PM=""
for p in apt-get dnf pacman zypper; do command -v $p >/dev/null && { PM=$p; break; }; done
install_pkg() { # install_pkg apt-name dnf-name pacman-name zypper-name
    case "$PM" in
        apt-get) $SUDO apt-get install -y "$1" || { $SUDO apt-get update && $SUDO apt-get install -y "$1"; } ;;
        dnf) $SUDO dnf install -y "$2" ;;
        pacman) $SUDO pacman -S --needed --noconfirm "$3" ;;
        zypper) $SUDO zypper --non-interactive install "$4" ;;
        *) return 1 ;;
    esac
}

if [ ! -f "$SRC/rawhams_lite_logger.py" ]; then
    echo "Can't find rawhams_lite_logger.py next to this script. Run it from the unzipped folder."
    exit 1
fi

say "Checking Python"
if ! command -v python3 >/dev/null; then
    warn "Python 3 is missing."
    ask "Install it now?" && install_pkg python3 python3 python python3
fi
command -v python3 >/dev/null || { echo "Python 3 is needed. Install it and run this again."; exit 1; }
python3 - <<'EOF' || { echo "Python 3.8 or newer is needed."; exit 1; }
import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)
EOF
echo "  $(python3 --version)"

say "Checking the window toolkit (tkinter)"
if ! python3 -c "import tkinter" 2>/dev/null; then
    warn "tkinter is missing - the logger needs it to show its window."
    ask "Install it now?" && install_pkg python3-tk python3-tkinter tk python3-tk
fi
python3 -c "import tkinter" 2>/dev/null && echo "  ok" || { echo "tkinter is still missing. Install your distro's python3-tk package."; exit 1; }

say "Checking radio control (pyserial)"
if ! python3 -c "import serial" 2>/dev/null; then
    warn "pyserial is missing - needed for USB radio control (Flrig/rigctld work without it)."
    if ask "Install it now?"; then
        install_pkg python3-serial python3-pyserial python-pyserial python3-pyserial \
            || python3 -m pip install --user --break-system-packages pyserial \
            || python3 -m pip install --user pyserial
    fi
fi
python3 -c "import serial" 2>/dev/null && echo "  ok" || warn "Skipped - the logger still works, just without USB radio control."

say "Checking the picture library (Pillow - for the Share map picture)"
if ! python3 -c "import PIL" 2>/dev/null; then
    warn "Pillow is missing - only needed for the Share button's map picture."
    if ask "Install it now?"; then
        install_pkg python3-pil python3-pillow python-pillow python3-Pillow \
            || python3 -m pip install --user --break-system-packages pillow \
            || python3 -m pip install --user pillow
    fi
fi
python3 -c "import PIL" 2>/dev/null && echo "  ok" || warn "Skipped - everything works, Share just copies the text."

say "Checking the password keyring (secret-tool)"
if ! command -v secret-tool >/dev/null; then
    warn "secret-tool is missing - with it, your QRZ password is kept in the desktop keyring."
    if ask "Install it now?"; then
        install_pkg libsecret-tools libsecret libsecret libsecret-tools || true
    fi
fi
command -v secret-tool >/dev/null && echo "  ok" || warn "Skipped - passwords are kept in a file only your user can read."

say "Installing the program to $APPDIR"
mkdir -p "$APPDIR" "$BINDIR" "$DESKDIR"
for f in rawhams_lite_logger.py logo.png logo.ico basemap.txt countries.txt ctyprefix.txt Raw_Hams_Lite_Logger_Manual.pdf; do
    [ -f "$SRC/$f" ] && cp -f "$SRC/$f" "$APPDIR/"
done
chmod 700 "$APPDIR"

cat > "$BINDIR/rawham-logger" <<EOF
#!/bin/sh
exec python3 "$APPDIR/rawhams_lite_logger.py" "\$@"
EOF
chmod +x "$BINDIR/rawham-logger"

cat > "$DESKDIR/rawham-lite-logger.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=The Raw Ham's Lite Logger
Comment=POTA, WWFF, SOTA, GMA, WWBOTA and LLOTA logger and self-spotter
Exec=$BINDIR/rawham-logger
Icon=$APPDIR/logo.png
Terminal=false
Categories=HamRadio;Network;Utility;
StartupWMClass=Tk
EOF
chmod +x "$DESKDIR/rawham-lite-logger.desktop"
command -v update-desktop-database >/dev/null && update-desktop-database "$DESKDIR" 2>/dev/null

DESKTOP="$(command -v xdg-user-dir >/dev/null && xdg-user-dir DESKTOP || echo "$HOME/Desktop")"
if [ -d "$DESKTOP" ]; then
    cp -f "$DESKDIR/rawham-lite-logger.desktop" "$DESKTOP/"
    chmod +x "$DESKTOP/rawham-lite-logger.desktop"
    command -v gio >/dev/null && gio set "$DESKTOP/rawham-lite-logger.desktop" metadata::trusted true 2>/dev/null
    echo "  Desktop icon added."
fi
echo "  Menu entry added (look for The Raw Ham's Lite Logger)."

say "Checking access to USB radios"
GRP=dialout
getent group dialout >/dev/null || GRP=uucp   # Arch uses uucp
if getent group $GRP >/dev/null && ! id -nG "$USER" | grep -qw $GRP; then
    warn "Your user isn't in the '$GRP' group, so USB radio ports won't open."
    if ask "Add $USER to $GRP now? (needs your password, then log out and back in)"; then
        $SUDO usermod -aG $GRP "$USER" && echo "  Added. Log out and back in before connecting the radio."
    fi
else
    echo "  ok"
fi

say "Done!"
echo "  Start it from your app menu, the desktop icon, or by typing:  rawham-logger"
case ":$PATH:" in *":$BINDIR:"*) ;; *) echo "  (If 'rawham-logger' isn't found, log out and back in so ~/.local/bin is on your PATH.)" ;; esac
echo "  Your log and settings live in $APPDIR and are kept when you update."

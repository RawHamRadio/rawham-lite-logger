#!/usr/bin/env python3
"""
The Raw Ham's Lite Logger - a small field logger and self-spotter for the "On The Air" programs.

  Programs:  POTA, WWFF, SOTA, GMA, WWBOTA, LLOTA (n-fers across programs work)
  Spotting:  POTA and WWBOTA post directly, GMA and WWFF go through their
             cluster servers, SOTA and LLOTA open their spot page in your
             browser with the spot text already on the clipboard.
  Radio:     Yaesu (FT-710, FT-991A, FT-891, FTDX10/101 and FT-817/818/857/897),
             Icom CI-V (IC-705, IC-7300, IC-7100, IC-7610, IC-9700), Xiegu G90/X6100/X5105,
             and any radio through Flrig or Hamlib rigctld - the app follows the radio's
             frequency and mode, and can set them.
  Logging:   Enter key logs, QSO counter, dupe warning, auto-saves every QSO.
  Export:    One ADIF per reference, with the right fields for each program.

Runs on Windows and Linux. Needs Python 3 with tkinter.
  Windows: python.org installer, then   py -m pip install pyserial
  Linux:   bash install-linux.sh   (installs python3-tk and python3-serial, adds a menu icon)
"""

import math
import json
import os
import queue
import re
import socket
import sqlite3
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
import xml.etree.ElementTree as ET
import xmlrpc.client
from datetime import datetime, timedelta, timezone

import tkinter as tk
import tkinter.font
from tkinter import filedialog, messagebox, ttk

try:
    import serial
    import serial.tools.list_ports
    HAVE_SERIAL = True
except ImportError:  # CAT is optional
    HAVE_SERIAL = False

APP = "The Raw Ham's Lite Logger"
IS_WIN = os.name == "nt"
IS_LINUX = sys.platform.startswith("linux")
UI_FONT = "Segoe UI" if IS_WIN else "DejaVu Sans"
PYSERIAL_CMD = "py -m pip install pyserial" if IS_WIN else "sudo apt install python3-serial   (or: pip install pyserial)"
ACCESS_CMD = ("py -m pip install access-parser" if IS_WIN
              else "pip install --user --break-system-packages access-parser")
PORT_WORD = "COM port" if IS_WIN else "serial port (/dev/ttyUSB0, /dev/ttyACM0 ...)"
VERSION = "1.36"
# Public download page - the update check reads version.json from it
UPDATE_URL = "https://raw.githubusercontent.com/RawHamRadio/rawham-lite-logger/main/version.json"
DOWNLOAD_PAGE = "https://github.com/RawHamRadio/rawham-lite-logger/releases/latest"
SETUP_URL = DOWNLOAD_PAGE + "/download/Raw_Ham_Lite_Logger_Setup.exe"
HERE = os.path.dirname(os.path.abspath(__file__))
FROZEN = bool(getattr(sys, "frozen", False))  # running as the installed Windows program (Setup.exe)
RES_DIR = getattr(sys, "_MEIPASS", HERE)  # where logo.ico / logo.png are


def _data_dir():
    """Your log and settings. Next to the .py file when run from Python (as before); in your own user
    folder when installed with Setup.exe, so updates and uninstalls never touch them."""
    if not FROZEN:
        return HERE
    base = (os.environ.get("LOCALAPPDATA") if os.name == "nt" else None) or os.path.join(
        os.path.expanduser("~"), ".local", "share")
    d = os.path.join(base, "Raw Ham Lite Logger")
    os.makedirs(d, exist_ok=True)
    # moving from the .py version: bring the old log and settings along the first time
    exe_dir = os.path.dirname(sys.executable)
    for name in ("rawhams_lite_data.json", "rawhams_lite.db"):
        old, new = os.path.join(exe_dir, name), os.path.join(d, name)
        if os.path.exists(old) and not os.path.exists(new):
            try:
                import shutil
                shutil.copy2(old, new)
            except OSError:
                pass
    return d


DATA_DIR = _data_dir()
DATA_FILE = os.path.join(DATA_DIR, "rawhams_lite_data.json")
DB_FILE = os.path.join(DATA_DIR, "rawhams_lite.db")
CALLBOOK_MAX_AGE_DAYS = 180

ABOUT_TEXT = """{app}
Version {version}

Written for and by Richie, KJ5GVQ - The Raw Ham.
A light field logger and self-spotter for POTA, SOTA, WWFF, GMA,
WWBOTA and LLOTA, at the park or at home.

Thank you to our beta testers for their time and ideas.

The Raw Ham art is by my daughter, Abigail Ryan (@pip_and_blob).

It's free and always will be. If it made your activation easier and
you want to buy me a coffee, it helps cover the tools I use to keep
it going.

Free data and services it uses - thank you:
  - Map outlines: Natural Earth (public domain)
  - Country prefixes: cty data by Jim Reisert AD1C
  - Spots: POTA, SOTA, WWFF and DX Summit public feeds
  - Callbook: FCC ULS and ISED Canada amateur lists
  - Lookups and logbook: QRZ.com (your own subscription)
  - Works alongside WSJT-X through its published UDP messages
"""
DONATE_URL = "https://www.paypal.me/TheRawHam"
MIN_SPOT_GAP_SEC = 60
DEFAULT_CLUSTER = "dxc.ve7cc.net:23"
CLUSTER_GAP_SEC = 15 * 60  # DX cluster self-spots: rarely, or not at all

# Digital voice modes: ADIF logs them as MODE DIGITALVOICE with the submode (DMR, DSTAR ...).
DIGITAL_VOICE = ("DMR", "DSTAR", "C4FM", "FREEDV", "M17")
MODES = ["SSB", "CW", "FT8", "FT4", "FM", "AM", "RTTY", "PSK31", *DIGITAL_VOICE]

BANDS = [
    (1800, 2000, "160m"), (3500, 4000, "80m"), (5330, 5410, "60m"),
    (7000, 7300, "40m"), (10100, 10150, "30m"), (14000, 14350, "20m"),
    (18068, 18168, "17m"), (21000, 21450, "15m"), (24890, 24990, "12m"),
    (28000, 29700, "10m"), (50000, 54000, "6m"), (144000, 148000, "2m"),
    (420000, 450000, "70cm"),
]

PROGRAMS = ["POTA", "WWFF", "SOTA", "GMA", "WWBOTA", "LLOTA"]
# QSOs needed for a valid activation (shown on the counter)
GOALS = {"POTA": 10, "WWFF": 44, "SOTA": 4}
MANUAL_SPOT_PAGES = {
    "SOTA": "https://sotawatch.sota.org.uk/en/",
    "LLOTA": "https://llota.app/",
    "WWFF": "https://spots.wwff.co/",
}

CALL_RE = re.compile(r"^([A-Z0-9]{1,4}/)?[A-Z0-9]{1,3}[0-9][A-Z0-9]{0,4}(/[A-Z0-9]{1,4})?$")


# ================================================================ helpers

def utc_now():
    return datetime.now(timezone.utc)


def band_for(khz):
    for lo, hi, name in BANDS:
        if lo <= khz <= hi:
            return name
    return ""


def parse_freq_khz(text):
    """14331, 14331.5 (kHz) or 14.331 (MHz) -> float kHz, else None."""
    text = str(text).strip().replace(",", ".")
    if not text:
        return None
    try:
        val = float(text)
    except ValueError:
        return None
    if val < 1000:
        val *= 1000
    return round(val, 2)


def fmt_khz(khz):
    return f"{khz:.2f}".rstrip("0").rstrip(".")


def default_rst(mode):
    if mode in ("CW", "RTTY", "PSK31"):
        return "599"
    if mode in ("FT8", "FT4"):
        return "-10"
    return "59"


def guess_program(ref):
    """Best guess at which program a reference belongs to."""
    if re.match(r"^[A-Z0-9]{1,4}FF-\d{4}$", ref):
        return "WWFF"
    if ref.startswith("B/"):
        return "WWBOTA"
    if re.match(r"^[A-Z0-9]{1,4}/[A-Z0-9]{2}-\d{3}$", ref):
        return "SOTA"
    if re.match(r"^[A-Z0-9]{1,4}-(\d{4,5}|TEST)$", ref):
        return "POTA"
    return None


DEFAULT_POTA_PREFIX = "US"  # a bare number like 1234 means US-1234


def parse_refs(text):
    """'1234, US-1234, KFF-0001, GMA:DL/EW-017' -> [('POTA','US-1234'), ...].
    A bare number is a POTA park in your default country.
    A PROGRAM: prefix overrides the guess (needed for GMA and LLOTA)."""
    out = []
    for raw in re.split(r"[,\s]+", text.upper()):
        if not raw:
            continue
        if re.fullmatch(r"\d{1,5}", raw):
            raw = f"{DEFAULT_POTA_PREFIX}-{int(raw):04d}"
        prog = None
        if ":" in raw:
            p, r = raw.split(":", 1)
            if p in PROGRAMS:
                prog, raw = p, r
        prog = prog or guess_program(raw)
        if raw:
            out.append((prog, raw))
    return out


def refs_label(refs):
    if not refs:
        return "Type your reference(s). Use GMA: or LLOTA: in front for those programs."
    parts = [f"{p or '??'} {r}" for p, r in refs]
    return "  ·  ".join(parts)


# ================================================================ ADIF

def _f(name, value):
    value = str(value)
    return f"<{name}:{len(value)}>{value} "


MFSK_SUBMODES = ("FT4", "FT2", "Q65", "FST4", "FST4W", "JS8")


def adif_mode_pair(mode):
    """The logger's mode -> (ADIF MODE, ADIF SUBMODE or None)."""
    if mode in MFSK_SUBMODES:
        return "MFSK", mode
    if mode == "PSK31":
        return "PSK", "PSK31"
    if mode in DIGITAL_VOICE:
        return "DIGITALVOICE", mode
    return mode, None


def _adif_mode(mode):
    m, sub = adif_mode_pair(mode)
    return _f("MODE", m) + (_f("SUBMODE", sub) if sub else "")


def _my_fields(prog, ref):
    if not (prog and ref):
        return ""  # not activating - home or portable
    if prog == "SOTA":
        return _f("MY_SOTA_REF", ref)
    s = _f("MY_SIG", prog) + _f("MY_SIG_INFO", ref)
    if prog == "WWFF":
        s += _f("MY_WWFF_REF", ref)
    return s


def _their_fields(their, file_prog):
    """their = [[prog, ref], ...] for the other station (P2P / S2S)."""
    if not their:
        return ""
    by_prog = {}
    for p, r in their:
        by_prog.setdefault(p, []).append(r)
    s = ""
    if "SOTA" in by_prog:
        s += _f("SOTA_REF", by_prog["SOTA"][0])
    if "WWFF" in by_prog:
        s += _f("WWFF_REF", by_prog["WWFF"][0])
    sig_prog = file_prog if (file_prog in by_prog and file_prog != "SOTA") else next(
        (p for p in by_prog if p and p != "SOTA"), None)
    if sig_prog:
        s += _f("SIG", sig_prog) + _f("SIG_INFO", ",".join(by_prog[sig_prog]))
    return s


def adif_filename(call, prog, ref, date):
    """The file names each upload site expects."""
    safe_call = call.replace("/", "_")
    if not (prog and ref):  # not activating: a plain daily log
        return f"{safe_call}-{date}.adi"
    safe_ref = ref.replace("/", "_")
    if prog == "WWFF":  # WWFF convention: CALL@REF YYYYMMDD.adi
        return f"{safe_call}@{safe_ref} {date}.adi"
    return f"{safe_call}@{safe_ref}-{date}.adi"  # POTA: CALL@PARK-YYYYMMDD.adi


def build_adif(qsos, my_call, prog, ref, grid="", operator=""):
    operator = operator or max(my_call.split("/"), key=len)
    out = [
        (f"{APP} export - {my_call} at {prog} {ref}\n" if prog and ref else f"{APP} export - {my_call}\n"),
        _f("ADIF_VER", "3.1.4") + _f("PROGRAMID", APP) + _f("PROGRAMVERSION", VERSION) + "<EOH>\n\n",
    ]
    for q in qsos:
        for their, time_on in _p2p_variants(q):
            out.append(_adif_record(q, their, time_on, my_call, operator, prog, ref, grid))
    return "".join(out)


def _p2p_variants(q):
    """A P2P with several parks becomes one record per park (POTA credits each
    park separately), a second apart so loggers don't merge them."""
    their = q.get("their", [])
    by_prog = {}
    for p, r in their:
        by_prog.setdefault(p, []).append(r)
    multi = next((p for p, rs in by_prog.items() if len(rs) > 1 and p != "SOTA"), None)
    if not multi:
        return [(their, q["time"])]
    others = [[p, r] for p, r in their if p != multi]
    return [(others + [[multi, r]], f"{q['time'][:4]}{i:02d}") for i, r in enumerate(by_prog[multi])]


def clean_text(t, limit=200):
    """Free text (comments) made safe for ADIF and the logger connections: no < > or control characters."""
    return re.sub(r"[<>\x00-\x1f\x7f]", " ", str(t or "")).strip()[:limit]


def _adif_record(q, their, time_on, my_call, operator, prog, ref, grid):
    if True:
        rec = (_f("CALL", q["call"]) + _f("QSO_DATE", q["date"]) + _f("TIME_ON", time_on)
               + _f("BAND", q["band"]) + _adif_mode(q["mode"])
               + _f("FREQ", f"{q['freq_khz'] / 1000:.5f}".rstrip("0"))
               + _f("RST_SENT", q["rst_s"]) + _f("RST_RCVD", q["rst_r"])
               + _f("STATION_CALLSIGN", my_call) + _f("OPERATOR", operator)
               + _my_fields(prog, ref))
        if grid:
            rec += _f("MY_GRIDSQUARE", grid)
        if clean_text(q.get("name"), 80):
            rec += _f("NAME", clean_text(q["name"], 80))
        if clean_text(q.get("state"), 6):
            rec += _f("STATE", clean_text(q["state"], 6))
        if _GRID_RE.match(q.get("grid") or ""):
            rec += _f("GRIDSQUARE", q["grid"])
        if clean_text(q.get("country"), 60):
            rec += _f("COUNTRY", clean_text(q["country"], 60))
        if q.get("comment"):
            rec += _f("COMMENT", clean_text(q["comment"]))
        rec += _their_fields(their, prog)
        return rec + "<EOR>\n"


# ================================================================ spotting

def _http_post_json(url, payload, headers):
    data = json.dumps(payload).encode("utf-8")
    h = {"Content-Type": "application/json", "Accept": "application/json",
         "User-Agent": f"RawHamsLiteLogger/{VERSION}"}
    h.update(headers)
    req = urllib.request.Request(url, data=data, method="POST", headers=h)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return None if 200 <= r.status < 300 else f"HTTP {r.status}"
    except urllib.error.HTTPError as e:
        return f"HTTP {e.code} {e.read().decode('utf-8', 'replace')[:120]}".strip()
    except urllib.error.URLError as e:
        return f"no connection ({e.reason})"
    except Exception as e:  # noqa: BLE001
        return str(e)


def spot_pota(call, khz, ref, mode, comment, spotter=""):
    """Spot call at ref. spotter = who's spotting (you); blank = a self-spot."""
    return _http_post_json("https://api.pota.app/spot/", {
        "activator": call, "spotter": spotter or call, "frequency": fmt_khz(khz),
        "reference": ref, "mode": mode, "source": APP, "comments": comment,
    }, {"Origin": "https://pota.app", "Referer": "https://pota.app/"})


def spot_wwbota(call, khz, ref, mode, comment, spotter=""):
    if not comment.upper().startswith(ref):
        comment = f"{ref} {comment}".strip()
    return _http_post_json("https://api.wwbota.net/spots/", {
        "spotter": spotter or call, "call": call, "freq": round(khz / 1000, 5),
        "mode": mode, "comment": comment, "type": "Live",
    }, {})


def spot_cluster(host, port, call, khz, ref, mode, comment, dx_call=""):
    """Log in to a DXSpider-style cluster (as call) and send one DX line (for dx_call, default yourself)."""
    line = re.sub(r"\s+", " ", f"DX {fmt_khz(khz)} {dx_call or call} {ref} {mode} {comment}").strip()
    try:
        s = socket.create_connection((host, port), timeout=10)
    except OSError as e:
        return f"can't reach {host} ({e})"
    try:
        s.settimeout(10)
        buf, sent_call, deadline = "", False, time.time() + 15
        while time.time() < deadline:
            try:
                chunk = s.recv(4096)
            except socket.timeout:
                break
            if not chunk:
                break
            buf += chunk.decode("latin-1", "ignore")
            if re.search(r"read-?only", buf, re.I):
                return "server is read-only"
            if not sent_call and re.search(r"login:|call:|enter your call", buf, re.I):
                s.sendall((call + "\r\n").encode())
                sent_call, buf = True, ""
            elif sent_call and re.search(r">\s*$", buf):
                s.sendall((line + "\r\n").encode())
                time.sleep(1.5)
                try:
                    s.sendall(b"bye\r\n")
                except OSError:
                    pass
                return None
        return "no prompt from server"
    finally:
        s.close()


def find_tqsl():
    """Path to ARRL's TQSL program (for LoTW), or ''."""
    import shutil
    p = shutil.which("tqsl")
    if p:
        return p
    for base in (os.environ.get("ProgramFiles(x86)", ""), os.environ.get("ProgramFiles", ""),
                 "/Applications/TrustedQSL"):
        for sub in ("TrustedQSL/tqsl.exe", "tqsl.app/Contents/MacOS/tqsl"):
            c = os.path.join(base, sub) if base else ""
            if c and os.path.exists(c):
                return c
    return ""


def tqsl_locations():
    """Station Location names saved in TQSL (read straight from TQSL's own station_data file)."""
    base = os.environ.get("TQSLDIR") or (os.path.join(os.environ.get("APPDATA", ""), "TrustedQSL") if IS_WIN
                                         else os.path.join(os.path.expanduser("~"), ".tqsl"))
    try:
        with open(os.path.join(base, "station_data"), encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    except OSError:
        return []
    import html
    return [html.unescape(n) for n in re.findall(r"<StationData\b[^>]*\bname=\"([^\"]*)\"", text)]


TQSL_RESULTS = {0: "uploaded", 1: "cancelled", 2: "rejected by LoTW", 3: "unexpected answer from LoTW",
                4: "TQSL error", 5: "TQSL library error", 6: "couldn't open the file", 7: "couldn't write a file",
                8: "all already in LoTW (or out of the location's dates)", 9: "uploaded (some were already in LoTW)",
                10: "TQSL couldn't find that station location (or didn't understand the request)", 11: "couldn't reach LoTW (internet?)"}


# ================================================================ share picture (map of worked stations)
# Only used when you press Share - nothing here runs in the background.

STATE_LL = {  # rough centre of each US state / Canadian province (lat, lon) - when we only know the state
    "AL": (32.8, -86.8), "AK": (61.4, -152.3), "AZ": (34.2, -111.7), "AR": (34.9, -92.4), "CA": (37.2, -119.5),
    "CO": (39.0, -105.5), "CT": (41.6, -72.7), "DE": (39.0, -75.5), "DC": (38.9, -77.0), "FL": (28.6, -82.4),
    "GA": (32.7, -83.4), "HI": (20.8, -156.3), "ID": (44.4, -114.6), "IL": (40.0, -89.2), "IN": (39.9, -86.3),
    "IA": (42.1, -93.5), "KS": (38.5, -98.4), "KY": (37.5, -85.3), "LA": (31.1, -92.0), "ME": (45.4, -69.2),
    "MD": (39.0, -76.8), "MA": (42.3, -71.8), "MI": (44.3, -85.4), "MN": (46.3, -94.3), "MS": (32.7, -89.7),
    "MO": (38.4, -92.5), "MT": (47.0, -109.6), "NE": (41.5, -99.8), "NV": (39.3, -116.6), "NH": (43.7, -71.6),
    "NJ": (40.2, -74.7), "NM": (34.4, -106.1), "NY": (42.9, -75.5), "NC": (35.6, -79.4), "ND": (47.5, -100.5),
    "OH": (40.3, -82.8), "OK": (35.6, -97.5), "OR": (43.9, -120.6), "PA": (40.9, -77.8), "RI": (41.7, -71.5),
    "SC": (33.9, -80.9), "SD": (44.4, -100.2), "TN": (35.9, -86.4), "TX": (31.5, -99.3), "UT": (39.3, -111.7),
    "VT": (44.1, -72.7), "VA": (37.5, -78.8), "WA": (47.4, -120.5), "WV": (38.6, -80.6), "WI": (44.6, -89.9),
    "WY": (43.0, -107.5), "PR": (18.2, -66.5),
    "AB": (53.9, -114.5), "BC": (51.5, -123.5), "MB": (50.5, -97.5), "NB": (46.6, -66.4), "NL": (48.6, -56.5),
    "NS": (45.0, -63.0), "ON": (45.5, -79.5), "PE": (46.3, -63.3), "QC": (46.8, -72.0), "SK": (52.0, -106.0),
    "NT": (62.5, -114.4), "NU": (63.7, -68.5), "YT": (60.7, -135.0)}


def grid_latlon(grid):
    """Centre of a Maidenhead square (EM15 or EM15ab) -> (lat, lon), or None."""
    g = (grid or "").strip()
    if not _GRID_RE.match(g):
        return None
    g = g[:2].upper() + g[2:4] + g[4:6].lower()
    lon = (ord(g[0]) - 65) * 20 - 180 + int(g[2]) * 2
    lat = (ord(g[1]) - 65) * 10 - 90 + int(g[3])
    if len(g) >= 6:
        lon += (ord(g[4]) - 97) / 12 + 1 / 24
        lat += (ord(g[5]) - 97) / 24 + 1 / 48
    else:
        lon, lat = lon + 1, lat + 0.5
    return lat, lon


_BASEMAP = {}


def _load_basemap():
    """Country outlines and state lines (Natural Earth, public domain) - read once, the first time Share is used."""
    if _BASEMAP:
        return _BASEMAP
    polys, lines, cents = [], [], {}
    try:
        with open(os.path.join(RES_DIR, "basemap.txt"), encoding="ascii") as fh:
            for ln in fh:
                if ln[:1] not in ("c", "s"):
                    continue
                pts = [(int(x) / 10, int(y) / 10) for x, y in (p.split(",") for p in ln[2:].split())]
                (polys if ln[0] == "c" else lines).append(pts)
        with open(os.path.join(RES_DIR, "countries.txt"), encoding="utf-8") as fh:
            for ln in fh:
                if ln.startswith("#"):
                    continue
                f = ln.rstrip("\n").split("|")
                if len(f) == 6:
                    for k in f[:3]:
                        if k:
                            cents[k.lower()] = (float(f[4]), float(f[5]))
    except OSError:
        pass
    _BASEMAP.update(polys=polys, lines=lines, cents=cents)
    return _BASEMAP


def _share_font(size, bold=False):
    from PIL import ImageFont
    for name in (("arialbd.ttf", "DejaVuSans-Bold.ttf") if bold else ("arial.ttf", "DejaVuSans.ttf")):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            pass
    try:
        return ImageFont.load_default(size=size)
    except TypeError:  # older Pillow
        return ImageFont.load_default()


def render_share_png(path, me, stations, title, lines_txt):
    """Draw the map picture (1200x630, the size Facebook and others like) and save it as PNG.
    me = (lat, lon) or None; stations = [(lat, lon, is_p2p), ...]."""
    from PIL import Image, ImageDraw
    W, H, TOP, BOT = 1200, 630, 70, 92
    bm = _load_basemap()
    pts = [(la, lo) for la, lo, _ in stations] + ([me] if me else [])
    if not pts:
        pts = [(38.0, -97.0)]
    lat0, lat1 = min(p[0] for p in pts), max(p[0] for p in pts)
    lon0, lon1 = min(p[1] for p in pts), max(p[1] for p in pts)
    # at least a region-sized view, with a margin, in the picture's shape
    clat = (lat0 + lat1) / 2
    kx = math.cos(math.radians(max(-70, min(70, clat))))
    span_lon = max(lon1 - lon0, (lat1 - lat0) / kx, 24) * 1.25
    mh = H - TOP - BOT
    span_lat = span_lon * kx * mh / W
    if span_lat < (lat1 - lat0) * 1.2:
        span_lat = (lat1 - lat0) * 1.2
        span_lon = span_lat / kx * W / mh
    cx = (lon0 + lon1) / 2
    left, right = cx - span_lon / 2, cx + span_lon / 2
    bottom, top = clat - span_lat / 2, clat + span_lat / 2

    def xy(lat, lon):
        return ((lon - left) / (right - left) * W, TOP + (top - lat) / (top - bottom) * mh)

    img = Image.new("RGB", (W, H), (22, 47, 74))
    d = ImageDraw.Draw(img)
    for poly in bm.get("polys", []):
        if max(x for x, _ in poly) < left - 5 or min(x for x, _ in poly) > right + 5:
            continue
        if max(y for _, y in poly) < bottom - 5 or min(y for _, y in poly) > top + 5:
            continue
        d.polygon([xy(y, x) for x, y in poly], fill=(214, 204, 178), outline=(150, 140, 115))
    for ln in bm.get("lines", []):
        if max(x for x, _ in ln) < left or min(x for x, _ in ln) > right:
            continue
        d.line([xy(y, x) for x, y in ln], fill=(170, 160, 135), width=1)
    if me:
        mx, my = xy(*me)
        for la, lo, _p2p in stations:
            d.line([(mx, my), xy(la, lo)], fill=(230, 120, 40), width=2)
    for la, lo, p2p in stations:
        x, y = xy(la, lo)
        r = 7 if p2p else 6
        d.ellipse([x - r, y - r, x + r, y + r], fill=(46, 158, 110) if p2p else (240, 180, 40), outline=(40, 30, 20))
    if me:
        mx, my = xy(*me)
        d.ellipse([mx - 10, my - 10, mx + 10, my + 10], fill=(200, 40, 40), outline=(255, 255, 255), width=3)
    d.rectangle([0, 0, W, TOP], fill=(20, 24, 28))
    d.text((20, 14), title, font=_share_font(34, True), fill=(255, 255, 255))
    d.rectangle([0, H - BOT, W, H], fill=(20, 24, 28))
    f2 = _share_font(24)
    for i, t in enumerate(lines_txt[:2]):
        d.text((20, H - BOT + 12 + i * 34), t, font=f2, fill=(235, 235, 235))
    f3 = _share_font(18)
    d.text((W - 300, H - 30), "The Raw Ham's Lite Logger", font=f3, fill=(170, 170, 170))
    d.rectangle([W - 312, TOP + 6, W - 6, TOP + 36], fill=(20, 24, 28))
    lx = W - 300
    for txt, colr, step in (("worked", (240, 180, 40), 110), ("P2P", (46, 158, 110), 90), ("me", (200, 40, 40), 0)):
        d.ellipse([lx, TOP + 14, lx + 14, TOP + 28], fill=colr, outline=(40, 30, 20))
        d.text((lx + 20, TOP + 10), txt, font=f3, fill=(255, 255, 255))
        lx += step
    img.save(path, "PNG", optimize=True)
    return path


# ================================================================ light / dark appearance

DARK = {"on": False}
# light-mode text colours -> easy-to-read versions on a dark background
_DARK_TEXT = {"#555": "#c8c8c8", "#777": "#a8a8a8", "#888": "#a8a8a8", "#222": "#f0f0f0", "#333": "#e6e6e6",
              "#c0392b": "#ff7b6e", "#1e7d4f": "#62d69c", "#b9770e": "#f2b84b", "#7a4f00": "#e9bb6c",
              "#1f4e8c": "#86b6ff", "#1b5e40": "#9fe0bf"}
_LIGHT_TEXT = {v: k for k, v in _DARK_TEXT.items()}
D_BG, D_PANEL, D_FIELD, D_FG, D_BORDER = "#202326", "#2b3035", "#15171a", "#e8e8e8", "#40464d"


def ver_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))) or (0,)


def fetch_latest(timeout=8):
    """version.json from the public page, or None (offline / not there yet)."""
    try:
        req = urllib.request.Request(UPDATE_URL + "?t=" + str(int(time.time() // 300)),
                                     headers={"User-Agent": f"RawHamsLiteLogger/{VERSION}"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            info = json.loads(r.read(20000).decode("utf-8"))
        return info if isinstance(info, dict) and info.get("pc") else None
    except Exception:
        return None


def qrt_comment(text):
    """The spot comment box, with QRT in it so the spot sites mark you off the air."""
    c = " ".join(str(text or "").split())
    if not c:
        return "QRT - thanks all!"
    return c if "qrt" in c.lower() else "QRT - " + c


def col(c):
    """A colour from the code, adjusted for dark mode when it's on."""
    return _DARK_TEXT.get(c.lower(), c) if DARK["on"] else c


def _dark_theme(style, body):
    if "rawdark" in style.theme_names():
        return
    sel = "#2e9e6e"
    style.theme_create("rawdark", parent="clam", settings={
        ".": {"configure": {"background": D_BG, "foreground": D_FG, "fieldbackground": D_FIELD,
                            "bordercolor": D_BORDER, "lightcolor": D_PANEL, "darkcolor": D_BG,
                            "troughcolor": D_PANEL, "focuscolor": sel, "selectbackground": sel,
                            "selectforeground": "white", "insertcolor": D_FG, "arrowcolor": D_FG},
              "map": {"foreground": [("disabled", "#6c737a")]}},
        "TFrame": {"configure": {"background": D_BG}},
        "TLabel": {"configure": {"background": D_BG, "foreground": D_FG}},
        "TLabelframe": {"configure": {"background": D_BG, "bordercolor": D_BORDER}},
        "TLabelframe.Label": {"configure": {"background": D_BG, "foreground": D_FG}},
        "TButton": {"configure": {"background": D_PANEL, "foreground": D_FG, "padding": (8, 3)},
                    "map": {"background": [("pressed", "#46505a"), ("active", "#39414a")]}},
        "TEntry": {"configure": {"fieldbackground": D_FIELD, "foreground": D_FG, "insertcolor": D_FG},
                   "map": {"fieldbackground": [("readonly", D_PANEL)]}},
        "TCombobox": {"configure": {"fieldbackground": D_FIELD, "foreground": D_FG, "background": D_PANEL,
                                    "arrowcolor": D_FG},
                      "map": {"fieldbackground": [("readonly", D_FIELD)], "foreground": [("readonly", D_FG)],
                              "selectbackground": [("readonly", D_FIELD)],
                              "selectforeground": [("readonly", D_FG)]}},
        "TCheckbutton": {"configure": {"background": D_BG, "foreground": D_FG, "indicatorbackground": D_FIELD,
                                       "indicatorforeground": D_FG},
                         "map": {"background": [("active", D_BG)],
                                 "indicatorbackground": [("selected", sel)]}},
        "TNotebook": {"configure": {"background": D_BG, "bordercolor": D_BORDER}},
        "TNotebook.Tab": {"configure": {"background": D_PANEL, "foreground": D_FG, "padding": (10, 4)},
                          "map": {"background": [("selected", D_BG)]}},
        "Treeview": {"configure": {"background": D_FIELD, "fieldbackground": D_FIELD, "foreground": D_FG,
                                   "font": body,
                                   "rowheight": int(tk.font.Font(font=body).metrics("linespace") * 1.5)},
                     "map": {"background": [("selected", sel)], "foreground": [("selected", "white")]}},
        "Treeview.Heading": {"configure": {"background": D_PANEL, "foreground": D_FG, "font": (body[0], 10, "bold")},
                             "map": {"background": [("active", "#39414a")]}},
        "TScrollbar": {"configure": {"background": D_PANEL, "troughcolor": D_BG, "arrowcolor": D_FG}},
    })


_FG_OPTS = ("foreground", "activeforeground", "disabledforeground", "insertbackground")
_BG_OPTS = ("background", "activebackground", "highlightbackground", "readonlybackground")
_DEFAULT_FG = {"black", "#000000", "#000", "systembuttontext", "systemwindowtext", "systemmenutext"}
_DEFAULT_BG = {"systembuttonface", "#d9d9d9", "#dcdad5", "systemwindow", "white", "#ffffff", "systemmenu",
               "#ececec", "systemwindowbody"}


def _retheme(w, dark, light_bg="SystemButtonFace"):
    """Switch an existing widget tree between light and dark (new widgets pick it up as they're made)."""
    is_ttk = w.__class__.__module__.endswith("ttk") or w.winfo_class().startswith("T") and w.winfo_class() != "Toplevel"
    if is_ttk:
        try:
            fgc = str(w.cget("foreground"))
            if fgc:
                m = (_DARK_TEXT if dark else _LIGHT_TEXT).get(fgc.lower())
                if m:
                    w.configure(foreground=m)
        except tk.TclError:
            pass
    else:
        orig = getattr(w, "_light_colors", None)
        if dark:
            saved = {}
            for opt in _FG_OPTS + _BG_OPTS:
                try:
                    v = str(w.cget(opt))
                except tk.TclError:
                    continue
                new = None
                if opt in _FG_OPTS:
                    new = _DARK_TEXT.get(v.lower()) or (D_FG if v.lower() in _DEFAULT_FG else None)
                elif v.lower() in _DEFAULT_BG:
                    new = D_FIELD if (w.winfo_class() in ("Listbox", "Entry", "Text") and opt == "background") \
                        else D_BG
                if new and new != v:
                    saved[opt] = v
                    try:
                        w.configure(**{opt: new})
                    except tk.TclError:
                        pass
            if saved and orig is None:
                w._light_colors = saved
        elif orig:
            try:
                w.configure(**orig)
            except tk.TclError:
                pass
            w._light_colors = None
        elif not dark:  # made while dark mode was on: map its dark colours back to light ones
            for opt in _FG_OPTS + _BG_OPTS:
                try:
                    v = str(w.cget(opt)).lower()
                except tk.TclError:
                    continue
                new = None
                if opt in _FG_OPTS:
                    new = _LIGHT_TEXT.get(v) or ("black" if v == D_FG else None)
                elif v in (D_BG, D_PANEL):
                    new = light_bg
                elif v == D_FIELD:
                    new = "white"
                if new:
                    try:
                        w.configure(**{opt: new})
                    except tk.TclError:
                        pass
    for c in w.winfo_children():
        _retheme(c, dark, light_bg)


def _dark_titlebar(win, dark):
    """Windows 10/11: dark title bar to match."""
    if not IS_WIN:
        return
    try:
        import ctypes
        hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
        val = ctypes.c_int(1 if dark else 0)
        for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE (newer, older builds)
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                break
    except Exception:  # noqa: BLE001
        pass


# ================================================================ desktop shortcut

def make_shortcuts():
    """Desktop + Start menu (Windows) or desktop + app menu (Linux) shortcuts with the logo.
    Returns a list of what was made; raises OSError with a plain message if it couldn't."""
    script = os.path.abspath(__file__)
    made = []
    if IS_WIN:
        import subprocess
        exe = sys.executable
        pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")  # no black window behind the logger
        if FROZEN:
            script, ico = "", exe  # the installed program: it carries its own icon
        elif os.path.exists(pyw):
            exe = pyw
        if not FROZEN:
            ico = os.path.join(HERE, "logo.ico")
        ps = ("$w = New-Object -ComObject WScript.Shell; "
              "foreach ($f in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) { "
              "  $s = $w.CreateShortcut((Join-Path $f $env:RH_NAME)); "
              "  $s.TargetPath = $env:RH_EXE; if ($env:RH_SCRIPT) { $s.Arguments = '\"' + $env:RH_SCRIPT + '\"' }; "
              "  $s.WorkingDirectory = $env:RH_DIR; $s.Description = $env:RH_DESC; "
              "  if (Test-Path $env:RH_ICO) { $s.IconLocation = $env:RH_ICO + ',0' }; "
              "  $s.Save(); Write-Output (Join-Path $f $env:RH_NAME) }")
        env = dict(os.environ, RH_NAME=f"{APP}.lnk", RH_EXE=exe, RH_SCRIPT=script,
                   RH_DIR=os.path.dirname(exe) if FROZEN else HERE, RH_ICO=ico,
                   RH_DESC="POTA, WWFF, SOTA, GMA, WWBOTA and LLOTA logger")
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                            "-Command", ps], env=env, capture_output=True, text=True, timeout=30,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0:
            raise OSError((r.stderr or "PowerShell refused").strip().splitlines()[-1])
        made = [ln.strip() for ln in r.stdout.splitlines() if ln.strip()]
    else:
        import shlex
        import shutil
        import subprocess
        png = os.path.join(RES_DIR, "logo.png")
        entry = ("[Desktop Entry]\nType=Application\nName=" + APP + "\n"
                 "Comment=POTA, WWFF, SOTA, GMA, WWBOTA and LLOTA logger and self-spotter\n"
                 "Exec=" + shlex.quote(sys.executable or "python3") + " " + shlex.quote(script) + "\n"
                 + ("Icon=" + png + "\n" if os.path.exists(png) else "")
                 + "Terminal=false\nCategories=HamRadio;Network;Utility;\nStartupWMClass=Tk\n")
        apps = os.path.join(os.path.expanduser("~"), ".local", "share", "applications")
        desk = os.path.join(os.path.expanduser("~"), "Desktop")
        if shutil.which("xdg-user-dir"):
            try:
                desk = subprocess.run(["xdg-user-dir", "DESKTOP"], capture_output=True, text=True,
                                      timeout=5).stdout.strip() or desk
            except Exception:  # noqa: BLE001
                pass
        for folder in (apps, desk):
            if folder == desk and not os.path.isdir(desk):
                continue
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, "rawham-lite-logger.desktop")
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(entry)
            os.chmod(path, 0o755)
            if folder == desk and shutil.which("gio"):
                subprocess.run(["gio", "set", path, "metadata::trusted", "true"], capture_output=True, timeout=5)
            made.append(path)
    if not made:
        raise OSError("no shortcut was created")
    return made


# ================================================================ keeping passwords safe

SECRET_KEYS = ("qrz_pass", "qrz_key", "wl_key")
_SECRET_TAG = "dpapi:"


def _dpapi(data, protect):
    """Windows DPAPI: encrypts with the signed-in Windows user's key (same protection as saved browser
    passwords). Only that Windows user on this PC can decrypt it."""
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    buf = ctypes.create_string_buffer(data, len(data))
    blob_in = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    blob_out = BLOB()
    crypt = ctypes.windll.crypt32
    fn = crypt.CryptProtectData if protect else crypt.CryptUnprotectData
    fn.argtypes = [ctypes.POINTER(BLOB), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                   wintypes.DWORD, ctypes.POINTER(BLOB)]
    fn.restype = wintypes.BOOL
    if not fn(ctypes.byref(blob_in), None, None, None, None, 0x01, ctypes.byref(blob_out)):  # UI_FORBIDDEN
        raise OSError("Windows couldn't " + ("encrypt" if protect else "decrypt") + " the saved password")
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(blob_out.pbData)


_KEYRING_TAG = "keyring:"
_KEYRING_SERVICE = "rawham-lite-logger"


def _secret_tool(*args, value=None):
    """Linux desktop keyring (GNOME Keyring / KWallet) through libsecret's secret-tool."""
    import shutil
    import subprocess
    if not IS_LINUX or not shutil.which("secret-tool"):
        raise OSError("no keyring")
    r = subprocess.run(["secret-tool", *args], input=(value or "").encode("utf-8"), capture_output=True,
                       timeout=8)
    if r.returncode != 0:
        raise OSError(r.stderr.decode("utf-8", "ignore").strip() or "keyring refused")
    return r.stdout.decode("utf-8")


def secret_seal(value, name=""):
    """Text to store in the data file for a password/key. Encrypted with Windows DPAPI on Windows; kept in the
    desktop keyring on Linux (the file only says where it is). Otherwise as-is (the file is owner-only)."""
    if not value:
        return value
    if IS_WIN:
        try:
            import base64
            return _SECRET_TAG + base64.b64encode(_dpapi(value.encode("utf-8"), True)).decode("ascii")
        except Exception:  # noqa: BLE001
            return value
    if IS_LINUX and name:
        try:
            _secret_tool("store", f"--label={APP} {name}", "service", _KEYRING_SERVICE, "key", name, value=value)
            return _KEYRING_TAG + name
        except Exception:  # noqa: BLE001
            return value
    return value


def secret_open(stored):
    """Undo secret_seal. Returns (value, ok). ok is False when it can't be unlocked (the data file was
    copied from another PC or user, or the keyring is unavailable) - the person just types it again."""
    if not stored:
        return "", True
    stored = str(stored)
    if stored.startswith(_KEYRING_TAG):
        try:
            v = _secret_tool("lookup", "service", _KEYRING_SERVICE, "key", stored[len(_KEYRING_TAG):])
            return v, bool(v)
        except Exception:  # noqa: BLE001
            return "", False
    if not stored.startswith(_SECRET_TAG):
        return stored, True
    try:
        import base64
        return _dpapi(base64.b64decode(stored[len(_SECRET_TAG):]), False).decode("utf-8"), True
    except Exception:  # noqa: BLE001
        return "", False


def is_private_host(host):
    """True for this PC and home-network addresses (where plain http is acceptable)."""
    import ipaddress
    h = (host or "").strip().lower().strip("[]")
    if h in ("localhost",) or h.endswith((".local", ".lan", ".home", ".home.arpa")):
        return True
    try:
        ip = ipaddress.ip_address(h)
        return ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        return False


def insecure_web_url(url):
    """True when a web address would send a key unencrypted over the internet (http to a public host)."""
    u = (url or "").strip()
    if not u:
        return False
    if "://" not in u:
        u = "https://" + u  # the logger adds https:// when no scheme is typed
    p = urllib.parse.urlparse(u)
    return p.scheme == "http" and not is_private_host(p.hostname or "")


def local_addresses():
    """This PC's own IP addresses (for accepting WSJT-X messages only from this PC)."""
    out = {"127.0.0.1"}
    try:
        out.update(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            out.add(info[4][0])
    except OSError:
        pass
    return out


# ================================================================ radio (CAT) control

# Yaesu "new" CAT (FT-991A, FT-710, FTDX10/101, FT-891 ...): MD0x;
YAESU_MODE_FROM_CODE = {"1": "SSB", "2": "SSB", "3": "CW", "7": "CW", "4": "FM", "B": "FM",
                        "A": "FM", "5": "AM", "D": "AM", "6": "RTTY", "9": "RTTY",
                        "8": "DATA", "C": "DATA"}
YAESU_IDS = {"0570": "FT-991A", "0800": "FT-710", "0650": "FT-891", "0761": "FTDX10",
             "0681": "FTDX101D", "0682": "FTDX101MP", "0670": "FT-991"}

# key, label, driver, default baud, CI-V address (Icom/Xiegu)
RIG_TYPES = [
    ("yaesu", "Yaesu FT-710 / FT-991A / FT-891 / FTDX10 / FTDX101", "yaesu", "38400", None),
    ("yaesu_old", "Yaesu FT-817 / FT-818 / FT-857 / FT-897", "yaesu_old", "4800", None),
    ("ic705", "Icom IC-705", "icom", "19200", 0xA4),
    ("ic7300", "Icom IC-7300", "icom", "19200", 0x94),
    ("ic7300mk2", "Icom IC-7300 MK2", "icom", "19200", 0xB6),
    ("ic7100", "Icom IC-7100", "icom", "19200", 0x88),
    ("ic7610", "Icom IC-7610", "icom", "19200", 0x98),
    ("ic9700", "Icom IC-9700", "icom", "19200", 0xA2),
    ("xiegu_g90", "Xiegu G90", "icom", "19200", 0x88),
    ("xiegu_x6100", "Xiegu X6100 / X6200", "icom", "19200", 0xA4),
    ("xiegu_x5105", "Xiegu X5105 / X108G", "icom", "19200", 0x70),
    ("icom_other", "Other Icom CI-V radio (set the address)", "icom", "19200", 0x94),
    ("flrig", "Flrig - any radio Flrig supports", "flrig", "", None),
    ("rigctld", "Hamlib rigctld - any Hamlib radio", "rigctld", "", None),
]
RIG_KEYS = [r[0] for r in RIG_TYPES]
RIG_NET_PORTS = {"flrig": "12345", "rigctld": "4532"}
RIG_HINTS = {
    "yaesu": "Use the radio's 'Enhanced' COM port. Speed must match the CAT RATE menu (38400 recommended). "
             "FT-710: tick DTR/RTS off.",
    "yaesu_old": "Needs a CAT cable on the ACC/CAT jack. Speed must match the CAT RATE menu (4800 by default). "
                 "FT8/FT4 use DIG mode - set the radio's DIG MODE menu to USER-U.",
    "icom": "IC-705 / IC-7300 / IC-9700: plug in the USB cable and use its COM port; CI-V USB baud 'Auto' "
            "works with any speed. Set CI-V USB Echo Back OFF if you can. The address is found automatically "
            "if it doesn't match.",
    "flrig": "Start Flrig first and set it up for your radio. The logger talks to it on this PC "
             "(127.0.0.1, port 12345). Flrig must be running while you log.",
    "rigctld": "Start rigctld for your radio first, for example:  rigctld -m 3073 -r COM5 -s 19200  "
               "(3073 = IC-7300). The logger talks to it on this PC (127.0.0.1, port 4532).",
}


def rig_type(key):
    return next((r for r in RIG_TYPES if r[0] == key), RIG_TYPES[0])


def yaesu_mode_code(mode, khz):
    if mode == "SSB":
        return "2" if (khz >= 10000 or 5330 <= khz <= 5410) else "1"
    return {"CW": "3", "FM": "4", "AM": "5", "RTTY": "6",
            "FT8": "C", "FT4": "C", "PSK31": "C"}.get(mode)


def _usb(khz):
    return khz >= 10000 or 5330 <= khz <= 5410


def norm_rig_mode(s):
    """Turn a Flrig/Hamlib mode name (USB-D, PKTUSB, DATA-U, CW-R ...) into SSB/CW/AM/FM/RTTY/DATA."""
    u = (s or "").strip().upper()
    if not u:
        return None
    if re.search(r"PKT|DATA|DIG|PSK|FT8|FT4|^D-|-D\d?$|\bD\d?$", u):
        return "DATA"
    if u.startswith("CW"):
        return "CW"
    if "RTTY" in u or "FSK" in u:
        return "RTTY"
    if u.startswith(("USB", "LSB")):
        return "SSB"
    if "AM" in u:
        return "AM"
    if "FM" in u:
        return "FM"
    return None


def rig_mode_wants(mode, khz):
    """Candidate mode names (Flrig style) for one of the logger's modes, best first."""
    sb = "USB" if _usb(khz) else "LSB"
    return {"SSB": [sb], "CW": ["CW", "CW-U", "CW-USB", "CWU"], "AM": ["AM"], "FM": ["FM"],
            "RTTY": ["RTTY", "RTTY-L", "RTTY-LSB", "FSK", "RTTY-U"],
            "FT8": ["USB-D", "USB-D1", "DATA-U", "D-USB", "PKT-U", "PKTUSB", "DIGU", "DIG-U", "DATA-USB",
                    "USB DATA", "DATA", "DIG", "USB"]}.get("FT8" if mode in ("FT8", "FT4", "PSK31") else mode, [])


class RigBase:
    """CAT on a background thread. Calls on_update(khz, mode_or_DATA) and on_status(text, ok)
    from that thread; the app hops back to Tk. set(khz, mode) queues a change."""
    where = "the radio"

    def __init__(self, on_update, on_status):
        self.on_update, self.on_status = on_update, on_status
        self.cmds = queue.Queue()
        self.running = False
        self.model = ""

    def start(self):
        self.running = True
        threading.Thread(target=self._run, daemon=True).start()

    def stop(self):
        self.running = False

    def set(self, khz, mode):
        self.cmds.put((khz, mode))

    # drivers fill these in
    def open(self):
        pass

    def close(self):
        pass

    def identify(self):
        return None

    def poll(self):
        return None

    def apply(self, khz, mode):
        pass

    def _run(self):
        try:
            self.open()
        except Exception as e:  # noqa: BLE001
            self.running = False
            self.on_status(f"Can't open {self.where}: {e}", False)
            return
        try:
            self.model = self.identify() or ""
        except Exception as e:  # noqa: BLE001
            self.running = False
            self.on_status(f"Can't reach {self.where}: {e}", False)
            try:
                self.close()
            except Exception:  # noqa: BLE001
                pass
            return
        if self.model:
            self.on_status(f"Connected: {self.model} ({self.where})", True)
        else:
            self.on_status(f"{self.where} opened but the radio didn't answer - check the radio type, "
                           "speed and CAT menu", False)
        misses = 0
        while self.running:
            try:
                while not self.cmds.empty():
                    khz, mode = self.cmds.get_nowait()
                    self.apply(khz, mode)
                r = self.poll()
                if r and r[0]:
                    misses = 0
                    if not self.model:
                        self.model = "radio"
                        self.on_status(f"Connected ({self.where})", True)
                    self.on_update(*r)
                else:
                    misses += 1
                    if misses == 5:
                        self.on_status("Radio stopped answering - is it on?", False)
            except Exception as e:  # noqa: BLE001
                self.on_status(f"CAT error: {e}", False)
                break
            time.sleep(0.5)
        try:
            self.close()
        except Exception:  # noqa: BLE001
            pass
        self.running = False


class SerialRig(RigBase):
    stopbits = 1

    def __init__(self, port, baud, drop_dtr_rts, on_update, on_status):
        super().__init__(on_update, on_status)
        self.port, self.baud, self.drop = port, baud, drop_dtr_rts
        self.where = port
        self.ser = None

    def open(self):
        s = serial.Serial()
        s.port, s.baudrate, s.timeout, s.write_timeout = self.port, self.baud, 0.6, 1
        s.bytesize, s.parity, s.stopbits = 8, "N", self.stopbits
        if self.drop:
            s.dtr = False
            s.rts = False
        s.open()
        self.ser = s

    def close(self):
        if self.ser:
            self.ser.close()


class YaesuCat(SerialRig):
    """Yaesu text CAT: FT-710, FT-991A, FT-891, FTDX10, FTDX101."""

    def _xfer(self, cmd, reply=True):
        self.ser.reset_input_buffer()
        self.ser.write(cmd.encode("ascii"))
        if not reply:
            time.sleep(0.05)
            return ""
        resp = self.ser.read_until(b";").decode("ascii", "ignore")
        return "" if resp == "?;" else resp

    def identify(self):
        m = re.match(r"ID(\d{4});", self._xfer("ID;"))
        return YAESU_IDS.get(m.group(1), f"Yaesu ID {m.group(1)}") if m else None

    def poll(self):
        fa = re.match(r"FA(\d{8,9});", self._xfer("FA;"))
        md = re.match(r"MD0([0-9A-F]);", self._xfer("MD0;"))
        if not fa:
            return None
        return int(fa.group(1)) / 1000.0, (YAESU_MODE_FROM_CODE.get(md.group(1)) if md else None)

    def apply(self, khz, mode):
        if khz:
            self._xfer(f"FA{int(round(khz * 1000)):09d};", reply=False)
        code = yaesu_mode_code(mode, khz or 14000) if mode else None
        if code:
            self._xfer(f"MD0{code};", reply=False)


class YaesuOldCat(SerialRig):
    """Yaesu 5-byte binary CAT: FT-817, FT-818, FT-857, FT-897 (8N2)."""
    stopbits = 2
    MODES = {0x00: "SSB", 0x01: "SSB", 0x02: "CW", 0x03: "CW", 0x04: "AM", 0x06: "FM", 0x08: "FM",
             0x0A: "DATA", 0x0C: "DATA"}

    def _cmd(self, b, reply=0):
        self.ser.reset_input_buffer()
        self.ser.write(bytes(b))
        if not reply:
            time.sleep(0.08)
            return b""
        return self.ser.read(reply)

    def poll(self):
        r = self._cmd([0, 0, 0, 0, 0x03], 5)
        if len(r) != 5:
            return None
        digits = "".join(f"{x >> 4}{x & 15}" for x in r[:4])
        if not digits.isdigit():
            return None
        return int(digits) * 10 / 1000.0, self.MODES.get(r[4] & 0x7F)

    def identify(self):
        return "Yaesu FT-817/818/857/897" if self.poll() else None

    def apply(self, khz, mode):
        if khz:
            v = f"{int(round(khz * 100)):08d}"  # 10 Hz units
            self._cmd([int(v[i], 10) << 4 | int(v[i + 1], 10) for i in range(0, 8, 2)] + [0x01])
        code = None
        if mode:
            code = {"SSB": 0x01 if _usb(khz or 14000) else 0x00, "CW": 0x02, "AM": 0x04, "FM": 0x08,
                    "RTTY": 0x0A, "FT8": 0x0A, "FT4": 0x0A, "PSK31": 0x0A}.get(mode)
        if code is not None:
            self._cmd([code, 0, 0, 0, 0x07])


def civ_bcd(hz, nbytes=5):
    out = []
    for _ in range(nbytes):
        d = hz % 100
        out.append((d // 10) << 4 | d % 10)
        hz //= 100
    return bytes(out)


def civ_unbcd(b):
    hz, mul = 0, 1
    for x in b:
        hi, lo = x >> 4, x & 15
        if hi > 9 or lo > 9:
            return None
        hz += (hi * 10 + lo) * mul
        mul *= 100
    return hz


class IcomCat(SerialRig):
    """Icom CI-V (IC-705, IC-7300, IC-7100, IC-7610, IC-9700 ...) and Xiegu G90 / X6100 / X5105."""
    CTRL = 0xE0
    MODES = {0x00: "SSB", 0x01: "SSB", 0x02: "AM", 0x03: "CW", 0x07: "CW", 0x04: "RTTY", 0x08: "RTTY",
             0x05: "FM", 0x06: "FM"}
    TRY_ADDRS = [0x94, 0xA4, 0x88, 0x70, 0x98, 0xA2, 0xB6, 0x76, 0x8E, 0xAC]

    def __init__(self, port, baud, drop_dtr_rts, addr, on_update, on_status):
        super().__init__(port, baud, drop_dtr_rts, on_update, on_status)
        self.addr = addr
        self.data_ok = True
        self.buf = b""

    def _frames(self, timeout=0.4):
        end = time.time() + timeout
        while time.time() < end:
            chunk = self.ser.read(self.ser.in_waiting or 1)
            if chunk:
                self.buf += chunk
            while b"\xfd" in self.buf:
                raw, self.buf = self.buf.split(b"\xfd", 1)
                i = raw.rfind(b"\xfe\xfe")
                if i >= 0 and len(raw) - i >= 5:
                    yield raw[i + 2:]

    def _cmd(self, cmd, data=b"", addr=None, reply=True):
        """Returns the reply payload after the command bytes, b'' for OK, None for NG / no answer."""
        to = self.addr if addr is None else addr
        self.ser.reset_input_buffer()
        self.buf = b""
        self.ser.write(b"\xfe\xfe" + bytes([to, self.CTRL]) + cmd + data + b"\xfd")
        for f in self._frames():
            dst, src, body = f[0], f[1], f[2:]
            if src == self.CTRL or dst not in (self.CTRL, 0x00):
                continue  # our own echo, or traffic for someone else
            if to not in (0x00, src):
                continue
            if body[:1] == b"\xfb":
                return b""
            if body[:1] == b"\xfa":
                return None
            if body.startswith(cmd):
                if addr == 0x00:
                    self.addr = src
                return body[len(cmd):]
        return None

    def identify(self):
        names = {r[4]: r[1] for r in reversed(RIG_TYPES) if r[2] == "icom" and r[0] != "icom_other"}
        r = self._cmd(b"\x19\x00")
        if r is None:
            r = self._cmd(b"\x19\x00", addr=0x00)  # broadcast - whoever is there answers
        if r is None:
            for a in [self.addr] + [x for x in self.TRY_ADDRS if x != self.addr]:
                if self._cmd(b"\x03", addr=a) is not None:
                    self.addr = a
                    break
            else:
                return None
        return f"{names.get(self.addr, 'Icom')} (CI-V {self.addr:02X}h)"

    def poll(self):
        f = self._cmd(b"\x03")
        hz = civ_unbcd(f[:5]) if f and len(f) >= 5 else None
        if not hz:
            return None
        mode = None
        m = self._cmd(b"\x04")
        if m:
            mode = self.MODES.get(m[0])
            if mode in ("SSB", "AM", "FM") and self.data_ok:
                dm = self._cmd(b"\x1a\x06")
                if dm is None:
                    self.data_ok = False  # radio has no data-mode command
                elif dm and dm[0]:
                    mode = "DATA"
        return hz / 1000.0, mode

    def apply(self, khz, mode):
        khz = khz or 14000
        if khz:
            self._cmd(b"\x05", civ_bcd(int(round(khz * 1000))))
        if not mode:
            return
        data = mode in ("FT8", "FT4", "PSK31")
        code = {"SSB": 0x01 if _usb(khz) else 0x00, "CW": 0x03, "AM": 0x02, "FM": 0x05, "RTTY": 0x04}.get(
            mode, 0x01 if data else None)
        if code is None:
            return
        self._cmd(b"\x06", bytes([code, 0x01]))
        if self.data_ok and code in (0x00, 0x01, 0x02, 0x05):
            self._cmd(b"\x1a\x06", b"\x01\x01" if data else b"\x00\x00")


class _TimeoutTransport(xmlrpc.client.Transport):
    def make_connection(self, host):
        c = super().make_connection(host)
        c.timeout = 3
        return c


class FlrigCat(RigBase):
    def __init__(self, host, port, on_update, on_status):
        super().__init__(on_update, on_status)
        self.host, self.port = host or "127.0.0.1", int(port or 12345)
        self.where = f"Flrig at {self.host}:{self.port}"
        self.modes = None

    def open(self):
        self.x = xmlrpc.client.ServerProxy(f"http://{self.host}:{self.port}/RPC2",
                                           transport=_TimeoutTransport(), allow_none=True)

    def _call(self, name, *args, alt=None):
        try:
            return getattr(self.x, name)(*args)
        except xmlrpc.client.Fault:
            if alt:
                return getattr(self.x, alt)(*args)
            raise

    def identify(self):
        try:
            name = str(self.x.rig.get_xcvr() or "").strip()
        except OSError as e:
            raise OSError("Flrig isn't running or not reachable") from e
        return f"{name or 'radio'} via Flrig"

    def poll(self):
        try:
            hz = float(self._call("rig.get_vfo", alt="rig.get_vfoA"))
        except (OSError, ValueError):
            return None
        try:
            mode = norm_rig_mode(str(self._call("rig.get_mode")))
        except Exception:  # noqa: BLE001
            mode = None
        return (hz / 1000.0, mode) if hz > 0 else None

    def apply(self, khz, mode):
        if khz:
            self._call("rig.set_vfo", float(int(round(khz * 1000))), alt="rig.set_vfoA")
        if mode:
            if self.modes is None:
                try:
                    self.modes = [str(m) for m in self._call("rig.get_modes")]
                except Exception:  # noqa: BLE001
                    self.modes = []
            have = {m.upper(): m for m in self.modes}
            for want in rig_mode_wants(mode, khz or 14000):
                if want in have:
                    self._call("rig.set_mode", have[want])
                    break


class RigctldCat(RigBase):
    HAMLIB = {"SSB": None, "CW": "CW", "AM": "AM", "FM": "FM", "RTTY": "RTTY",
              "FT8": "PKTUSB", "FT4": "PKTUSB", "PSK31": "PKTUSB"}

    def __init__(self, host, port, on_update, on_status):
        super().__init__(on_update, on_status)
        self.host, self.port = host or "127.0.0.1", int(port or 4532)
        self.where = f"rigctld at {self.host}:{self.port}"
        self.s = None
        self.f = None

    def open(self):
        try:
            self.s = socket.create_connection((self.host, self.port), timeout=3)
        except OSError as e:
            raise OSError("rigctld isn't running or not reachable") from e
        self.f = self.s.makefile("rwb", buffering=0)

    def close(self):
        if self.s:
            self.s.close()

    def _ask(self, cmd, lines=1):
        self.s.sendall((cmd + "\n").encode("ascii"))
        out = []
        for _ in range(lines):
            ln = self.f.readline().decode("ascii", "ignore").strip()
            out.append(ln)
            if ln.startswith("RPRT"):
                break
        return out

    def identify(self):
        r = self.poll()
        return "radio via rigctld" if r else None

    def poll(self):
        f = self._ask("f")
        if not f or not f[0].lstrip("-").isdigit():
            return None
        m = self._ask("m", 2)
        return int(f[0]) / 1000.0, norm_rig_mode(m[0] if m else "")

    def apply(self, khz, mode):
        if khz:
            self._ask(f"F {int(round(khz * 1000))}")
        if mode in self.HAMLIB:
            name = self.HAMLIB[mode] or ("USB" if _usb(khz or 14000) else "LSB")
            self._ask(f"M {name} 0")


def make_rig(d, port, baud, drop, on_update, on_status):
    """Build the right driver from the saved settings."""
    key, _label, drv, _b, addr = rig_type(d.get("rig_type") or "yaesu")
    if drv == "flrig":
        return FlrigCat(d.get("rig_host"), d.get("rig_net_port") or "12345", on_update, on_status)
    if drv == "rigctld":
        return RigctldCat(d.get("rig_host"), d.get("rig_net_port") or "4532", on_update, on_status)
    if drv == "icom":
        try:
            addr = int(str(d.get("civ_addr") or "").strip().rstrip("hH"), 16)
        except ValueError:
            pass
        return IcomCat(port, baud, drop, addr or 0x94, on_update, on_status)
    if drv == "yaesu_old":
        return YaesuOldCat(port, baud, drop, on_update, on_status)
    return YaesuCat(port, baud, drop, on_update, on_status)


# ================================================================ QRZ Logbook, WSJT-X and other loggers

WSJTX_MAGIC = 0xADBCCBDA


def wsjtx_parse(data):
    """Decode a WSJT-X UDP datagram. Returns (msg_type, id, payload_bytes) or None."""
    import struct
    if len(data) < 12:
        return None
    magic, _schema, mtype = struct.unpack(">III", data[:12])
    if magic != WSJTX_MAGIC:
        return None
    pos = 12

    def qstr():
        nonlocal pos
        (n,) = struct.unpack(">I", data[pos:pos + 4])
        pos += 4
        if n == 0xFFFFFFFF:
            return ""
        s = data[pos:pos + n].decode("utf-8", "replace")
        pos += n
        return s
    try:
        ident = qstr()
        if mtype == 12:  # Logged ADIF: the whole QSO as ADIF text
            return mtype, ident, qstr()
        return mtype, ident, None
    except Exception:  # noqa: BLE001
        return None


def wsjtx_decode_fields(data):
    """Decode WSJT-X Status (1) and Decode (2) messages into dicts. Returns (type, dict) or None."""
    import struct
    if len(data) < 12:
        return None
    magic, _schema, mtype = struct.unpack(">III", data[:12])
    if magic != WSJTX_MAGIC or mtype not in (1, 2):
        return None
    pos = 12

    def take(fmt):
        nonlocal pos
        size = struct.calcsize(fmt)
        v = struct.unpack(fmt, data[pos:pos + size])
        pos += size
        return v[0]

    def qstr():
        nonlocal pos
        n = take(">I")
        if n == 0xFFFFFFFF:
            return ""
        s = data[pos:pos + n].decode("utf-8", "replace")
        pos += n
        return s
    try:
        ident = qstr()
        if mtype == 1:  # Status: dial frequency, mode, DX call ...
            dial = take(">Q")
            mode = qstr()
            dx_call = qstr()
            d = {"id": ident, "dial_hz": dial, "mode": mode, "dx_call": dx_call, "de_grid": ""}
            try:  # report, tx mode, tx enabled, transmitting, decoding, rx df, tx df, DE call, DE grid
                qstr(), qstr(), take(">B"), take(">B"), take(">B"), take(">I"), take(">I"), qstr()
                g = qstr().strip()
                d["de_grid"] = g if _GRID_RE.match(g) else ""
            except Exception:  # noqa: BLE001 - older WSJT-X
                pass
            return 1, d
        d = {"id": ident, "new": bool(take(">B")), "time": take(">I"), "snr": take(">i"), "dt": take(">d"),
             "df": take(">I"), "mode": qstr(), "message": qstr()}
        try:
            d["low_conf"] = bool(take(">B"))
            d["off_air"] = bool(take(">B"))
        except Exception:  # noqa: BLE001 - older WSJT-X versions stop here
            d["low_conf"], d["off_air"] = False, False
        return 2, d
    except Exception:  # noqa: BLE001
        return None


def wsjtx_reply_packet(d):
    """WSJT-X 'Reply' (type 4): makes WSJT-X answer the station in this decode, as if you double-clicked it."""
    import struct

    def qstr(s):
        b = (s or "").encode("utf-8")
        return struct.pack(">I", len(b)) + b
    return (struct.pack(">III", WSJTX_MAGIC, 2, 4) + qstr(d["id"]) + struct.pack(">I", d["time"])
            + struct.pack(">i", d["snr"]) + struct.pack(">d", d["dt"]) + struct.pack(">I", d["df"])
            + qstr(d["mode"]) + qstr(d["message"]) + struct.pack(">B", 1 if d.get("low_conf") else 0)
            + struct.pack(">B", 0))


_GRID_RE = re.compile(r"^[A-R]{2}\d{2}([a-x]{2})?$", re.I)
_CALL_TOKEN = re.compile(r"^[A-Z0-9/]*\d[A-Z0-9/]*$")
OTA_WORDS = {"POTA", "SOTA", "WWFF", "GMA", "BOTA", "WWBOTA", "LLOTA", "IOTA", "COTA"}


def parse_ft_message(msg):
    """Who is sending this FT8/FT4 message? -> dict(call, to, grid, cq, cq_word) or None."""
    t = [x for x in (msg or "").upper().split() if x]
    if not t:
        return None
    if t[0] == "CQ" or t[0].startswith("CQ_"):
        rest = t[1:]
        word = t[0][3:] if t[0].startswith("CQ_") else ""
        if rest and not _CALL_TOKEN.match(rest[0].strip("<>")) and len(rest) > 1:
            word, rest = rest[0], rest[1:]  # CQ POTA K5ABC EM15
        if not rest:
            return None
        call = rest[0].strip("<>")
        grid = rest[1] if len(rest) > 1 and _GRID_RE.match(rest[1]) and rest[1] != "RR73" else ""
        return {"call": call, "to": "CQ " + word if word else "CQ", "grid": grid, "cq": True, "cq_word": word}
    if len(t) >= 2:
        frm = t[1].strip("<>")
        if not _CALL_TOKEN.match(frm):
            return None
        grid = t[2] if len(t) > 2 and _GRID_RE.match(t[2]) and t[2] != "RR73" else ""
        return {"call": frm, "to": t[0].strip("<>"), "grid": grid, "cq": False, "cq_word": ""}
    return None


# ---------------------------------------------------------------- live spots (internet)

SPOT_SOURCES = {
    "POTA": "https://api.pota.app/spot/activator",
    "SOTA": "https://api2.sota.org.uk/api/spots/60/all",
    "WWFF": "https://spots.wwff.co/static/spots.json",
    "DX": "https://www.dxsummit.fi/api/v1/spots?limit=100",
}


def _spot_mode(m, khz=0):
    m = (m or "").strip().upper()
    if m in ("USB", "LSB", "SSB", "PHONE"):
        return "SSB"
    if m in ("CW", "FT8", "FT4", "FM", "AM", "RTTY", "PSK31"):
        return m
    if m.startswith("FT8"):
        return "FT8"
    if m in ("DATA", "DIGI", "DIGITAL", "JS8", "OLIVIA"):
        return "DATA"
    return m


def _utc_ts(s):
    """'2026-10-23T13:05:12' (UTC, maybe without Z) or epoch seconds -> epoch seconds."""
    if s in (None, ""):
        return 0
    if isinstance(s, (int, float)) or str(s).isdigit():
        return float(s)
    try:
        t = str(s).replace("Z", "").replace(" ", "T")[:19]
        return datetime.strptime(t, "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc).timestamp()
    except ValueError:
        return 0


def _dx_mode_guess(info, khz):
    u = (info or "").upper()
    for m in ("FT8", "FT4", "CW", "SSB", "RTTY", "FM", "JS8"):
        if re.search(r"\b" + m + r"\b", u):
            return _spot_mode(m)
    for f in (1840, 3573, 7074, 10136, 14074, 18100, 21074, 24915, 28074, 50313):
        if abs(khz - f) < 3:
            return "FT8"
    return ""


def fetch_spots(programs):
    """Live spots from each program's own feed -> (list of dicts, list of problems). Runs in a thread."""
    out, problems = [], []
    for prog in programs:
        url = SPOT_SOURCES.get(prog)
        if not url:
            continue
        try:
            data = json.loads(_text(_download(url, timeout=15)))
        except Exception as e:  # noqa: BLE001
            problems.append(f"{prog}: {e}")
            continue
        if isinstance(data, dict):
            data = data.get("spots") or data.get("data") or []
        for s in data if isinstance(data, list) else []:
            try:
                if prog == "POTA":
                    khz = float(s.get("frequency") or 0)
                    sp = {"call": s.get("activator", ""), "ref": s.get("reference", ""), "khz": khz,
                          "mode": _spot_mode(s.get("mode"), khz), "name": s.get("name") or s.get("locationDesc", ""),
                          "where": s.get("locationDesc", ""), "note": (s.get("comments") or "").strip(),
                          "ts": _utc_ts(s.get("spotTime"))}
                elif prog == "SOTA":
                    khz = float(s.get("frequency") or 0) * 1000  # SOTA gives MHz
                    ref = "/".join(x for x in (s.get("associationCode"), s.get("summitCode")) if x)
                    sp = {"call": s.get("activatorCallsign", ""), "ref": ref, "khz": khz,
                          "mode": _spot_mode(s.get("mode"), khz), "name": s.get("summitDetails", "") or "",
                          "where": "", "note": (s.get("comments") or "").strip(), "ts": _utc_ts(s.get("timeStamp"))}
                    if isinstance(sp["name"], dict):
                        sp["name"] = sp["name"].get("name", "")
                elif prog == "WWFF":
                    khz = float(s.get("frequency_khz") or 0)
                    sp = {"call": s.get("activator", ""), "ref": s.get("reference", ""), "khz": khz,
                          "mode": _spot_mode(s.get("mode"), khz), "name": s.get("reference_name", ""), "where": "",
                          "note": (s.get("remarks") or "").strip(), "ts": _utc_ts(s.get("spot_time"))}
                else:  # DX cluster
                    khz = float(s.get("frequency") or 0)
                    info = (s.get("info") or "").strip()
                    sp = {"call": s.get("dx_call", ""), "ref": "", "khz": khz, "mode": _dx_mode_guess(info, khz),
                          "name": "", "where": "", "note": info, "ts": _utc_ts(s.get("time"))}
            except (TypeError, ValueError):
                continue
            sp["call"] = (sp["call"] or "").strip().upper()
            if not sp["call"] or not sp["khz"]:
                continue
            if re.search(r"\bQRT\b", sp["note"].upper()):
                continue  # they've stopped
            sp["prog"] = prog
            sp["band"] = band_for(sp["khz"])
            out.append(sp)
    # newest spot per station + reference
    best = {}
    for sp in out:
        k = (sp["call"], sp["ref"] or sp["band"])
        if k not in best or sp["ts"] > best[k]["ts"]:
            best[k] = sp
    return sorted(best.values(), key=lambda x: -x["ts"]), problems


def wsjtx_logged_adif_packet(adif, ident="RawHamLite"):
    """Build a WSJT-X 'Logged ADIF' datagram (what many loggers listen for)."""
    import struct

    def qstr(s):
        b = s.encode("utf-8")
        return struct.pack(">I", len(b)) + b
    return struct.pack(">III", WSJTX_MAGIC, 2, 12) + qstr(ident) + qstr(adif)


def adif_records(text):
    """Split an ADIF string into single-record strings (each ending in <EOR>)."""
    body = re.split(r"<eoh>", text, flags=re.I)[-1]
    return [r.strip() + " <EOR>" for r in re.split(r"<eor>", body, flags=re.I) if r.strip()]


class QRZLogbook:
    """QRZ Logbook API (uses the Logbook API key, not the XML login)."""
    URL = "https://logbook.qrz.com/api"

    def __init__(self, key):
        self.key = key.strip()

    def _post(self, **fields):
        import html
        body = urllib.parse.urlencode({"KEY": self.key, **fields}).encode()
        req = urllib.request.Request(self.URL, data=body, method="POST", headers={
            "User-Agent": f"RawHamsLiteLogger/{VERSION}",
            "Content-Type": "application/x-www-form-urlencoded"})
        with urllib.request.urlopen(req, timeout=60) as r:
            text = r.read().decode("utf-8", "replace")
        parsed = urllib.parse.parse_qs(html.unescape(text), keep_blank_values=True)
        return {k.upper(): v[0] for k, v in parsed.items()}

    def status(self):
        return self._post(ACTION="STATUS")

    def fetch_page(self, after_logid=0, page=250):
        res = self._post(ACTION="FETCH", OPTION=f"MAX:{page},AFTERLOGID:{after_logid}")
        if res.get("RESULT") not in ("OK",):
            reason = res.get("REASON", "")
            if res.get("COUNT") == "0" or "no log" in reason.lower() or "0 record" in reason.lower():
                return []
            raise QRZError(reason or "QRZ Logbook FETCH failed")
        import html
        return list(parse_adif("<EOH>" + html.unescape(res.get("ADIF", ""))))

    def insert(self, adif_record, replace=False):
        res = self._post(ACTION="INSERT", ADIF=adif_record, **({"OPTION": "REPLACE"} if replace else {}))
        result = res.get("RESULT", "")
        reason = res.get("REASON", "")
        if result in ("OK", "REPLACE"):
            return "ok", ""
        if "duplicate" in reason.lower():
            return "dupe", reason
        return "fail", reason or "unknown error"


# ================================================================ editing & past activations

def adif_record_text(rec):
    """dict (upper-case ADIF fields, in order) -> one ADIF record string."""
    return "".join(_f(k, v) for k, v in rec.items() if v != "" and v is not None) + "<EOR>"


def read_adif_file(path):
    with open(path, "rb") as fh:
        raw = fh.read()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
    m = re.search(r"<eoh>", text, re.I)
    header = text[:m.start()] if m else ""
    return header, list(parse_adif(text))


def write_adif_file(path, header, recs):
    head = header.rstrip() or f"{APP} ADIF"
    if "<ADIF_VER" not in head.upper():
        head += "\n" + _f("ADIF_VER", "3.1.4")
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(head + " <EOH>\n\n" + "\n".join(adif_record_text(r) for r in recs) + "\n")


def _adif_keys(recs):
    """Which contacts a file holds (call, date, time) - to spot the same activation saved for each park of a two-fer."""
    return {((r.get("CALL") or "").strip().upper(), (r.get("QSO_DATE") or "").strip(), (r.get("TIME_ON") or "").strip())
            for r in recs}


def _add_ref(refs, r):
    if r[1] and all(x[1] != r[1] for x in refs):
        refs.append(r)


def _my_refs(r):
    """MY_SIG / MY_SOTA_REF / MY_WWFF_REF -> [[prog, ref]] - where this contact was made from."""
    out = []
    if (r.get("MY_SOTA_REF") or "").strip():
        _add_ref(out, ["SOTA", r["MY_SOTA_REF"].strip().upper()])
    info = (r.get("MY_SIG_INFO") or "").strip().upper()
    if info:
        _add_ref(out, [(r.get("MY_SIG") or "").strip().upper() or guess_program(info) or "", info])
    if (r.get("MY_WWFF_REF") or "").strip():
        _add_ref(out, ["WWFF", r["MY_WWFF_REF"].strip().upper()])
    return out


def qsos_from_adif(recs, my_call):
    """A saved file back into contacts (Past activations > Continue). A P2P with several parks was saved as one
    record per park - it comes back as one contact."""
    me = base_call(my_call or "")
    out = []
    for r in recs:
        call = (r.get("CALL") or "").strip().upper()
        if not call:
            continue
        khz = parse_freq_khz(r.get("FREQ") or "") or 0
        their = []
        sig = (r.get("SIG") or "").strip().upper()
        for x in re.split(r"\s*,\s*", (r.get("SIG_INFO") or "").upper()):
            if x.strip():
                _add_ref(their, [sig or guess_program(x.strip()) or "", x.strip()])
        if (r.get("SOTA_REF") or "").strip():
            _add_ref(their, ["SOTA", r["SOTA_REF"].strip().upper()])
        if (r.get("WWFF_REF") or "").strip():
            _add_ref(their, ["WWFF", r["WWFF_REF"].strip().upper()])
        refs = _my_refs(r)
        q = {"call": call, "date": (r.get("QSO_DATE") or "").strip(), "time": (r.get("TIME_ON") or "").strip()[:4],
             "freq_khz": khz, "band": (r.get("BAND") or "").strip().lower() or band_for(khz),
             "mode": norm_mode(r.get("MODE"), r.get("SUBMODE")),
             "rst_s": (r.get("RST_SENT") or "").strip(), "rst_r": (r.get("RST_RCVD") or "").strip(),
             "state": (r.get("STATE") or "").strip().upper(), "country": clean_text(r.get("COUNTRY"), 60),
             "their": their, "refs": refs, "name": (r.get("NAME") or "").strip(),
             "comment": clean_text(r.get("COMMENT"))}
        if not refs and fmt_grid(r.get("MY_GRIDSQUARE")):
            q["my_grid"] = fmt_grid(r.get("MY_GRIDSQUARE"))
        if _GRID_RE.match((r.get("GRIDSQUARE") or "").strip()):
            q["grid"] = fmt_grid(r.get("GRIDSQUARE"))
        sc = (r.get("STATION_CALLSIGN") or "").strip().upper()
        if sc and base_call(sc) != me:
            q["station_call"] = sc
        op = (r.get("OPERATOR") or "").strip().upper()
        if op and op != me:
            q["operator"] = op
        prev = out[-1] if out else None
        if prev and their and prev["their"] and all(prev[k] == q[k] for k in ("call", "date", "time", "band", "mode")):
            for t in their:
                _add_ref(prev["their"], t)
            continue
        out.append(q)
    return out


def _log_error(exc=None):
    """Write the error (the current one, or exc = (type, value, traceback)) to error.log in the data folder,
    kept small, so a bug report can include it."""
    try:
        path = os.path.join(DATA_DIR, "error.log")
        if os.path.exists(path) and os.path.getsize(path) > 200_000:
            os.replace(path, path + ".old")
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(f"--- {datetime.now():%Y-%m-%d %H:%M:%S}  {APP} {VERSION}\n{''.join(traceback.format_exception(*exc)) if exc else traceback.format_exc()}\n")
    except Exception:  # noqa: BLE001
        pass


def aclog_send_records(host, port, records):
    """Add ADIF records to ACLog over its TCP API. -> (number sent, error or None)"""
    sent = 0
    try:
        with socket.create_connection((host, port), timeout=5) as s:
            s.settimeout(2)
            for adif in records:
                s.sendall(f"<CMD><ADDADIFRECORD><VALUE>{adif}</VALUE></CMD>\r\n".encode("utf-8"))
                sent += 1
                time.sleep(0.15)
            s.sendall(b"<CMD><CHECKLOG></CMD>\r\n")
            time.sleep(0.3)
            s.sendall(b"\r\n")
        return sent, None
    except ConnectionRefusedError:
        return sent, ("ACLog isn't accepting connections. Open ACLog, then check Settings > "
                      "Application Program Interface > 'TCP API Enabled' (port 1100).")
    except OSError as e:
        return sent, f"Couldn't reach ACLog: {e}"


class QsoEditor:
    """A small window with every field of one contact. Nothing changes until Save."""

    def __init__(self, app, title, fields, on_save):
        self.app, self.on_save = app, on_save
        self.w = w = tk.Toplevel(app.root)
        w.title(title)
        w.transient(app.root)
        w.resizable(False, False)
        fr = ttk.Frame(w, padding=12)
        fr.grid()
        self.vars = {}
        for i, (key, label, value, choices) in enumerate(fields):
            r, c = divmod(i, 2)
            ttk.Label(fr, text=label).grid(row=r, column=c * 2, sticky="w", padx=(0 if c == 0 else 14, 6), pady=3)
            var = tk.StringVar(value=value)
            if choices:
                wdg = ttk.Combobox(fr, textvariable=var, values=choices, width=14)
            else:
                wdg = ttk.Entry(fr, textvariable=var, width=18 if key not in ("their", "refs") else 24,
                                font=app.mono)
            wdg.grid(row=r, column=c * 2 + 1, sticky="w", pady=3)
            self.vars[key] = var
            if i == 0:
                wdg.focus_set()
        self.msg = ttk.Label(fr, text="", foreground=col("#c0392b"))
        self.msg.grid(row=50, column=0, columnspan=4, sticky="w", pady=(6, 0))
        b = ttk.Frame(fr)
        b.grid(row=51, column=0, columnspan=4, sticky="e", pady=(8, 0))
        ttk.Button(b, text="Save", command=self.save).grid(row=0, column=0, padx=4)
        ttk.Button(b, text="Cancel", command=w.destroy).grid(row=0, column=1)
        w.bind("<Return>", lambda e: self.save())
        w.bind("<Escape>", lambda e: w.destroy())
        w.grab_set()

    def save(self):
        vals = {k: v.get().strip() for k, v in self.vars.items()}
        err = self.on_save(vals)
        if err:
            self.msg.config(text=err)
        else:
            self.w.destroy()


def check_qso_fields(vals):
    """Shared checks for the edit window. Returns an error message or None."""
    if not vals["call"]:
        return "Call can't be empty."
    if not re.fullmatch(r"\d{8}", vals["date"]):
        return "Date must look like 20261018 (YYYYMMDD)."
    if not re.fullmatch(r"\d{4}(\d{2})?", vals["time"]):
        return "Time must look like 1530 (HHMM, UTC)."
    khz = parse_freq_khz(vals["freq"])
    if not khz or not band_for(khz):
        return "Frequency isn't in a ham band (e.g. 14250 or 14.250)."
    for key, label in (("their", "Their ref"), ("refs", "My ref")):
        if key in vals:
            bad = [r for p, r in parse_refs(vals[key]) if not p]
            if bad:
                return f"{label}: which program is {', '.join(bad)}? Put e.g. GMA: or LLOTA: in front."
    if "refs" in vals and not parse_refs(vals["refs"]):
        return "My ref(s) can't be empty."
    if vals.get("my_grid", "").strip() and not _GRID_RE.match(vals["my_grid"].strip()):
        return "My grid should look like EM15 or EM15ab."
    return None


def fmt_grid(g):
    """em15AB -> EM15ab (the usual way grids are written); anything that isn't a grid -> ''."""
    g = (g or "").strip()
    if not _GRID_RE.match(g):
        return ""
    return g[:2].upper() + g[2:4] + g[4:6].lower()


def refs_text(refs):
    return ", ".join(r if guess_program(r) == p else f"{p}:{r}" for p, r in refs)


# ================================================================ log of choice (LOC)

LOC_TYPES = [  # key, label, default port, short name
    ("none", "None", "", "your log"),
    ("n3fjp", "N3FJP ACLog (or any N3FJP logger)", "1100", "ACLog"),
    ("log4om", "Log4OM 2", "2237", "Log4OM"),
    ("hrd", "HRD Logbook", "2333", "HRD"),
    ("dxkeeper", "DXLab DXKeeper", "52001", "DXKeeper"),
    ("wavelog", "Wavelog / Cloudlog (web)", "", "Wavelog"),
    ("udp_wsjtx", "Other logger - WSJT-X UDP (GridTracker, MacLoggerDX ...)", "2237", "your logger"),
    ("udp_adif", "Other logger - ADIF over UDP", "2333", "your logger"),
]
LOC_HINTS = {
    "none": "Nothing selected - Send to LOC will ask you to pick one.",
    "n3fjp": "In ACLog: Settings > Application Program Interface > tick TCP API Enabled (port 1100). "
             "Use 127.0.0.1 when ACLog is on this PC. Works the same for N3FJP's Field Day and contest loggers.",
    "log4om": "In Log4OM add a UDP inbound connection for WSJT-X/JTDX messages on this port (Connections settings). "
              "If this logger also listens to WSJT-X on the same PC, give Log4OM a different port.",
    "hrd": "In HRD Logbook turn on QSO Forwarding and receive UDP on port 2333.",
    "dxkeeper": "In DXKeeper: Configuration > Defaults > turn on the Network Service. It listens on the Base Port + 1 "
                "(52001 when the base is 52000). Turn off DXKeeper's own auto-upload to QRZ/Club Log to avoid doubles.",
    "wavelog": "Your Wavelog or Cloudlog site address, an API key with write access (Account > API Keys) and the "
               "station location number (Station Locations - the number at the end of its Edit link).",
    "udp_wsjtx": "For loggers that accept WSJT-X \"Logged ADIF\" messages. Use the UDP port your logger listens on.",
    "udp_adif": "For loggers that take a raw ADIF record over UDP.",
}
LOC_KEYS = [t[0] for t in LOC_TYPES]


def _dxf(name, value):
    return f"<{name}:{len(value.encode('utf-8'))}>{value}"


def dxkeeper_send(host, port, records):
    """DXLab DXKeeper network service: one 'externallog' directive per connection; it never replies."""
    for rec in records:
        body = re.sub(r"<eor>\s*$", "", rec.strip(), flags=re.I).strip() + "<EOR>"
        params = _dxf("ExternalLogADIF", body)
        params += "".join(_dxf(f, "N") for f in ("UploadeQSL", "UploadLoTW", "UploadClubLog", "UploadQRZ"))
        params += "".join(_dxf(f, "Y") for f in ("DeduceMissing", "QueryCallbook", "CheckOverrides"))
        msg = _dxf("command", "externallog") + _dxf("parameters", params)
        try:
            with socket.create_connection((host, port), timeout=4) as s:
                s.sendall(msg.encode("utf-8"))
                time.sleep(0.25)  # DXKeeper closes and reopens its port after every directive
        except OSError as e:
            return (f"Couldn't reach DXKeeper at {host}:{port}. In DXKeeper turn on the Network Service "
                    f"(Configuration > Defaults); it listens on the Base Port + 1, 52001 by default. ({e})")
    return None


def udp_send_records(host, port, records, wsjtx_format):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            for rec in records:
                s.sendto(wsjtx_logged_adif_packet(rec) if wsjtx_format else rec.encode("utf-8"), (host, port))
                time.sleep(0.05)
        return None
    except OSError as e:
        return f"Couldn't send to your logger: {e}"


def wavelog_url(site, call):
    base = site.strip().rstrip("/")
    if not re.match(r"(?i)https?://", base):
        base = "https://" + base
    base = re.sub(r"(?i)/api/[a-z_]+$", "", base)
    if not base.lower().endswith("/index.php"):
        base += "/index.php"
    return f"{base}/api/{call}"


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):  # never carry the API key to another address
        return None


def _wavelog_post(site, call, payload, timeout=60):
    req = urllib.request.Request(wavelog_url(site, call), data=json.dumps(payload).encode("utf-8"), method="POST",
                                 headers={"Content-Type": "application/json", "User-Agent": f"RawHamsLiteLogger/{VERSION}"})
    opener = urllib.request.build_opener(_NoRedirect)
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def wavelog_send(site, key, station, records):
    if not key.strip():
        return "Wavelog/Cloudlog: enter your API key in Settings."
    if not station.strip().isdigit():
        return ("Wavelog/Cloudlog: the station ID must be the station location number "
                "(Station Locations - the number at the end of that location's Edit link).")
    for rec in records:
        try:
            code, body = _wavelog_post(site, "qso", {"key": key.strip(), "station_profile_id": station.strip(),
                                                     "type": "adif", "string": rec}, timeout=20)
        except Exception as e:  # noqa: BLE001
            return f"Couldn't reach your Wavelog/Cloudlog site: {e}"
        if code in (401, 403):
            return f"Wavelog/Cloudlog refused the API key or station ID (HTTP {code})."
        if not 200 <= code < 300:
            return f"Wavelog/Cloudlog answered HTTP {code}. Check the site address."
        t = body.lower().replace(" ", "")
        if '"status":"failed"' in t or '"status":"error"' in t:
            m = re.search(r'"reason"\s*:\s*"([^"]*)"', body)
            return "Wavelog/Cloudlog rejected a QSO" + (f": {m.group(1)}" if m else "")
    return None


def wavelog_fetch(site, key, station, from_id):
    """One batch of contacts from Wavelog/Cloudlog -> (records, last_id)."""
    code, body = _wavelog_post(site, "get_contacts_adif",
                               {"key": key.strip(), "station_id": station.strip(), "fetchfromid": from_id}, timeout=120)
    try:
        r = json.loads(body)
    except ValueError:
        raise IOError(f"Wavelog/Cloudlog answered HTTP {code} - check the site address")
    if r.get("status") != "successful":
        raise IOError("Wavelog/Cloudlog: " + str(r.get("reason") or f"HTTP {code}"))
    adif = r.get("adif") or ""
    recs = list(parse_adif(adif if "<eoh>" in adif.lower() else "<EOH>" + adif)) if adif else []
    return recs, int(r.get("lastfetchedid") or from_id)


def _n3fjp_date(d):
    p = re.split(r"[/\-. ]+", d.strip())
    if len(p) >= 3 and len(p[2]) == 4 and p[0].isdigit() and p[1].isdigit():
        return f"{p[2]}{int(p[0]):02d}{int(p[1]):02d}"
    dg = re.sub(r"\D", "", d)
    return dg[:8]


def n3fjp_list(host, port):
    """Every contact in an N3FJP log over its TCP API (<CMD><LIST></CMD>), as ADIF-style dicts."""
    buf = b""
    with socket.create_connection((host, port), timeout=5) as s:
        s.settimeout(5)
        s.sendall(b"<CMD><LIST></CMD>\r\n")
        deadline = time.time() + 300
        while time.time() < deadline:
            try:
                chunk = s.recv(65536)
            except socket.timeout:
                break  # quiet for 5 s - everything has arrived
            if not chunk:
                break
            buf += chunk
        try:
            s.sendall(b"\r\n")
        except OSError:
            pass
    out = []
    for inner in re.findall(r"<CMD>(.*?)</CMD>", buf.decode("utf-8", "replace"), re.S | re.I):
        if not inner.strip().upper().startswith("<LIST"):
            continue
        raw = {re.sub(r"^(FLD|TXTENTRY)", "", k.upper()): v.strip()
               for k, v in re.findall(r"<([A-Za-z0-9_]+)>([^<]*)</\1>", inner)}

        def first(*keys):
            return next((raw[k] for k in keys if raw.get(k)), "")
        call = first("CALL").upper()
        if not call:
            continue
        band = first("BAND").lower()
        if re.fullmatch(r"\d+(\.\d+)?", band):
            band += "m"
        mode = first("MODE").upper()
        out.append({"CALL": call, "QSO_DATE": _n3fjp_date(first("DATE", "DATEON", "QSODATE", "DATESTR")),
                    "TIME_ON": re.sub(r"\D", "", first("TIMEON", "TIME", "TIMEONSTR"))[:4], "BAND": band,
                    "MODE": "SSB" if mode == "PH" else mode, "NAME": first("NAMEF", "NAME", "FIRSTNAME"),
                    "STATE": first("STATE"), "COMMENT": first("COMMENTS", "COMMENT", "NOTES")})
    return out


# ================================================================ offline callbook (like ACLog's Calldata)

FCC_URL = "https://data.fcc.gov/download/pub/uls/complete/l_amat.zip"
FCC_URLS = [FCC_URL, "ftp://wirelessftp.fcc.gov/pub/uls/complete/l_amat.zip"]  # main site, then FCC's FTP server
# some government sites (the FCC) refuse anything that doesn't look like a web browser
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/130.0.0.0 Safari/537.36")
CANADA_URL = "https://apc-cap.ic.gc.ca/datafiles/amateur_delim.zip"


def _nice_name(*parts):
    """JOHN A O'NEIL-SMITH -> John A O'Neil-Smith"""
    def cap(word):
        for sep in ("-", "'"):
            word = sep.join(w[:1].upper() + w[1:] for w in word.split(sep))
        return word
    text = " ".join(p.strip() for p in parts if p and p.strip()).lower()
    return " ".join(cap(w) for w in text.split())


def download_file(url, dest, progress=None):
    """Download to a file. `url` may be a list of addresses to try in turn."""
    if isinstance(url, (list, tuple)):
        last = None
        for u in url:
            try:
                return download_file(u, dest, progress)
            except Exception as e:  # noqa: BLE001
                last = e
        raise last or OSError("no address to try")
    headers = {"User-Agent": f"RawHamsLiteLogger/{VERSION}"}
    if "fcc.gov" in url:
        headers = {"User-Agent": BROWSER_UA, "Accept": "application/zip,application/octet-stream,*/*",
                   "Accept-Language": "en-US,en;q=0.9"}
    req = urllib.request.Request(url, headers=headers) if url.startswith("http") else url
    with urllib.request.urlopen(req, timeout=60) as r, open(dest, "wb") as out:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            chunk = r.read(256 * 1024)
            if not chunk:
                break
            out.write(chunk)
            got += len(chunk)
            if progress:
                progress(got, total)


def parse_fcc_zip(path, progress=None):
    """Yield (call, name, city, state, 'USA', class) for every active US license."""
    import io
    import zipfile
    with zipfile.ZipFile(path) as z:
        names = {n.upper(): n for n in z.namelist()}
        active, classes = None, {}
        if "HD.DAT" in names:  # license status: keep only Active licenses
            active = set()
            with z.open(names["HD.DAT"]) as fh:
                for line in io.TextIOWrapper(fh, encoding="utf-8", errors="replace"):
                    f = line.split("|")
                    if len(f) > 5 and f[5] == "A":
                        active.add(f[1])
        if "AM.DAT" in names:  # operator class (E, A, G, T ...)
            with z.open(names["AM.DAT"]) as fh:
                for line in io.TextIOWrapper(fh, encoding="utf-8", errors="replace"):
                    f = line.split("|")
                    if len(f) > 5 and (active is None or f[1] in active):
                        classes[f[1]] = f[5]
        with z.open(names["EN.DAT"]) as fh:
            for n, line in enumerate(io.TextIOWrapper(fh, encoding="utf-8", errors="replace")):
                f = line.rstrip("\r\n").split("|")
                if len(f) < 18 or (active is not None and f[1] not in active):
                    continue
                call = f[4].strip().upper()
                if not call:
                    continue
                name = _nice_name(f[8], f[9], f[10], f[11]) or _nice_name(f[7])
                yield (call, name, _nice_name(f[16]), f[17].strip().upper(), "USA", classes.get(f[1], ""))
                if progress and n % 50000 == 0:
                    progress(n)


def parse_canada_zip(path):
    """Yield (call, name, city, prov, 'Canada', '') from ISED's amateur_delim file."""
    import csv
    import io
    import zipfile
    with zipfile.ZipFile(path) as z:
        member = next(n for n in z.namelist() if n.lower().endswith((".txt", ".csv")))
        text = z.read(member).decode("latin-1")
    first = text.split("\n", 1)[0]
    delim = max((";", "|", ",", "\t"), key=first.count)
    rows = csv.reader(io.StringIO(text), delimiter=delim)
    header = [h.strip().lower() for h in next(rows)]
    if any("call" in h for h in header):
        idx = {h: i for i, h in enumerate(header)}

        def col(r, *names):
            for nm in names:
                if nm in idx and idx[nm] < len(r):
                    return r[idx[nm]]
            return ""
    else:  # no header: callsign, first name, surname, address, city, province
        rows = csv.reader(io.StringIO(text), delimiter=delim)
        pos = {"callsign": 0, "first_name": 1, "surname": 2, "city": 4, "prov_cd": 5}

        def col(r, *names):
            for nm in names:
                if nm in pos and pos[nm] < len(r):
                    return r[pos[nm]]
            return ""
    for r in rows:
        call = col(r, "callsign", "call_sign", "call").strip().upper()
        if not call:
            continue
        name = _nice_name(col(r, "first_name", "given_names"), col(r, "surname", "last_name")) \
            or _nice_name(col(r, "club_name"))
        city = col(r, "city") or col(r, "club_city")
        prov = col(r, "prov_cd", "province") or col(r, "club_prov_cd")
        yield (call, name, _nice_name(city), prov.strip().upper(), "Canada", "")


# ================================================================ park & summit lists

REF_SOURCES = {
    "POTA": "https://api.pota.app/program/parks/{code}",
    "SOTA": "https://storage.sota.org.uk/summitslist.csv",
    "WWFF": "https://wwff.co/wwff-data/wwff_directory.csv",
}


def _download(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": f"RawHamsLiteLogger/{VERSION}",
                                               "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _text(raw):
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("latin-1")


def maidenhead(lat, lon, chars=6):
    """Latitude/longitude to a Maidenhead grid square (EM15ab). Returns "" if they aren't numbers."""
    try:
        lat, lon = float(lat), float(lon)
    except (TypeError, ValueError):
        return ""
    if not (-90 <= lat <= 90 and -180 <= lon <= 180) or (lat == 0 and lon == 0):
        return ""
    lon = min(lon + 180, 359.99999)
    lat = min(lat + 90, 179.99999)
    g = chr(65 + int(lon // 20)) + chr(65 + int(lat // 10))
    g += str(int(lon % 20 // 2)) + str(int(lat % 10))
    if chars >= 6:
        g += chr(97 + int(lon % 2 * 12)) + chr(97 + int(lat % 1 * 24))
    return g


def fetch_pota_parks(code):
    data = json.loads(_text(_download(REF_SOURCES["POTA"].format(code=urllib.parse.quote(code)))))
    rows = []
    for p in data:
        ref = str(p.get("reference", "")).upper().strip()
        if ref:
            grid = maidenhead(p.get("latitude"), p.get("longitude")) or str(p.get("grid") or "").strip()
            rows.append(("POTA", ref, str(p.get("name", "")).strip(), str(p.get("locationDesc", "")).strip(), grid))
    return rows


def _valid_today(valid_to):
    v = (valid_to or "").strip()
    m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", v) or re.match(r"(\d{4})-(\d{2})-(\d{2})", v)
    if not m:
        return True
    a, b, c = m.groups()
    ymd = (int(c), int(b), int(a)) if len(a) <= 2 else (int(a), int(b), int(c))
    return ymd >= utc_now().timetuple()[:3]


def fetch_sota_summits():
    import csv
    import io
    lines = _text(_download(REF_SOURCES["SOTA"])).splitlines()
    while lines and "SummitCode" not in lines[0]:  # first line is a title, not the header
        lines.pop(0)
    rows = []
    for r in csv.DictReader(io.StringIO("\n".join(lines))):
        code = (r.get("SummitCode") or "").strip().upper()
        if not code or not _valid_today(r.get("ValidTo")):
            continue
        loc = ", ".join(x for x in ((r.get("RegionName") or "").strip(),
                                    (r.get("AssociationName") or "").strip()) if x)
        rows.append(("SOTA", code, (r.get("SummitName") or "").strip(), loc,
                     maidenhead(r.get("Latitude"), r.get("Longitude"))))
    return rows


def fetch_wwff_refs():
    import csv
    import io
    rows = []
    for r in csv.DictReader(io.StringIO(_text(_download(REF_SOURCES["WWFF"])))):
        r = {(k or "").strip().lower(): (v or "").strip() for k, v in r.items()}
        ref = r.get("reference", "").upper()
        if not ref or r.get("status", "active").lower() not in ("active", ""):
            continue
        loc = ", ".join(x for x in (r.get("state", ""), r.get("region", ""), r.get("country", "")) if x)
        grid = maidenhead(r.get("latitude"), r.get("longitude")) or r.get("iarulocator", "")
        rows.append(("WWFF", ref, r.get("name", ""), loc, grid))
    return rows


def pota_program_of(ref):
    m = re.match(r"^([A-Z0-9]{1,4})-\d{4,5}$", ref)
    return m.group(1) if m else None


# ================================================================ worked-before & callbook

def base_call(call):
    """KJ5GVQ/P -> KJ5GVQ, VE3/W1AW -> W1AW (the part that identifies the person)."""
    parts = [p for p in call.upper().strip().split("/") if p]
    if not parts:
        return ""
    good = [p for p in parts if re.search(r"\d", p) and re.search(r"[A-Z]", p) and len(p) >= 3]
    return max(good or parts, key=len)


def norm_mode(mode, submode=""):
    mode, submode = (mode or "").upper(), (submode or "").upper()
    if mode in ("USB", "LSB", "SSB"):
        return "SSB"
    if mode == "MFSK" and submode:
        return submode
    if mode == "PSK" and submode:
        return submode
    if mode == "DIGITALVOICE" and submode:
        return submode
    return mode


_ADIF_TAG = re.compile(r"<([A-Za-z0-9_]+)(?::(\d+)(?::[A-Za-z])?)?>")


def parse_adif(text):
    """Yield one dict per QSO record (keys upper-case)."""
    pos = 0
    eoh = re.search(r"<eoh>", text, re.I)
    if eoh:
        pos = eoh.end()
    rec = {}
    while True:
        m = _ADIF_TAG.search(text, pos)
        if not m:
            break
        tag = m.group(1).upper()
        if tag == "EOR":
            if rec:
                yield rec
            rec, pos = {}, m.end()
            continue
        n = int(m.group(2) or 0)
        rec[tag] = text[m.end():m.end() + n]
        pos = m.end() + n


class LocalDB:
    """Worked-before history and saved QRZ lookups, in one SQLite file."""

    def __init__(self, path):
        self.lock = threading.Lock()
        self.c = sqlite3.connect(path, check_same_thread=False)
        if not IS_WIN:
            try:
                os.chmod(path, 0o600)  # owner-only: your log and saved lookups
            except OSError:
                pass
        self.c.executescript("""
            CREATE TABLE IF NOT EXISTS worked (base TEXT, call TEXT, date TEXT, time TEXT,
                band TEXT, mode TEXT, name TEXT, state TEXT, src TEXT, app_id INTEGER);
            CREATE INDEX IF NOT EXISTS worked_base ON worked(base);
            CREATE TABLE IF NOT EXISTS refs (prog TEXT, ref TEXT, name TEXT, loc TEXT,
                PRIMARY KEY (prog, ref));
            CREATE INDEX IF NOT EXISTS refs_ref ON refs(ref);
            CREATE TABLE IF NOT EXISTS offline (call TEXT PRIMARY KEY, name TEXT, city TEXT,
                state TEXT, country TEXT, cls TEXT);
            CREATE TABLE IF NOT EXISTS callbook (base TEXT PRIMARY KEY, call TEXT, name TEXT,
                qth TEXT, state TEXT, grid TEXT, country TEXT, fetched REAL);
        """)
        if "comment" not in [r[1] for r in self.c.execute("PRAGMA table_info(worked)")]:
            self.c.execute("ALTER TABLE worked ADD COLUMN comment TEXT")  # your note from that QSO (v1.10)
        if "grid" not in [r[1] for r in self.c.execute("PRAGMA table_info(refs)")]:
            self.c.execute("ALTER TABLE refs ADD COLUMN grid TEXT")  # park/summit grid square (v1.6)
        self.c.commit()

    # --- worked before
    def import_adif(self, path):
        with open(path, "rb") as fh:
            raw = fh.read()
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("latin-1")
        rows = []
        for r in parse_adif(text):
            call = r.get("CALL", "").strip().upper()
            if not call:
                continue
            rows.append((base_call(call), call, r.get("QSO_DATE", ""), r.get("TIME_ON", "")[:4],
                         r.get("BAND", "").lower(), norm_mode(r.get("MODE"), r.get("SUBMODE")),
                         r.get("NAME", "").strip(), r.get("STATE", "").strip().upper(), "adif", None,
                         clean_text(r.get("COMMENT") or r.get("NOTES") or "")))
        with self.lock:
            self.c.execute("DELETE FROM worked WHERE src='adif'")  # re-import replaces the old copy
            self.c.executemany("INSERT INTO worked (base, call, date, time, band, mode, name, state, src, app_id, comment) VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows)
            self.c.commit()
        return len(rows)

    def add_worked_rows(self, recs, src):
        rows = []
        for r in recs:
            call = r.get("CALL", "").strip().upper()
            if call:
                rows.append((base_call(call), call, r.get("QSO_DATE", ""), r.get("TIME_ON", "")[:4],
                             r.get("BAND", "").lower(), norm_mode(r.get("MODE"), r.get("SUBMODE")),
                             r.get("NAME", "").strip(), r.get("STATE", "").strip().upper(), src, None,
                             clean_text(r.get("COMMENT") or r.get("NOTES") or "")))
        with self.lock:
            self.c.executemany("INSERT INTO worked (base, call, date, time, band, mode, name, state, src, app_id, comment) VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows)
            self.c.commit()
        return len(rows)

    def clear_worked(self, src):
        with self.lock:
            self.c.execute("DELETE FROM worked WHERE src=?", (src,))
            self.c.commit()

    def worked_count(self, src):
        with self.lock:
            return self.c.execute("SELECT COUNT(*) FROM worked WHERE src=?", (src,)).fetchone()[0]

    def adif_count(self):
        with self.lock:
            return self.c.execute("SELECT COUNT(*) FROM worked WHERE src='adif'").fetchone()[0]

    def add_app_qso(self, q):
        with self.lock:
            if self.c.execute("SELECT 1 FROM worked WHERE src='app' AND app_id=?", (q["id"],)).fetchone():
                return
            self.c.execute("INSERT INTO worked (base, call, date, time, band, mode, name, state, src, app_id, comment) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                           (base_call(q["call"]), q["call"], q["date"], q["time"], q["band"], q["mode"],
                            q.get("name", ""), q.get("state", ""), "app", q["id"], clean_text(q.get("comment", ""))))
            self.c.commit()

    def drop_app_like(self, q):
        """Continue a past activation: the worked-before row from when it was first logged goes, so nothing counts twice."""
        with self.lock:
            self.c.execute("DELETE FROM worked WHERE src='app' AND call=? AND date=? AND substr(time,1,4)=? AND band=?",
                           (q["call"], q["date"], q["time"][:4], q["band"]))
            self.c.commit()

    def delete_app_qsos(self, ids):
        with self.lock:
            self.c.executemany("DELETE FROM worked WHERE src='app' AND app_id=?", [(i,) for i in ids])
            self.c.commit()

    def worked(self, base, band, mode):
        """-> (total, last (date,time,band,mode) or None, worked_on_this_band_mode, name, state)"""
        with self.lock:
            rows = self.c.execute("SELECT date, time, band, mode, name, state FROM worked "
                                  "WHERE base=? ORDER BY date DESC, time DESC", (base,)).fetchall()
        seen, uniq = set(), []
        for r in rows:  # a QSO sent to ACLog shows up twice; count it once
            k = (r[0], (r[1] or "")[:4], r[2], r[3])
            if k not in seen:
                seen.add(k)
                uniq.append(r)
        rows = uniq
        if not rows:
            return 0, None, False, "", ""
        same = any(r[2] == band and r[3] == mode for r in rows)
        name = next((r[4] for r in rows if r[4]), "")
        state = next((r[5] for r in rows if r[5]), "")
        return len(rows), rows[0][:4], same, name, state

    def last_comment(self, base):
        """Your most recent note for this station -> (comment, date) or None."""
        with self.lock:
            r = self.c.execute("SELECT comment, date FROM worked WHERE base=? AND comment IS NOT NULL AND comment != '' "
                               "ORDER BY date DESC, time DESC LIMIT 1", (base,)).fetchone()
        return (r[0], r[1]) if r else None

    def unique_calls(self):
        with self.lock:
            return [r[0] for r in self.c.execute("SELECT DISTINCT base FROM worked")]

    # --- park / summit lists
    def replace_refs(self, prog, rows, ref_prefix=None):
        with self.lock:
            if ref_prefix:
                self.c.execute("DELETE FROM refs WHERE prog=? AND ref LIKE ?", (prog, ref_prefix + "-%"))
            else:
                self.c.execute("DELETE FROM refs WHERE prog=?", (prog,))
            rows = [tuple(r[:5]) + ("",) * (5 - len(r[:5])) for r in rows]
            self.c.executemany("INSERT OR REPLACE INTO refs (prog, ref, name, loc, grid) VALUES (?,?,?,?,?)", rows)
            self.c.commit()

    def ref_get(self, prog, ref):
        if ref == "K-TEST":
            return {"name": "POTA test park", "loc": ""}
        with self.lock:
            r = self.c.execute("SELECT name, loc FROM refs WHERE prog=? AND ref=?", (prog, ref)).fetchone()
        return {"name": r[0], "loc": r[1]} if r else None

    def ref_grid(self, prog, ref):
        """The park's / summit's grid square from the saved lists, or ''."""
        with self.lock:
            r = self.c.execute("SELECT grid FROM refs WHERE prog=? AND ref=?", (prog, ref)).fetchone()
        return (r[0] or "") if r else ""

    def refs_have_grids(self):
        with self.lock:
            return bool(self.c.execute("SELECT 1 FROM refs WHERE grid IS NOT NULL AND grid != '' LIMIT 1").fetchone())

    def ref_guess_prog(self, ref):
        """Which program(s) have this exact reference?"""
        with self.lock:
            return [r[0] for r in self.c.execute("SELECT prog FROM refs WHERE ref=?", (ref,))]

    def ref_search(self, text, limit=60):
        t = text.strip().upper()
        if len(t) < 2:
            return []
        with self.lock:
            exact = self.c.execute("SELECT prog, ref, name, loc FROM refs WHERE ref LIKE ? "
                                   "ORDER BY ref LIMIT ?", (t + "%", limit)).fetchall()
            words = [w for w in re.split(r"\s+", t) if w]
            where = " AND ".join(["(UPPER(name) LIKE ? OR UPPER(loc) LIKE ?)"] * len(words))
            args = []
            for w in words:
                args += [f"%{w}%", f"%{w}%"]
            named = self.c.execute(f"SELECT prog, ref, name, loc FROM refs WHERE {where} "
                                   "ORDER BY name LIMIT ?", (*args, limit)).fetchall() if words else []
        seen, out = set(), []
        for r in exact + named:
            if r[:2] not in seen:
                seen.add(r[:2])
                out.append(r)
        return out[:limit]

    def ref_suggest(self, token, limit=8):
        """Matches for a partly typed reference: digits, a reference, or part of a name."""
        t = token.strip().upper()
        if not t:
            return []
        if t.isdigit():
            pre = DEFAULT_POTA_PREFIX
            exact = f"{pre}-{int(t):04d}"
            with self.lock:
                rows = self.c.execute(
                    "SELECT prog, ref, name, loc FROM refs WHERE ref=? "
                    "UNION ALL SELECT * FROM (SELECT prog, ref, name, loc FROM refs WHERE prog='POTA' "
                    "AND ref LIKE ? AND ref != ? ORDER BY length(ref), ref LIMIT ?)",
                    (exact, f"{pre}-%{t}%", exact, limit)).fetchall()
            if exact == "US-0000":
                rows = []
            return rows[:limit]
        if re.search(r"\d", t) and re.search(r"[-/]", t):
            with self.lock:
                return self.c.execute("SELECT prog, ref, name, loc FROM refs WHERE ref LIKE ? "
                                      "ORDER BY ref LIMIT ?", (t + "%", limit)).fetchall()
        return self.ref_search(t, limit) if len(t) >= 3 else []

    def refs_counts(self):
        with self.lock:
            return dict(self.c.execute("SELECT prog, COUNT(*) FROM refs GROUP BY prog").fetchall())

    # --- offline callbook
    def offline_replace(self, country, rows_iter, batch=50000):
        n = 0
        with self.lock:
            self.c.execute("DELETE FROM offline WHERE country=?", (country,))
            buf = []
            for r in rows_iter:
                buf.append(r)
                if len(buf) >= batch:
                    self.c.executemany("INSERT OR REPLACE INTO offline VALUES (?,?,?,?,?,?)", buf)
                    n += len(buf)
                    buf = []
            if buf:
                self.c.executemany("INSERT OR REPLACE INTO offline VALUES (?,?,?,?,?,?)", buf)
                n += len(buf)
            self.c.commit()
        return n

    def offline_get(self, call):
        with self.lock:
            r = self.c.execute("SELECT call, name, city, state, country, cls FROM offline WHERE call=?",
                               (call,)).fetchone()
        if not r:
            return None
        return {"call": r[0], "name": r[1], "qth": r[2], "state": r[3], "country": r[4],
                "cls": r[5], "src": "FCC" if r[4] == "USA" else "ISED"}

    def offline_counts(self):
        with self.lock:
            return dict(self.c.execute("SELECT country, COUNT(*) FROM offline GROUP BY country").fetchall())

    # --- callbook
    def callbook_get(self, base):
        with self.lock:
            r = self.c.execute("SELECT call, name, qth, state, grid, country, fetched FROM callbook "
                               "WHERE base=?", (base,)).fetchone()
        if not r:
            return None
        return dict(zip(("call", "name", "qth", "state", "grid", "country", "fetched"), r))

    def callbook_put(self, base, info):
        with self.lock:
            self.c.execute("INSERT OR REPLACE INTO callbook VALUES (?,?,?,?,?,?,?,?)",
                           (base, info.get("call", base), info.get("name", ""), info.get("qth", ""),
                            info.get("state", ""), info.get("grid", ""), info.get("country", ""),
                            time.time()))
            self.c.commit()

    def callbook_count(self):
        with self.lock:
            return self.c.execute("SELECT COUNT(*) FROM callbook WHERE name != ''").fetchone()[0]

    def close(self):
        with self.lock:
            self.c.close()


DEFAULT_ACLOG = os.path.join(os.path.expanduser("~"), "OneDrive", "Documents", "Affirmatech",
                             "N3FJP Software", "ACLog", "LogData.mdb")


def read_aclog_into(db, path):
    """Read QSOs straight from ACLog's LogData.mdb (needs: pip install access-parser).
    Works on a copy, so ACLog can stay open."""
    import shutil
    import tempfile
    from access_parser import AccessParser
    tmp = os.path.join(tempfile.gettempdir(), "rawhams_aclog_copy.mdb")
    shutil.copyfile(path, tmp)
    try:
        table = AccessParser(tmp).parse_table("tblContacts")
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    cols = {k.lower(): k for k in table}

    def col(*names):
        for n in names:
            if n.lower() in cols:
                return table[cols[n.lower()]]
        return None
    calls = col("fldCall")
    if calls is None:
        raise ValueError("no fldCall column in tblContacts")
    n = len(calls)
    blank = [""] * n
    dates = col("fldDateStr", "fldDate") or blank
    times = col("fldTimeOnStr", "fldTimeOn") or blank
    bands = col("fldBand") or blank
    modes = col("fldMode") or blank
    names = col("fldNameS", "fldName", "fldFirstName") or blank
    states = col("fldState") or blank
    notes = col("fldComments", "fldComment", "fldNotes") or blank

    def clean_date(v):
        if hasattr(v, "strftime"):
            return v.strftime("%Y%m%d")
        return re.sub(r"\D", "", str(v or ""))[:8]

    def clean_time(v):
        if hasattr(v, "strftime"):
            return v.strftime("%H%M")
        return re.sub(r"\D", "", str(v or ""))[:4]

    def clean_band(v):
        v = str(v or "").strip().lower()
        if v and not v.endswith(("m", "cm")):
            v += "m"
        return v

    rows = []
    for i in range(n):
        call = str(calls[i] or "").strip().upper()
        if not call:
            continue
        rows.append((base_call(call), call, clean_date(dates[i]), clean_time(times[i]),
                     clean_band(bands[i]), norm_mode(str(modes[i] or "")),
                     str(names[i] or "").strip(), str(states[i] or "").strip().upper(), "adif", None,
                     clean_text(notes[i] or "")))
    with db.lock:
        db.c.execute("DELETE FROM worked WHERE src='adif'")
        db.c.executemany("INSERT INTO worked (base, call, date, time, band, mode, name, state, src, app_id, comment) VALUES (?,?,?,?,?,?,?,?,?,?,?)", rows)
        db.c.commit()
    return len(rows)


class QRZError(Exception):
    pass


class QRZ:
    """QRZ XML callsign lookups (needs a QRZ XML Logbook Data subscription)."""
    URL = "https://xmldata.qrz.com/xml/current/"

    def __init__(self, user, password):
        self.user, self.password = user, password
        self.key = None
        self.lock = threading.Lock()

    def _get(self, params):
        url = self.URL + "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers={"User-Agent": f"RawHamsLiteLogger/{VERSION}"})
        with urllib.request.urlopen(req, timeout=10) as r:
            root = ET.fromstring(r.read())
        out = {}
        for el in root.iter():
            tag = el.tag.split("}")[-1]
            parent = out.setdefault("_session" if tag in ("Key", "Error", "Message", "SubExp") else "_cs", {})
            parent[tag] = (el.text or "").strip()
        return out

    def login(self):
        res = self._get({"username": self.user, "password": self.password,
                         "agent": f"RawHamsLiteLogger{VERSION}"})
        s = res.get("_session", {})
        if not s.get("Key"):
            raise QRZError(s.get("Error") or "QRZ login failed")
        self.key = s["Key"]
        return s.get("SubExp", "")

    def lookup(self, call):
        """-> dict (empty dict if QRZ has no record). Raises QRZError on login problems."""
        with self.lock:
            for attempt in range(2):
                if not self.key:
                    self.login()
                res = self._get({"s": self.key, "callsign": call})
                s, cs = res.get("_session", {}), res.get("_cs", {})
                err = s.get("Error", "")
                if not s.get("Key") or re.search(r"session|invalid", err, re.I):
                    self.key = None
                    if attempt == 0:
                        continue
                    raise QRZError(err or "QRZ session problem")
                if err.lower().startswith("not found"):
                    return {}
                if not cs.get("call"):
                    return {}
                first = cs.get("nickname") or cs.get("fname", "")
                return {"call": cs.get("call", call).upper(),
                        "name": " ".join(x for x in (first, cs.get("name", "")) if x).strip(),
                        "qth": cs.get("addr2", ""), "state": cs.get("state", ""),
                        "grid": cs.get("grid", ""), "country": cs.get("country", ""),
                        "image": cs.get("image", "") if re.match(r"https?://", cs.get("image", "")) else ""}
        return {}


class RefSuggest:
    """Drop-down of matching parks/summits under a reference box (works offline)."""

    def __init__(self, app, entry, var, on_tab=None):
        self.app, self.entry, self.var = app, entry, var
        self.on_tab = on_tab  # where Tab goes next (after picking a suggestion)
        self.pop = None
        self.rows = []
        entry.bind("<KeyRelease>", self._key, add="+")
        entry.bind("<Down>", lambda e: self._move(1))
        entry.bind("<Up>", lambda e: self._move(-1))
        entry.bind("<Return>", self._enter)
        entry.bind("<KP_Enter>", self._enter)
        entry.bind("<Tab>", self._tab)
        entry.bind("<Escape>", lambda e: self.hide())
        entry.bind("<FocusOut>", lambda e: (self._cancel(), entry.after(200, self.hide)), add="+")

    def _token(self):
        return self.var.get().split(",")[-1].strip()

    def _key(self, e):
        if e.keysym in ("Up", "Down", "Return", "KP_Enter", "Tab", "Escape"):
            return
        # wait for a short pause in typing, so slow computers never lag behind the keyboard
        if getattr(self, "_job", None):
            self.entry.after_cancel(self._job)
        self._job = self.entry.after(150, self._lookup)

    def _cancel(self):
        if getattr(self, "_job", None):
            self.entry.after_cancel(self._job)
            self._job = None

    def _lookup(self):
        self._job = None
        tok = self._token()
        known = parse_refs(tok)
        # nothing to suggest for an empty word or a complete reference we already know
        if not tok or (known and known[0][0] and not tok.isdigit()
                       and self.app.db.ref_get(*known[0])):
            self.hide()
            return
        self.rows = self.app.db.ref_suggest(tok)
        if not self.rows:
            self.hide()
            if not self.app.db.refs_counts():
                self.app.info_hint("No park lists saved yet - connect to the internet and use "
                                   "Settings > Offline data > Update park & summit lists.")
            return
        self._show()

    def _show(self):
        if not self.pop:
            self.pop = tk.Toplevel(self.entry)
            self.pop.wm_overrideredirect(True)
            self.pop.attributes("-topmost", True)
            self.lb = tk.Listbox(self.pop, font=self.app.mono, height=8, width=64,
                                 activestyle="none", exportselection=False,
                                 selectbackground=col("#2e9e6e"), selectforeground="white")
            self.lb.pack(fill="both", expand=True)
            self.lb.bind("<ButtonRelease-1>", lambda e: self.pick())
        self.lb.delete(0, "end")
        for prog, ref, name, loc in self.rows:
            label = ref if prog == "POTA" else f"{prog} {ref}"
            self.lb.insert("end", f"{label:<13} {name[:34]:<34} {loc[:14]}")
        self.lb.config(height=len(self.rows))
        self.lb.selection_clear(0, "end")
        self.lb.selection_set(0)
        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        self.pop.geometry(f"+{x}+{y}")
        self.pop.deiconify()
        self.pop.lift()

    def visible(self):
        return bool(self.pop and self.pop.winfo_viewable() and self.rows)

    def hide(self):
        if self.pop:
            self.pop.withdraw()

    def _move(self, d):
        if not self.visible():
            return None
        cur = (self.lb.curselection() or (0,))[0]
        new = max(0, min(len(self.rows) - 1, cur + d))
        self.lb.selection_clear(0, "end")
        self.lb.selection_set(new)
        self.lb.see(new)
        return "break"

    def pick(self):
        if not self.rows:
            return
        i = (self.lb.curselection() or (0,))[0]
        prog, ref = self.rows[i][:2]
        token = ref if guess_program(ref) == prog else f"{prog}:{ref}"
        parts = [p.strip() for p in self.var.get().split(",")]
        parts[-1] = token
        self.var.set(", ".join(p for p in parts if p))
        self.entry.icursor("end")
        self.hide()
        self.rows = []

    def _enter(self, e):
        if getattr(self, "_job", None):  # Enter before the list caught up - don't swallow it
            self.entry.after_cancel(self._job)
            self._job = None
        if self.visible():
            self.pick()
            return "break"
        return None

    def _tab(self, e):
        if self.visible():
            self.pick()
            if not self.on_tab:
                return "break"
        return self.on_tab(e) if self.on_tab else None


# ================================================================ Raw Roster (WSJT-X) and live Spots windows

_CTY = {}


def country_of(call):
    """Country from the callsign prefix (AD1C's cty list, works offline). '' if unknown."""
    if not _CTY:
        try:
            with open(os.path.join(RES_DIR, "ctyprefix.txt"), encoding="utf-8") as fh:
                for ln in fh:
                    if ln.startswith("#") or "|" not in ln:
                        continue
                    name, pfx = ln.rstrip("\n").split("|", 1)
                    for x in pfx.split():
                        _CTY.setdefault(x.upper(), name)
        except OSError:
            _CTY["-"] = ""
    c = (call or "").upper().strip()
    if "/" in c:  # VE3/W1AW -> VE3 ;  W1AW/P -> W1AW ;  W1AW/VE3 -> VE3
        parts = [x for x in c.split("/") if x]
        pre = [x for x in parts if x not in ("P", "M", "MM", "AM", "QRP", "A") and len(x) <= 4 and x != base_call(c)]
        c = pre[0] if pre else base_call(c)
    for n in range(min(len(c), 6), 0, -1):
        if c[:n] in _CTY:
            return _CTY[c[:n]]
    return ""


class _ListWindow:
    """Shared bits: a Toplevel with a filter bar, a table and a status line. Closing it = Off."""

    def __init__(self, app, title, cols, geometry, on_close):
        self.app = app
        self.w = w = tk.Toplevel(app.root)
        w.title(f"{title} - {APP}")
        w.geometry(geometry)
        w.columnconfigure(0, weight=1)
        w.rowconfigure(1, weight=1)
        w.protocol("WM_DELETE_WINDOW", on_close)
        self.bar = ttk.Frame(w, padding=(8, 6, 8, 2))
        self.bar.grid(row=0, column=0, sticky="ew")
        fr = ttk.Frame(w, padding=(8, 2))
        fr.grid(row=1, column=0, sticky="nsew")
        fr.columnconfigure(0, weight=1)
        fr.rowconfigure(0, weight=1)
        self.tv = ttk.Treeview(fr, columns=[c[0] for c in cols], show="headings", selectmode="browse")
        for key, head, width, stretch in cols:
            self.tv.heading(key, text=head)
            self.tv.column(key, width=width, minwidth=30, stretch=stretch,
                           anchor="w" if stretch or key in ("call", "msg") else "center")
        sb = ttk.Scrollbar(fr, orient="vertical", command=self.tv.yview)
        self.tv.configure(yscrollcommand=sb.set)
        self.tv.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        for tag, color, bold in (("new", "#1e7d4f", True), ("b4", "#1f4e8c", False), ("dupe", "#888", False),
                                 ("p2p", "#b9770e", True), ("me", "#c0392b", True)):
            self.tv.tag_configure(tag, foreground=col(color),
                                  font=(UI_FONT, 10, "bold") if bold else (UI_FONT, 10))
        self.status = ttk.Label(w, text="", foreground=col("#555"), padding=(8, 2, 8, 6))
        self.status.grid(row=2, column=0, sticky="ew")
        if DARK["on"]:
            w.after(60, lambda: _dark_titlebar(w, True))

    def tag_for(self, call, khz, mode, p2p=False):
        """NEW / worked before / already in this activation (dupe) - from your own log."""
        band = band_for(khz) if khz else ""
        today = utc_now().strftime("%Y%m%d")
        if any(q["call"] == call and q["band"] == band and q["mode"] == mode and q["date"] == today
               for q in self.app.d["qsos"]):
            return "dupe", "DUPE"
        total, _last, _same, _n, _s = self.app.db.worked(base_call(call), band, mode)
        if p2p:
            w = "P2P" if self.app.activating() else "PARK"
            return "p2p", (w if not total else w + " B4")
        return ("b4", f"B4 x{total}") if total else ("new", "NEW")


class CallRoster(_ListWindow):
    """Stations WSJT-X is decoding right now, tagged from your log. Double-click one to have WSJT-X call it."""
    MAX_AGE = 5 * 60

    def __init__(self, app, on_close):
        super().__init__(app, "Raw Roster (WSJT-X)", [
            ("call", "Callsign", 100, False), ("calling", "Calling", 90, False), ("grid", "Grid", 60, False),
            ("country", "Country", 130, False), ("st", "St", 40, False), ("db", "dB", 44, False),
            ("age", "Age", 52, False), ("tag", "", 90, False),
            ("note", "Your note / message", 240, True)], "960x440", on_close)
        self.heard = {}  # call -> dict(decode..., parsed..., when, addr)
        self.grids = {}  # last grid heard from each station (CQ and first calls carry it)
        self.heads = {"call": "Callsign", "calling": "Calling", "grid": "Grid", "country": "Country", "st": "St",
                      "db": "dB", "age": "Age", "tag": "", "note": "Your note / message"}
        sk = app.d.get("roster_sort") or ["age", False]
        self.sort_col, self.sort_rev = (sk[0], bool(sk[1])) if sk[0] in self.heads else ("age", False)
        for k in self.heads:
            self.tv.heading(k, command=lambda k=k: self.sort_by(k))
        self._show_sort()
        self.v_cq = tk.BooleanVar(value=bool(app.d.get("roster_cq_only", False)))
        self.v_nodupe = tk.BooleanVar(value=bool(app.d.get("roster_hide_dupes", True)))
        self.v_p2p = tk.BooleanVar(value=bool(app.d.get("roster_p2p_only", False)))
        for txt, var in (("CQ only", self.v_cq), ("Hide dupes", self.v_nodupe), ("P2P only (CQ POTA/SOTA/WWFF...)",
                                                                                 self.v_p2p)):
            ttk.Checkbutton(self.bar, text=txt, variable=var, command=self.refresh).pack(side="left", padx=(0, 14))
        ttk.Label(self.bar, text="Double-click = WSJT-X calls them    Right-click = more",
                  foreground=col("#777")).pack(side="right")
        self.tv.bind("<Double-1>", lambda e: self.call_selected())
        self.tv.bind("<Return>", lambda e: self.call_selected())
        menu = tk.Menu(self.w, tearoff=0)
        menu.add_command(label="Call them in WSJT-X", command=self.call_selected)
        menu.add_command(label="Put in the Call box", command=self.to_call_box)
        menu.add_command(label="Look up on QRZ.com", command=self.qrz_lookup)

        def popup(ev):
            row = self.tv.identify_row(ev.y)
            if row:
                self.tv.selection_set(row)
                menu.tk_popup(ev.x_root, ev.y_root)
        self.tv.bind("<Button-3>", popup)
        self.dial_hz, self.mode = 0, "FT8"
        self.status.config(text="Waiting for WSJT-X... (Settings > WSJT-X must be on, and WSJT-X sending UDP to "
                                f"port {app.d.get('wsjtx_port') or 2237})")
        self._tick()

    def on_status(self, st):
        self.dial_hz = st.get("dial_hz") or self.dial_hz
        if st.get("mode"):
            self.mode = st["mode"].upper()

    def on_decode(self, d, addr):
        if d.get("off_air"):
            return
        p = parse_ft_message(d.get("message"))
        if not p or not p["call"] or p["call"] == self.app.v_call.get().strip().upper():
            return
        if p.get("grid"):
            self.grids[p["call"]] = p["grid"]
        self.heard[p["call"]] = {**d, **p, "when": time.time(), "addr": addr}

    def sort_by(self, k):
        """Click a heading to sort by it; click again to flip. Stations calling you always stay on top."""
        if k == "note":
            return
        if self.sort_col == k:
            self.sort_rev = not self.sort_rev
        else:
            self.sort_col, self.sort_rev = k, False
        self.app.d["roster_sort"] = [self.sort_col, self.sort_rev]
        self._show_sort()
        self.refresh()

    def _show_sort(self):
        for k, t in self.heads.items():
            arrow = (" \u25bc" if not self.sort_rev else " \u25b2") if k == self.sort_col else ""
            self.tv.heading(k, text=t + arrow)

    def _tick(self):
        if not self.w.winfo_exists():
            return
        self.refresh()
        self.w.after(2000, self._tick)

    def refresh(self):
        now = time.time()
        for c in [c for c, h in self.heard.items() if now - h["when"] > self.MAX_AGE]:
            del self.heard[c]
        khz = self.dial_hz / 1000.0 if self.dial_hz else (self.app.cat_khz or parse_freq_khz(self.app.v_freq.get()))
        mode = norm_mode(self.mode or "FT8")  # whatever WSJT-X is in: FT8, FT4, Q65, JT65, MSK144 ...
        me = base_call(self.app.v_call.get().strip().upper())
        keep = self.tv.selection()
        self.tv.delete(*self.tv.get_children())
        shown = 0
        rows = []
        for call, h in self.heard.items():
            p2p = h["cq_word"] in OTA_WORDS
            if self.v_cq.get() and not h["cq"]:
                continue
            if self.v_p2p.get() and not p2p:
                continue
            tag, label = self.tag_for(call, khz, mode, p2p)
            if tag == "dupe" and self.v_nodupe.get():
                continue
            if me and base_call(h["to"]) == me:
                tag, label = "me", "CALLING YOU"
            info = self.app.db.callbook_get(base_call(call)) or self.app.db.offline_get(base_call(call)) or {}
            note = self.app.db.last_comment(base_call(call))
            grid = h["grid"] or self.grids.get(call) or (info.get("grid") or "")[:4]
            country = country_of(call) or info.get("country", "")
            rows.append((tag == "me", h, (call, h["to"], grid, country, (info.get("state") or "")[:3], h["snr"],
                                          int(now - h["when"]), label, f'"{note[0]}"' if note else h["message"]), tag))
        idx = list(self.heads).index(self.sort_col)

        def key(r):
            v = r[2][idx]
            if self.sort_col == "age":
                v = -r[1]["when"]  # newest first
            elif self.sort_col == "db":
                v = -(v if isinstance(v, int) else -99)  # strongest first
            return (str(v).upper() if isinstance(v, str) else v)
        rows.sort(key=key, reverse=self.sort_rev)
        rows.sort(key=lambda r: not r[0])  # stations calling you stay on top (stable sort keeps the rest)
        for _me, h, v, tag in rows:
            age = v[6]
            self.tv.insert("", "end", iid=v[0], tags=(tag,), values=v[:6] + (f"{age // 60}:{age % 60:02d}",) + v[7:])
            shown += 1
        for k in keep:
            if self.tv.exists(k):
                self.tv.selection_set(k)
        if self.heard:
            band = band_for(khz) if khz else "?"
            self.status.config(text=f"{shown} shown of {len(self.heard)} heard in the last 5 minutes  -  {band} {mode}")

    def _sel(self):
        s = self.tv.selection()
        return self.heard.get(s[0]) if s else None

    def call_selected(self):
        h = self._sel()
        if not h:
            return
        sock = getattr(self.app, "_wsjtx_sock", None)
        if not sock or not h.get("addr"):
            self.status.config(text="Can't reach WSJT-X - is the WSJT-X listener on?", foreground=col("#c0392b"))
            return
        try:
            sock.sendto(wsjtx_reply_packet(h), h["addr"])
            self.status.config(text=f"Asked WSJT-X to call {h['call']}.", foreground=col("#1e7d4f"))
        except OSError as e:
            self.status.config(text=f"Couldn't send to WSJT-X: {e}", foreground=col("#c0392b"))

    def to_call_box(self):
        h = self._sel()
        if h:
            self.app.q_call.set(h["call"])
            self.app.call_entry.focus_set()

    def qrz_lookup(self):
        h = self._sel()
        if h:
            webbrowser.open("https://www.qrz.com/db/" + urllib.parse.quote(base_call(h["call"])))


class SpotsWindow(_ListWindow):
    """Live POTA / SOTA / WWFF / DX spots. Click one: the radio tunes there, the call and park go in the form."""
    BANDS = ["All", "160m", "80m", "60m", "40m", "30m", "20m", "17m", "15m", "12m", "10m", "6m", "2m"]
    PROGS = ["POTA", "SOTA", "WWFF", "DX"]

    def __init__(self, app, on_close):
        super().__init__(app, "Spots", [
            ("utc", "UTC", 50, False), ("call", "Call", 96, False), ("freq", "Freq", 76, False),
            ("mode", "Mode", 50, False), ("prog", "Prog", 50, False), ("ref", "Ref", 96, False),
            ("tag", "", 64, False), ("name", "Park / summit / info", 300, True)], "900x460", on_close)
        d = app.d
        self.v_band = tk.StringVar(value=d.get("spots_band") or "All")
        self.v_mode = tk.StringVar(value=d.get("spots_mode") or "All")
        self.v_prog = {p: tk.BooleanVar(value=p in (d.get("spots_progs") or ["POTA", "SOTA", "WWFF"]))
                       for p in self.PROGS}
        ttk.Label(self.bar, text="Band").pack(side="left")
        cb = ttk.Combobox(self.bar, textvariable=self.v_band, values=self.BANDS, width=6, state="readonly")
        cb.pack(side="left", padx=(4, 12))
        cb.bind("<<ComboboxSelected>>", lambda e: self.show())
        ttk.Label(self.bar, text="Mode").pack(side="left")
        mb = ttk.Combobox(self.bar, textvariable=self.v_mode, values=["All", "SSB", "CW", "FT8", "FT4", "DATA", "FM"],
                          width=6, state="readonly")
        mb.pack(side="left", padx=(4, 12))
        mb.bind("<<ComboboxSelected>>", lambda e: self.show())
        for p in self.PROGS:
            ttk.Checkbutton(self.bar, text=p, variable=self.v_prog[p], command=self.reload).pack(side="left", padx=(0, 8))
        ttk.Button(self.bar, text="Refresh", command=self.reload).pack(side="right")
        ttk.Label(self.bar, text="Click a spot to tune and fill the form", foreground=col("#777")).pack(side="right",
                                                                                                    padx=10)
        self.tv.bind("<<TreeviewSelect>>", lambda e: self.use_selected())
        self.spots, self._busy, self._job = [], False, None
        self.reload()

    def _save_filters(self):
        self.app.d.update(spots_band=self.v_band.get(), spots_mode=self.v_mode.get(),
                          spots_progs=[p for p, v in self.v_prog.items() if v.get()])

    def close(self):
        """Spots: Off. Stop the once-a-minute refresh too - before 1.36 it kept running on the closed window."""
        self._closed = True
        if self._job:
            try:
                self.w.after_cancel(self._job)
            except tk.TclError:
                pass
            self._job = None
        try:
            self.w.destroy()
        except tk.TclError:
            pass

    def reload(self):
        if getattr(self, "_closed", False) or not self.w.winfo_exists():
            return
        self._save_filters()
        if self._job:
            try:
                self.w.after_cancel(self._job)
            except tk.TclError:
                pass
        self._job = self.w.after(60000, self.reload)  # refresh every minute while On
        if self._busy:
            return
        progs = [p for p, v in self.v_prog.items() if v.get()]
        if not progs:
            self.spots = []
            self.show()
            return
        self._busy = True
        self.status.config(text="Getting spots...", foreground=col("#555"))

        def work():
            try:
                spots, problems = fetch_spots(progs)
            except Exception as e:  # noqa: BLE001
                spots, problems = [], [str(e)]
            self.app.ui_q.put((self._loaded, (spots, problems)))
        threading.Thread(target=work, daemon=True).start()

    def _loaded(self, spots, problems):
        self._busy = False
        if getattr(self, "_closed", False) or not self.w.winfo_exists():
            return
        if spots or not problems:
            self.spots = spots
        self.show()
        when = utc_now().strftime("%H:%M")
        if problems and not spots:
            self.status.config(text="No internet or the spot sites aren't answering - spots paused, trying again "
                                    "every minute.", foreground=col("#c0392b"))
        else:
            extra = ("   (couldn't get: " + ", ".join(p.split(":")[0] for p in problems) + ")") if problems else ""
            self.status.config(text=f"Updated {when}Z  -  {len(self.tv.get_children())} shown of {len(self.spots)} "
                                    f"spots{extra}", foreground=col("#1e7d4f") if not problems else col("#b9770e"))

    def show(self):
        self._save_filters()
        band, mode = self.v_band.get(), self.v_mode.get()
        self.tv.delete(*self.tv.get_children())
        for i, sp in enumerate(self.spots):
            if band != "All" and sp["band"] != band:
                continue
            if mode != "All" and sp["mode"] != mode:
                continue
            m = sp["mode"] if sp["mode"] in MODES else "SSB"
            tag, label = self.tag_for(sp["call"], sp["khz"], m, p2p=False)
            utc = datetime.fromtimestamp(sp["ts"], timezone.utc).strftime("%H:%M") if sp["ts"] else ""
            name = sp["name"] or ""
            if sp["where"] and sp["where"] not in name:
                name = f"{name}  ({sp['where']})" if name else sp["where"]
            if sp["note"]:
                name = f"{name}  -  {sp['note']}" if name else sp["note"]
            self.tv.insert("", "end", iid=str(i), tags=(tag,), values=(
                utc, sp["call"], fmt_khz(sp["khz"]), sp["mode"], sp["prog"], sp["ref"], label, name))

    def use_selected(self):
        s = self.tv.selection()
        if not s:
            return
        sp = self.spots[int(s[0])]
        a = self.app
        a.v_freq.set(fmt_khz(sp["khz"]))
        a._update_band()
        if sp["mode"] in MODES and sp["mode"] != a.v_mode.get():
            a._set_rst_defaults(a.v_mode.get(), sp["mode"])
            a.v_mode.set(sp["mode"])
            a.d["mode"] = sp["mode"]
        a._push_to_radio()  # tune the radio by CAT
        a.q_call.set(sp["call"])
        if sp["ref"] and sp["prog"] in ("POTA", "SOTA", "WWFF"):
            ref = sp["ref"] if guess_program(sp["ref"]) == sp["prog"] else f"{sp['prog']}:{sp['ref']}"
            a.q_their.set(ref)  # their park/summit goes in P2P
        else:
            a.q_their.set("")
        a._save()
        a._status(f"Spot: {sp['call']} {fmt_khz(sp['khz'])} {sp['mode']} {sp['ref']}"
                  + (" - radio tuned" if a.cat and a.cat.running else " - radio not connected"), ok=True)


# ================================================================ app

class OtaLite:
    def __init__(self, root):
        self.root = root
        root.report_callback_exception = lambda *exc: _log_error(exc)  # button/timer errors go to error.log too
        self.d = self._load()
        self.last_spot_at = 0.0
        self.cat = None
        self.cat_khz = None
        self.ui_q = queue.Queue()  # background threads -> Tk main thread
        self.db = LocalDB(DB_FILE)
        self.qrz = None
        self._lookup_job = None
        self._lookup_busy = set()
        self._auto_state = ""
        self._cur_name = ""
        self._preloading = False
        self._qrz_warned = False
        self._status_var = tk.StringVar(value="")
        self._migrate_loc()

        root.title(APP)
        root.geometry("1060x640")
        root.minsize(780, 480)
        root.columnconfigure(0, weight=1)
        root.rowconfigure(3, weight=1)

        style = ttk.Style()
        try:
            style.theme_use("vista" if os.name == "nt" else "clam")
        except tk.TclError:
            pass
        body = ("Segoe UI", 10) if os.name == "nt" else ("DejaVu Sans", 10)
        style.configure("Treeview", font=body,
                        rowheight=int(tk.font.Font(font=body).metrics("linespace") * 1.5))
        style.configure("Treeview.Heading", font=(body[0], 10, "bold"))
        self.mono = ("Consolas", 12) if os.name == "nt" else ("DejaVu Sans Mono", 11)
        self._light_theme, self._body, self._root_bg = style.theme_use(), body, str(root.cget("bg"))
        if self.d.get("dark"):
            self.apply_appearance(True, built=False)

        self._set_pota_prefix()
        self._build_menu()
        self._build_station()
        self._build_activation()
        self._build_logbar()
        self._build_table()
        self._build_footer()

        self._apply_activating()
        self._refresh_refs()
        self._refresh_table()
        self._update_band()
        self._tick()
        self._pump()
        for q in self.d["qsos"]:
            self.db.add_app_qso(q)
        self._make_qrz()
        self.root.after(2500, self._auto_update_worked)
        self.root.after(4000, self._auto_update_refs)
        self._latest = None
        self.root.after(6000, lambda: self.check_updates(quiet=True))
        self._wsjtx_stop = True
        if self.d.get("wsjtx_on"):
            self.root.after(800, self._start_wsjtx)
        self._refresh_station()
        self._refresh_send_buttons()
        self.call_entry.focus_set()
        if not self.d.get("shortcut_offered") and (IS_WIN or IS_LINUX) and not FROZEN \
                and not os.environ.get("RAWHAM_NO_PROMPTS"):
            self.root.after(1500, self._offer_shortcut)
        if not self.d.get("callsign"):
            self.root.after(700, lambda: self.settings_dialog("My station"))
        elif getattr(self, "_lost_secrets", None):
            names = {"qrz_pass": "QRZ password", "qrz_key": "QRZ Logbook API key", "wl_key": "Wavelog API key"}
            self.root.after(900, lambda: messagebox.showinfo(
                APP, "Your saved " + ", ".join(names[k] for k in self._lost_secrets) + " couldn't be unlocked - "
                "passwords are locked to the Windows user and PC they were saved on.\n\nPlease type them again "
                "in Settings."))
        net_rig = rig_type(self.d.get("rig_type") or "yaesu")[2] in RIG_NET_PORTS
        if self.d.get("cat_autoconnect") and (net_rig or (HAVE_SERIAL and self.d.get("cat_port"))):
            self.root.after(500, self.toggle_cat)

    # ------------------------------------------------ persistence
    def _load(self):
        d = {"callsign": "", "grid": "", "refs": "K-TEST", "freq": "14331", "mode": "SSB",
             "comment": "", "auto_respot": False, "cat_port": "", "cat_baud": 38400,
             "cat_drop": False, "cat_autoconnect": False, "qrz_user": "", "qrz_pass": "", "qsos": [], "next_id": 1,
             "qrz_key": "", "qrz_auto": False, "udp_fwd": False, "udp_host": "127.0.0.1", "udp_port": "2236",
             "udp_fmt": "WSJT-X", "wsjtx_on": False, "wsjtx_port": "2237", "wsjtx_group": "",
             "aclog_auto": True, "activating": True, "my_grid": ""}
        try:
            with open(DATA_FILE, encoding="utf-8") as fh:
                d.update(json.load(fh))
        except FileNotFoundError:
            pass
        except Exception as e:  # noqa: BLE001
            messagebox.showwarning(APP, f"Couldn't read saved data; starting fresh.\n\n{e}")
        self._lost_secrets = []
        for k in SECRET_KEYS:
            d[k], ok = secret_open(d.get(k, ""))
            if not ok:
                self._lost_secrets.append(k)
        return d

    def _save(self):
        self.d.update({
            "callsign": self.v_call.get().strip().upper(), "grid": self.v_grid.get().strip(),
            "refs": self.v_refs.get().strip().upper(), "freq": self.v_freq.get().strip(),
            "mode": self.v_mode.get(), "comment": self.v_comment.get(),
            "auto_respot": bool(self.v_auto.get()), "cat_port": self.v_port.get(),
            "my_grid": fmt_grid(self.v_mygrid.get()) if hasattr(self, "v_mygrid") else self.d.get("my_grid", ""),
            "cat_baud": int(self.v_baud.get() or 38400), "cat_drop": bool(self.v_drop.get()),
        })
        out = dict(self.d)
        for k in SECRET_KEYS:  # passwords and keys: encrypted (Windows) or in the keyring (Linux)
            v = self.d.get(k, "")
            if v and getattr(self, "_sealed", {}).get(k, (None,))[0] == v:
                out[k] = self._sealed[k][1]  # unchanged - don't touch the keyring again
            else:
                out[k] = secret_seal(v, k)
                self._sealed = getattr(self, "_sealed", {})
                self._sealed[k] = (v, out[k])
        tmp = DATA_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(out, fh, indent=1)
        if not IS_WIN:
            try:
                os.chmod(tmp, 0o600)  # owner-only
            except OSError:
                pass
        os.replace(tmp, DATA_FILE)

    # ------------------------------------------------ UI build
    def _build_station(self):
        f = ttk.LabelFrame(self.root, text="Station & radio", padding=(8, 4))
        f.grid(row=0, column=0, sticky="ew", padx=8, pady=(6, 3))
        f.columnconfigure(7, weight=1)
        self.v_call = tk.StringVar(value=self.d["callsign"])
        self.v_grid = tk.StringVar(value=self.d["grid"])
        self.v_port = tk.StringVar(value=self.d["cat_port"])
        self.v_baud = tk.StringVar(value=str(self.d["cat_baud"]))
        self.v_drop = tk.BooleanVar(value=self.d["cat_drop"])
        self.station_lbl = tk.Label(f, text="", font=(self.mono[0], 15, "bold"), cursor="hand2")
        self.station_lbl.grid(row=0, column=0, padx=(0, 14))
        self.station_lbl.bind("<Button-1>", lambda _e: self.settings_dialog("My station"))
        ttk.Style().configure("Disconnect.TButton", foreground=col("#c0392b"), font=(UI_FONT, 10, "bold"))
        ttk.Style().configure("On.TButton", foreground=col("#1e7d4f"), font=(UI_FONT, 10, "bold"))
        self.cat_btn = ttk.Button(f, text="Connect radio", command=self.toggle_cat, width=18)
        self.cat_btn.grid(row=0, column=1)
        ttk.Button(f, text="Settings", command=self.settings_dialog).grid(row=0, column=2, padx=(6, 0))
        self.act_btn = ttk.Button(f, text="Activating: On", width=15, command=self.toggle_activating)
        self.act_btn.grid(row=0, column=3, padx=(6, 0))
        self.spots_btn = ttk.Button(f, text="Spots: Off", width=11, command=self.toggle_spots)
        self.spots_btn.grid(row=0, column=4, padx=(6, 0))
        self.roster_btn = ttk.Button(f, text="Raw Roster: Off", width=15, command=self.toggle_roster)
        self.roster_btn.grid(row=0, column=5, padx=(6, 0))
        self.cat_lbl = ttk.Label(f, text="Radio not connected" if HAVE_SERIAL
                                 else "USB radio control off: run  " + PYSERIAL_CMD, foreground=col("#777"))
        self.photo_btn = ttk.Button(f, text="Photo: Off", width=11, command=self.toggle_photo)
        self.photo_btn.grid(row=0, column=6, padx=(6, 0))
        self.cat_lbl.grid(row=0, column=7, sticky="w", padx=(12, 0))
        self.ver_lbl = tk.Label(f, text=f"v{VERSION}", fg=col("#888"), cursor="hand2", font=(UI_FONT, 9))
        self.ver_lbl.grid(row=0, column=8, sticky="e", padx=(8, 0))
        self.ver_lbl.bind("<Button-1>", lambda _e: self.check_updates(quiet=False))

    def _build_activation(self):
        f = ttk.LabelFrame(self.root, text="Activation", padding=(8, 4))
        f.grid(row=1, column=0, sticky="ew", padx=8, pady=3)
        self.act_frame = f
        f.columnconfigure(1, weight=1)
        self.v_refs = tk.StringVar(value=self.d["refs"])
        self.v_freq = tk.StringVar(value=self.d["freq"])
        self.v_mode = tk.StringVar(value=self.d["mode"])
        self.v_comment = tk.StringVar(value=self.d["comment"])
        self.v_auto = tk.BooleanVar(value=self.d["auto_respot"])

        ref_l = ttk.Label(f, text="Reference(s)")
        ref_l.grid(row=0, column=0, sticky="w")
        e = ttk.Entry(f, textvariable=self.v_refs, font=self.mono)
        e.grid(row=0, column=1, columnspan=3, sticky="ew", padx=(4, 4))
        find_b = ttk.Button(f, text="Find...", width=6, command=lambda: self.find_ref("mine"))
        find_b.grid(row=0, column=4, padx=(0, 10))

        # not activating: My grid instead of the park
        self.v_mygrid = tk.StringVar(value=self.d.get("my_grid") or self.d.get("grid", ""))
        self._grid_typed = False
        grid_l = ttk.Label(f, text="My grid")
        grid_l.grid(row=0, column=0, sticky="w")
        grid_e = ttk.Entry(f, textvariable=self.v_mygrid, font=self.mono, width=8)
        grid_e.grid(row=0, column=1, sticky="w", padx=(4, 4))
        grid_e.bind("<KeyRelease>", lambda _e: setattr(self, "_grid_typed", True), add="+")
        grid_e.bind("<FocusOut>", lambda _e: (self.v_mygrid.set(fmt_grid(self.v_mygrid.get())), self._save(),
                                             self._refresh_grid_hint()), add="+")
        self.grid_hint = ttk.Label(f, text="", foreground=col("#555"))
        self.grid_hint.grid(row=0, column=2, columnspan=3, sticky="w", padx=(4, 10))
        self._home_widgets = [grid_l, grid_e, self.grid_hint]
        self.v_refs.trace_add("write", lambda *_: self._refresh_refs())
        e.bind("<FocusOut>", lambda _e: (self._tidy_refs(self.v_refs), self._save()), add="+")
        self.refs_suggest = RefSuggest(self, e, self.v_refs)

        ttk.Label(f, text="Freq kHz").grid(row=0, column=5)
        self.freq_entry = ttk.Entry(f, textvariable=self.v_freq, width=10, font=self.mono)
        self.freq_entry.grid(row=0, column=6, padx=(4, 2))
        self.freq_entry.bind("<Return>", self._freq_enter)
        self.v_freq.trace_add("write", lambda *_: self._update_band())
        self.band_lbl = ttk.Label(f, text="", width=5, foreground=col("#555"))
        self.band_lbl.grid(row=0, column=7)
        ttk.Label(f, text="Mode").grid(row=0, column=8)
        mb = ttk.Combobox(f, textvariable=self.v_mode, values=MODES, width=6, state="readonly")
        mb.grid(row=0, column=9, padx=(4, 0))
        mb.bind("<<ComboboxSelected>>", lambda _e: self._mode_picked())

        self.refs_lbl = ttk.Label(f, text="", foreground=col("#555"))
        self.refs_lbl.grid(row=1, column=1, columnspan=9, sticky="w", padx=4)

        self.spot_btn = tk.Button(f, text="SPOT ME", command=self.spot, bg=col("#2e9e6e"), fg="white",
                                  activebackground=col("#24835a"), activeforeground="white",
                                  font=(UI_FONT, 11, "bold"), relief="flat", cursor="hand2",
                                  padx=14)
        self.spot_btn.grid(row=2, column=0, sticky="ew", pady=(4, 0))
        # spot comment right here (also in Settings > Spotting) and QRT when you're shutting down
        sp = self.spot_cmt_frame = ttk.Frame(f)
        sp.grid(row=2, column=1, columnspan=9, sticky="w", padx=(10, 0), pady=(4, 0))
        ttk.Label(sp, text="Spot comment").grid(row=0, column=0)
        self.spot_cmt_entry = ttk.Entry(sp, textvariable=self.v_comment, width=30)
        self.spot_cmt_entry.grid(row=0, column=1, padx=(6, 10))
        self.spot_cmt_entry.bind("<FocusOut>", lambda _e: self._save(), add="+")
        self.qrt_btn = tk.Button(sp, text="QRT", command=self.qrt, bg=col("#c0392b"), fg="white",
                                 activebackground=col("#a93226"), activeforeground="white",
                                 font=(UI_FONT, 10, "bold"), relief="flat", cursor="hand2", padx=12)
        self.qrt_btn.grid(row=0, column=2)
        self.spot_lbl = ttk.Label(f, text="Spot comment is optional - leave blank for an automatic one. "
                                          "QRT tells hunters you're done.", foreground=col("#777"))
        self.spot_lbl.grid(row=3, column=0, columnspan=10, sticky="w", pady=(2, 0))
        self._act_widgets = [ref_l, e, find_b, self.refs_lbl, self.qrt_btn]
        f.bind("<Configure>", lambda e: (self.spot_lbl.config(wraplength=max(300, e.width - 30)),
                                         self.refs_lbl.config(wraplength=max(300, e.width - 140))))

    def _build_logbar(self):
        f = ttk.LabelFrame(self.root, text="Log a contact   (Tab = next box,  Enter = Log,  Esc = Clear)",
                           padding=(8, 4))
        f.grid(row=2, column=0, sticky="ew", padx=8, pady=3)
        f.columnconfigure(10, weight=1)
        rst = default_rst(self.v_mode.get())
        self.q_call, self.q_rs, self.q_rr = tk.StringVar(), tk.StringVar(value=rst), tk.StringVar(value=rst)
        self.q_state, self.q_their, self.q_comment = tk.StringVar(), tk.StringVar(), tk.StringVar()
        self.q_name = tk.StringVar()
        self._auto_name = ""

        # row 0:  Call  Sent  Rcvd  P2P [...]  Comment  [Log]      counter
        big = (self.mono[0], 16)
        ttk.Label(f, text="Call").grid(row=0, column=0, sticky="w")
        self.call_entry = ttk.Entry(f, textvariable=self.q_call, width=11, font=big)
        self.call_entry.grid(row=0, column=1, padx=(4, 10))
        ttk.Label(f, text="Sent").grid(row=0, column=2)
        rs_e = ttk.Entry(f, textvariable=self.q_rs, width=4, font=self.mono, justify="center")
        rs_e.grid(row=0, column=3, padx=(4, 6))
        ttk.Label(f, text="Rcvd").grid(row=0, column=4)
        rr_e = ttk.Entry(f, textvariable=self.q_rr, width=4, font=self.mono, justify="center")
        rr_e.grid(row=0, column=5, padx=(4, 10))
        self.p2p_lbl = ttk.Label(f, text="P2P")
        self.p2p_lbl.grid(row=0, column=6)
        te = ttk.Entry(f, textvariable=self.q_their, width=14, font=self.mono)
        te.grid(row=0, column=7, padx=(4, 0))
        te.bind("<FocusOut>", lambda _e: self._tidy_refs(self.q_their), add="+")
        tb = ttk.Button(f, text="\u2026", width=2, command=lambda: self.find_ref("theirs"), takefocus=False)
        tb.grid(row=0, column=8, padx=(2, 10))
        self.q_their.trace_add("write", self._refresh_their)
        ttk.Label(f, text="Comment").grid(row=0, column=9)
        com_e = ttk.Entry(f, textvariable=self.q_comment, width=18, font=self.mono)
        com_e.grid(row=0, column=10, sticky="ew", padx=(4, 10))
        log_b = tk.Button(f, text="LOG", command=self.log_qso, width=6, bg=col("#2e9e6e"), fg="white",
                          activebackground=col("#24835a"), activeforeground="white", font=(UI_FONT, 11, "bold"),
                          relief="flat", cursor="hand2", highlightthickness=2, highlightcolor=col("#1b5e40"))
        log_b.grid(row=0, column=11)

        right = ttk.Frame(f)
        right.grid(row=0, column=12, rowspan=2, sticky="e", padx=(10, 0))
        self.count_lbl = tk.Label(right, text="0", font=(UI_FONT, 22, "bold"), fg=col("#c0392b"), width=3)
        self.count_lbl.grid(row=0, column=0, rowspan=2)
        self.goal_lbl = ttk.Label(right, text="")
        self.goal_lbl.grid(row=0, column=1, sticky="w")
        self.clock_lbl = ttk.Label(right, text="", font=(self.mono[0], 10))
        self.clock_lbl.grid(row=1, column=1, sticky="w")

        # row 1:  Name  State   (fill in by themselves from the callbook)   lookup line
        ttk.Label(f, text="Name").grid(row=1, column=0, sticky="w", pady=(4, 0))
        name_e = ttk.Entry(f, textvariable=self.q_name, width=11, font=self.mono)
        name_e.grid(row=1, column=1, sticky="ew", padx=(4, 10), pady=(4, 0))
        ttk.Label(f, text="State").grid(row=1, column=2, pady=(4, 0))
        st_e = ttk.Entry(f, textvariable=self.q_state, width=4, font=self.mono, justify="center")
        st_e.grid(row=1, column=3, padx=(4, 6), pady=(4, 0))
        self.q_country = tk.StringVar()
        self._auto_country = ""
        ttk.Label(f, text="Country").grid(row=1, column=4, pady=(4, 0))
        ct_e = ttk.Entry(f, textvariable=self.q_country, width=14, font=self.mono)
        ct_e.grid(row=1, column=5, columnspan=3, sticky="ew", padx=(4, 10), pady=(4, 0))
        self.info_lbl = tk.Label(f, text="", anchor="w", font=(UI_FONT, 11), fg=col("#555"))
        self.info_lbl.grid(row=1, column=8, columnspan=3, sticky="ew", pady=(4, 0))
        self.spot_them_btn = ttk.Button(f, text="Spot them", width=9, command=self.spot_them, takefocus=False)
        self.spot_them_btn.grid(row=1, column=11, pady=(4, 0))
        self.their_lbl = tk.Label(f, text="", anchor="w", justify="left", font=(UI_FONT, 10), fg=col("#7a4f00"))
        self.their_lbl.grid(row=2, column=0, columnspan=13, sticky="ew")
        self.q_call.trace_add("write", lambda *_: self._schedule_lookup())
        self.call_entry.bind("<FocusOut>", lambda _e: self._photo_for_call(), add="+")

        # Tab order: Call > Sent > Rcvd > P2P > Comment > Log > (back to Call). Name/State are skipped
        # (they fill in by themselves); clicked into, they Tab on to Comment.
        chain = [self.call_entry, rs_e, rr_e, te, com_e]  # LOG = Enter, so Tab doesn't stop on the button
        nxt = {w: chain[(i + 1) % len(chain)] for i, w in enumerate(chain)}
        prv = {w: chain[i - 1] for i, w in enumerate(chain)}
        # Name, State and Country fill themselves, so Tab never stops there; clicked into, Country sits after Comment
        nxt.update({name_e: st_e, st_e: com_e, ct_e: self.call_entry})
        prv.update({name_e: self.call_entry, st_e: name_e, ct_e: com_e})
        for w in chain + [name_e, st_e, ct_e]:
            if w is not te:  # the P2P box shares Tab with its park drop-down
                w.bind("<Tab>", lambda e, w=w: self._focus_field(nxt[w]))
            for seq in ("<Shift-Tab>", "<ISO_Left_Tab>"):
                try:
                    w.bind(seq, lambda e, w=w: self._focus_field(prv[w]))
                except tk.TclError:
                    pass
        self.their_suggest = RefSuggest(self, te, self.q_their, on_tab=lambda e: self._focus_field(com_e))
        name_e.configure(takefocus=False)
        st_e.configure(takefocus=False)
        ct_e.configure(takefocus=False)
        log_b.configure(takefocus=False)

        self.root.bind("<Return>", self._enter_key)
        self.root.bind("<KP_Enter>", self._enter_key)
        self.root.bind("<Escape>", lambda _e: self._clear_form())

    def _focus_field(self, w):
        """Move to the next box with its text selected, ready to type over."""
        w.focus_set()
        if isinstance(w, (ttk.Entry, tk.Entry)):
            w.select_range(0, "end")
            w.icursor("end")
        return "break"

    def _build_table(self):
        f = ttk.Frame(self.root, padding=(8, 2))
        f.grid(row=3, column=0, sticky="nsew")
        f.columnconfigure(0, weight=1)
        f.rowconfigure(0, weight=1)
        cols = [("n", "#", 52), ("time", "UTC", 56), ("call", "Call", 96), ("name", "Name", 120), ("rs", "Sent", 48),
                ("rr", "Rcvd", 48), ("state", "St", 40), ("their", "P2P", 110),
                ("freq", "Freq", 76), ("band", "Band", 50), ("mode", "Mode", 54), ("comment", "Comment", 130)]
        self.tree = ttk.Treeview(f, columns=[c[0] for c in cols], show="headings", selectmode="extended")
        for key, title, w in cols:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=w, minwidth=w, anchor="w" if key == "comment" else "center",
                             stretch=key in ("name", "their", "comment"))
        sb = ttk.Scrollbar(f, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        self.tree.bind("<Delete>", lambda _e: self.delete_selected())
        self.tree.bind("<Double-1>", lambda _e: self.edit_selected())
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Edit QSO...", command=self.edit_selected)
        menu.add_separator()
        menu.add_command(label="Delete selected QSO(s)", command=self.delete_selected)

        def popup(ev):
            iid = self.tree.identify_row(ev.y)
            if iid:
                if iid not in self.tree.selection():
                    self.tree.selection_set(iid)
                menu.tk_popup(ev.x_root, ev.y_root)
        self.tree.bind("<Button-3>", popup)

    def _build_footer(self):
        f = ttk.Frame(self.root, padding=(8, 4, 8, 8))
        f.grid(row=4, column=0, sticky="ew")
        f.columnconfigure(4, weight=1)
        ttk.Button(f, text="Export ADIF...", command=self.export_adif).grid(row=0, column=0, padx=(0, 6))
        ttk.Button(f, text="Past activations...", command=self.past_activations).grid(row=0, column=1)
        ttk.Button(f, text="New activation", command=self.new_activation).grid(row=0, column=2, padx=(6, 0))
        ttk.Button(f, text="Share \U0001f4f7", command=self.share).grid(row=0, column=3, padx=(6, 0), sticky="w")
        ttk.Label(f, text="Q = QRZ   L = log of choice   W = LoTW   E = event call",
                  foreground=col("#888")).grid(row=0, column=4, sticky="e")
        self.qrz_btn = ttk.Button(f, text="Send to QRZ", command=self.upload_to_qrz, width=16)
        self.qrz_btn.grid(row=0, column=5, padx=(8, 0))
        self.loc_btn = ttk.Button(f, text="Send to LOC", command=self.send_loc_current, width=20)
        self.loc_btn.grid(row=0, column=6, padx=(6, 0))
        self.lotw_btn = ttk.Button(f, text="Send to LoTW", command=self.send_lotw, width=16)
        self.lotw_btn.grid(row=0, column=7, padx=(6, 0))

    # ------------------------------------------------ small helpers
    # --- Spots / Raw Roster on-off
    def toggle_spots(self):
        if getattr(self, "_spots_checking", False):
            return  # still checking the internet from the last click - one window at a time
        if getattr(self, "spots_win", None):
            self.spots_win.close()
            self.spots_win = None
            self.spots_btn.config(text="Spots: Off", style="TButton")
            self._save()
            return
        self.spots_btn.config(text="Spots: ...")
        self._spots_checking = True

        def check():  # only turns on with internet
            try:
                _download("https://api.pota.app/", timeout=6)
                ok = True
            except urllib.error.HTTPError:
                ok = True  # the server answered - we're online
            except Exception:  # noqa: BLE001
                ok = False
            self.ui_q.put((self._spots_online, (ok,)))
        threading.Thread(target=check, daemon=True).start()

    def _spots_online(self, ok):
        self._spots_checking = False
        if getattr(self, "spots_win", None):
            return
        if not ok:
            self.spots_btn.config(text="Spots: Off")
            messagebox.showinfo(APP, "Spots need an internet connection (Wi-Fi or a phone hotspot).\n\n"
                                     "Turn them on again when you're connected.")
            return
        self.spots_win = SpotsWindow(self, self.toggle_spots)
        self.spots_btn.config(text="Spots: On", style="On.TButton")

    def toggle_roster(self):
        if getattr(self, "roster", None):
            self.roster.w.destroy()
            self.roster = None
            self.roster_btn.config(text="Raw Roster: Off", style="TButton")
            return
        if not self.d.get("wsjtx_on"):
            if not messagebox.askyesno(APP, "The Raw Roster listens to WSJT-X. Turn on the WSJT-X listener now?\n\n"
                                            "(Settings > WSJT-X - port " + str(self.d.get("wsjtx_port") or 2237) + ")"):
                return
            self.d["wsjtx_on"] = True
            self._save()
            self._restart_wsjtx()
        self.roster = CallRoster(self, self.toggle_roster)
        self.roster_btn.config(text="Raw Roster: On", style="On.TButton")

    def about(self):
        w = tk.Toplevel(self.root)
        w.title(f"About - {APP}")
        w.transient(self.root)
        w.resizable(False, False)
        ttk.Label(w, text=ABOUT_TEXT.format(app=APP, version=VERSION), justify="left",
                  padding=(16, 14, 16, 6)).pack(anchor="w")
        b = ttk.Frame(w, padding=(16, 4, 16, 14))
        b.pack(fill="x")
        ttk.Button(b, text="Buy me a coffee (PayPal)", command=lambda: webbrowser.open(DONATE_URL)).pack(side="left")
        ttk.Button(b, text="Close", command=w.destroy).pack(side="right")
        w.bind("<Escape>", lambda _e: w.destroy())
        w.grab_set()

    # ------------------------------------------------ QRZ photo pop-out (on/off, needs internet + QRZ XML login)
    def toggle_photo(self):
        if getattr(self, "photo_on", False):
            self.photo_on = False
            self.photo_btn.config(text="Photo: Off", style="TButton")
            if getattr(self, "photo_win", None) and self.photo_win.winfo_exists():
                self._remember_photo_pos(self.photo_win)
                self._save()
                self.photo_win.destroy()
            self.photo_win = None
            return
        try:
            import PIL.Image  # noqa: F401
        except ImportError:
            messagebox.showinfo(APP, "Photos need the Pillow library:\n\n" + ("pip install pillow" if IS_WIN else
                                     "sudo apt install python3-pil   (or: pip install --user pillow)"))
            return
        if not self.qrz:
            messagebox.showinfo(APP, "Photos come from QRZ name lookups - put your QRZ username and password in "
                                     "Settings > QRZ first (needs a QRZ XML subscription).")
            return
        self.photo_btn.config(text="Photo: ...")

        def check():
            try:
                _download("https://xmldata.qrz.com/", timeout=6)
                ok = True
            except urllib.error.HTTPError:
                ok = True
            except Exception:  # noqa: BLE001
                ok = False
            self.ui_q.put((self._photo_online, (ok,)))
        threading.Thread(target=check, daemon=True).start()

    def _photo_online(self, ok):
        if not ok:
            self.photo_btn.config(text="Photo: Off", style="TButton")
            messagebox.showinfo(APP, "Photos need an internet connection. Connect, then turn Photo on again.")
            return
        self.photo_on = True
        self._photo_cache = {}
        self.photo_btn.config(text="Photo: On", style="On.TButton")
        self._status("Photo on - the station's QRZ picture pops up when you Tab out of Call.", ok=True)

    def _hide_photo(self):
        """Contact logged - put the photo away until the next call."""
        self._photo_shown = ""
        w = getattr(self, "photo_win", None)
        if w and w.winfo_exists():
            self._remember_photo_pos(w)
            w.withdraw()

    def _remember_photo_pos(self, w):
        try:
            if w.winfo_ismapped():
                self.d["photo_pos"] = [w.winfo_x(), w.winfo_y()]
        except tk.TclError:
            pass

    def _photo_for_call(self):
        if not getattr(self, "photo_on", False):
            return
        base = base_call(self.q_call.get().strip().upper())
        if len(base) < 3 or not re.search(r"\d", base) or base == getattr(self, "_photo_shown", ""):
            return
        self._photo_shown = base
        if base in self._photo_cache:
            self._show_photo(base, self._photo_cache[base])
            return

        def work():
            data, name, why = None, "", ""
            try:
                info = self.qrz.lookup(base) or {}
                name = info.get("name", "")
                if not info:
                    why = "not found on QRZ"
                elif not info.get("image"):
                    why = "no photo on QRZ"
                else:
                    req = urllib.request.Request(info["image"], headers={"User-Agent": BROWSER_UA, "Accept": "image/*,*/*"})
                    with urllib.request.urlopen(req, timeout=12) as r:
                        data = r.read(3_000_001)
                    if len(data) > 3_000_000:
                        data, why = None, "photo too big"
            except QRZError as e:
                why = f"QRZ: {e}"
            except Exception as e:  # noqa: BLE001
                why = f"couldn't get the photo ({e})"
            self.ui_q.put((self._photo_got, (base, data, name, why)))
        threading.Thread(target=work, daemon=True).start()

    def _photo_got(self, base, data, name, why=""):
        if len(self._photo_cache) > 30:
            self._photo_cache.clear()
        if data or why in ("no photo on QRZ", "not found on QRZ"):  # don't remember network hiccups
            self._photo_cache[base] = (data, name, why)
        if base == self._photo_shown and getattr(self, "photo_on", False):
            self._show_photo(base, (data, name, why))

    def _show_photo(self, base, got):
        data, name, why = (tuple(got) + ("",))[:3]
        import io
        import base64
        w = getattr(self, "photo_win", None)
        had_focus = self.root.focus_get()
        if not (w and w.winfo_exists()):
            w = self.photo_win = tk.Toplevel(self.root)
            w.title("QRZ photo")
            w.resizable(False, False)
            try:
                w.attributes("-topmost", True)
                if IS_WIN:
                    w.attributes("-toolwindow", True)
            except tk.TclError:
                pass
            pos = self.d.get("photo_pos")  # where you last dragged it
            if pos and 0 <= pos[0] < self.root.winfo_screenwidth() - 40 and 0 <= pos[1] < self.root.winfo_screenheight() - 40:
                w.geometry(f"+{pos[0]}+{pos[1]}")
            else:
                x = self.root.winfo_rootx() + self.root.winfo_width() + 8
                w.geometry(f"+{min(x, self.root.winfo_screenwidth() - 380)}+{self.root.winfo_rooty()}")
            self._photo_lbl = tk.Label(w, bd=0)
            self._photo_lbl.pack()
            self._photo_cap = tk.Label(w, font=(UI_FONT, 12, "bold"), pady=4)
            self._photo_cap.pack(fill="x")
            w.protocol("WM_DELETE_WINDOW", lambda: (self._remember_photo_pos(w), w.withdraw()))
        w.deiconify()
        img = None
        if data:
            try:  # shrink with Pillow, then show as PNG (Tk shows PNG by itself - no extra pieces needed)
                from PIL import Image
                im = Image.open(io.BytesIO(data))
                im.thumbnail((360, 360))
                buf = io.BytesIO()
                im.convert("RGB").save(buf, "PNG")
                img = tk.PhotoImage(data=base64.b64encode(buf.getvalue()))
            except Exception as e:  # noqa: BLE001
                img, why = None, f"couldn't show the photo ({e})"
        if img:
            self._photo_lbl.config(image=img, text="", width=img.width(), height=img.height())
        else:
            self._photo_lbl.config(image="", text=f"{base}: {why or 'no photo on QRZ'}", width=34, height=8,
                                   wraplength=300)
            if why and why not in ("no photo on QRZ", "not found on QRZ"):
                self._status(f"Photo: {why}", ok=False)
        self._photo_lbl.image = img
        self._photo_cap.config(text=f"{base}  {name}".strip())
        if had_focus:  # keep typing where you were
            self.root.after(30, had_focus.focus_force)

    # ------------------------------------------------ activating on / off
    def activating(self):
        return bool(self.d.get("activating", True))

    def toggle_activating(self):
        self.d["activating"] = not self.activating()
        if not self.activating() and not fmt_grid(self.v_mygrid.get()):
            self.v_mygrid.set(fmt_grid(self.v_grid.get()))
        self._save()
        self._apply_activating()
        self._refresh_refs()
        self._status("Activating - park, self-spot and P2P are back." if self.activating() else
                     "Not activating - contacts log with your grid, no park. Great for home or the field.", ok=True)

    def _apply_activating(self):
        on = self.activating()
        self.act_btn.config(text="Activating: On" if on else "Activating: Off", style="On.TButton" if on else "TButton")
        self.act_frame.config(text="Activation" if on else "Station  (not activating)")
        for w in self._act_widgets:
            (w.grid if on else w.grid_remove)()
        for w in self._home_widgets:
            (w.grid_remove if on else w.grid)()
        self.p2p_lbl.config(text="P2P" if on else "Their park")
        show_spot = on or self._cluster_allowed()
        self.spot_btn.grid() if show_spot else self.spot_btn.grid_remove()
        self.spot_cmt_frame.grid() if show_spot else self.spot_cmt_frame.grid_remove()
        self._spot_msg("Comment is optional - leave blank for an automatic one." if on else
                       ("SPOT ME sends a DX cluster spot" + (f" for {self.event_call()}" if self.event_call() else "")
                        + " - special events only, never in contests. At most one every 15 minutes."
                        if show_spot else "No self-spotting while not activating (DX cluster spots can be allowed "
                                          "for special events in Settings > Spotting)."))
        self.tree.heading("their", text="P2P" if on else "Their park")
        self._refresh_their()
        self._refresh_grid_hint()

    def _my_grid_now(self):
        return fmt_grid(self.v_mygrid.get()) or fmt_grid(self.v_grid.get())

    def _refresh_grid_hint(self):
        if not hasattr(self, "grid_hint"):
            return
        g = self.v_mygrid.get().strip()
        if g and not fmt_grid(g):
            self.grid_hint.config(text="Grid should look like EM15 or EM15ab", foreground=col("#c0392b"))
            return
        src = getattr(self, "_grid_src", "")
        txt = ("from WSJT-X" if src == "wsjtx" else "type yours here - from WSJT-X automatically when it's running")
        if not g and self.v_grid.get().strip():
            txt = f"blank = your home grid {fmt_grid(self.v_grid.get())}"
        self.grid_hint.config(text=txt + "   \u00b7   Their park = a park you hunted (not P2P)",
                              foreground=col("#555"))

    # ------------------------------------------------ after each contact: backup + "Activated!"
    def _after_log(self, q):
        self._backup(q)
        refs = q.get("refs") or []
        if not refs:
            return
        prog = refs[0][0]
        goal = GOALS.get(prog)
        n = sum(1 for o in self.d["qsos"] if o["date"] == q["date"] and o.get("refs") == refs)
        if goal and n == goal:
            self._celebrate(f"ACTIVATED!  {n} contacts at {refs_text(refs)}")

    def _celebrate(self, text):
        """Bell + the counter flashes green a few times."""
        self.root.bell()
        self._status(text, ok=True)
        lbl = self.count_lbl
        normal_bg = lbl.cget("bg")

        def flash(i):
            if i >= 8:
                lbl.config(bg=normal_bg)
                self._update_counter()
                return
            lbl.config(bg=col("#1e7d4f") if i % 2 == 0 else normal_bg, fg="white" if i % 2 == 0 else col("#1e7d4f"))
            self.root.after(350, lambda: flash(i + 1))
        flash(0)

    def _backup(self, q):
        """Every contact also goes into a daily backup file the moment it's logged - safe even if the PC dies."""
        try:
            folder = os.path.join(DATA_DIR, "backup")
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, f"backup-{q['date']}.adi")
            new = not os.path.exists(path)
            with open(path, "a", encoding="utf-8", newline="\n") as fh:
                if new:
                    fh.write(f"{APP} automatic backup - every contact as it was logged\n"
                             + _f("ADIF_VER", "3.1.4") + _f("PROGRAMID", APP) + "<EOH>\n\n")
                for rec in self._records_for([q]):
                    fh.write((rec if isinstance(rec, str) else adif_record_text(rec)) + "\n")
        except OSError:
            pass

    # ------------------------------------------------ LoTW (through TQSL)
    def send_lotw(self):
        if self._event_blocks_send():
            return
        tq = find_tqsl()
        if not tq:
            if messagebox.askyesno(APP, "Send to LoTW uses ARRL's TQSL program, which isn't installed.\n\n"
                                        "Open the TQSL download page?"):
                webbrowser.open("https://lotw.arrl.org/lotw-help/installation/")
            return
        loc = (self.d.get("tqsl_loc") or "").strip().strip('"').strip()
        have = tqsl_locations()
        if not loc or (have and loc not in have):
            messagebox.showinfo(APP, (f"TQSL has no Station Location called \"{loc}\".\n\n" if loc else "")
                                + "Pick your TQSL Station Location: Settings > QRZ > LoTW station location."
                                + ("\n\nTQSL has: " + ", ".join(have) if have else ""))
            self.settings_dialog("QRZ")
            return
        todo = [q for q in self.d["qsos"] if not q.get("lotw_sent") and not q.get("station_call")]
        if not todo:
            messagebox.showinfo(APP, "No QSOs yet." if not self.d["qsos"] else "Every QSO here is already sent to LoTW.")
            return
        if not messagebox.askyesno(APP, f"Sign and upload {len(todo)} QSO(s) to LoTW with TQSL, using your "
                                        f"station location \"{loc}\"?"):
            return
        import tempfile
        tmp = tempfile.NamedTemporaryFile("w", suffix=".adi", delete=False, encoding="utf-8", newline="\n")
        tmp.write(_f("ADIF_VER", "3.1.4") + _f("PROGRAMID", APP) + "<EOH>\n\n")
        for rec in self._records_for(todo):
            tmp.write((rec if isinstance(rec, str) else adif_record_text(rec)) + "\n")
        tmp.close()
        ids = {q["id"] for q in todo}
        self.lotw_btn.config(state="disabled", text="Sending to LoTW...")
        self._status("TQSL is signing and uploading to LoTW...", ok=True)

        def work():
            import subprocess
            try:
                r = subprocess.run([tq, "-q", "-x", "-d", "-u", "-a", "compliant", "-l", loc, tmp.name],
                                   capture_output=True, text=True, timeout=300,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                code, err = r.returncode, (r.stderr or "").strip().splitlines()[-1:] or [""]
            except Exception as e:  # noqa: BLE001
                code, err = -1, [str(e)]
            try:
                os.remove(tmp.name)
            except OSError:
                pass
            self.ui_q.put((self._lotw_done, (code, err[0], ids)))
        threading.Thread(target=work, daemon=True).start()

    def _lotw_done(self, code, err, ids):
        ok = code in (0, 8, 9)
        if ok:
            for q in self.d["qsos"]:
                if q["id"] in ids:
                    q["lotw_sent"] = True
            self._save()
            self._refresh_table()
        self._refresh_send_buttons()
        why = TQSL_RESULTS.get(code, f"TQSL stopped (code {code})")
        self._status(f"LoTW: {why}." + ("" if ok or not err else f"  {err}"), ok=ok)
        if not ok:
            messagebox.showwarning(APP, f"LoTW: {why}.\n\n{err}\n\nCheck the station location name in Settings > QRZ "
                                        "matches TQSL exactly, and that your certificate is valid.")

    # ------------------------------------------------ Share: map picture + summary for social media
    def _station_ll(self, q):
        """Where the other station was: their grid, the park they were at, the callbook, their state, their country."""
        g = grid_latlon(q.get("grid"))
        if g:
            return g
        for p, r in q.get("their", []):
            g = grid_latlon(self.db.ref_grid(p, r))
            if g:
                return g
        cb = self.db.callbook_get(base_call(q["call"])) or {}
        g = grid_latlon(cb.get("grid"))
        if g:
            return g
        st = (q.get("state") or cb.get("state") or "").upper()
        if st in STATE_LL:
            return STATE_LL[st]
        country = (cb.get("country") or "").lower()
        if country:
            cents = _load_basemap()["cents"]
            for k in (country, {"usa": "united states of america", "united states": "united states of america",
                                "england": "united kingdom", "scotland": "united kingdom", "wales": "united kingdom",
                                "northern ireland": "united kingdom", "russia": "russia",
                                "european russia": "russia", "asiatic russia": "russia"}.get(country, "")):
                if k and k in cents:
                    return cents[k]
        return None

    def share_summary(self, qsos):
        """The words for a post: who, where, how many, bands and modes."""
        call = self._calls_for(qsos[0])[0] if qsos else self.v_call.get().strip().upper()
        refs = qsos[0].get("refs") if qsos else []
        where = refs_text(refs) if refs else ""
        name = ((self.db.ref_get(*refs[0]) or {}).get("name") or "") if refs else ""
        days = sorted({q["date"] for q in qsos})
        d0 = datetime.strptime(days[0], "%Y%m%d").strftime("%d %b %Y") if days else ""
        bands = sorted({q["band"] for q in qsos}, key=lambda b: -float(re.sub(r"[^0-9.]", "", b) or 0))
        modes = sorted({q["mode"] for q in qsos})
        p2p = sum(1 for q in qsos if q.get("their"))
        states = sorted({(q.get("state") or "").upper() for q in qsos if q.get("state")})
        title = f"{call}" + (f" at {where}" if where else "") + (f" - {name}" if name else "")
        line1 = f"{len(qsos)} QSOs" + (f"  \u00b7  {p2p} park-to-park" if p2p and refs else
                                      (f"  \u00b7  {p2p} parks hunted" if p2p else "")) + \
                (f"  \u00b7  {len(states)} states" if len(states) > 1 else "")
        line2 = "  ".join(bands) + "   " + " ".join(modes) + (f"   \u00b7   {d0}" if d0 else "")
        tags = " ".join(t for t in ("#" + refs[0][0] if refs else "", "#hamradio",
                                    "#" + refs[0][0].lower() + "activation" if refs else "") if t)
        text = f"{title}\n{line1}\n{line2}\nThanks to everyone who called!\n{tags}".strip()
        return title, [line1, line2], text

    def share(self):
        qsos = self.d["qsos"]
        if not qsos:
            messagebox.showinfo(APP, "Log some contacts first - then Share makes a map picture and a summary to post.")
            return
        try:
            import PIL  # noqa: F401
        except ImportError:
            messagebox.showinfo(APP, "The map picture needs the Pillow library:\n\n"
                                     + ("pip install pillow" if IS_WIN else "sudo apt install python3-pil   "
                                        "(or: pip install --user pillow)")
                                     + "\n\nThe summary text is copied to your clipboard anyway.")
            self.root.clipboard_clear()
            self.root.clipboard_append(self.share_summary(qsos)[2])
            return
        # the current activation (the latest park / day) - not a mix
        last = qsos[-1]
        mine = [q for q in qsos if q.get("refs") == last.get("refs") and
                (q["date"] == last["date"] if not last.get("refs") else True)]
        stations = []
        for q in mine:
            ll = self._station_ll(q)
            if ll:
                stations.append((ll[0], ll[1], bool(q.get("their"))))
        prog, ref, grid = self._where(last)
        me = grid_latlon(grid)
        title, lines_txt, text = self.share_summary(mine)
        folder = self._export_dir()
        if not folder:
            return
        name = re.sub(r"[^A-Za-z0-9@_-]+", "_", f"share-{self._calls_for(last)[0]}-{ref or 'log'}-{last['date']}") + ".png"
        path = os.path.join(folder, name)
        self._status("Drawing the map...", ok=True)
        self.root.update_idletasks()
        try:
            render_share_png(path, me, stations, title, lines_txt)
        except Exception as e:  # noqa: BLE001
            messagebox.showwarning(APP, f"Couldn't draw the map picture:\n{e}")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        missing = len(mine) - len(stations)
        self._show_in_folder(path)
        messagebox.showinfo(APP, f"Saved the picture:\n{path}\n\nThe words for your post are on the clipboard "
                                 "(Ctrl+V):\n\n" + text +
                            (f"\n\n({missing} station(s) aren't on the map - no location known for them.)"
                             if missing else ""))

    def _wsjtx_grid(self, grid):
        """WSJT-X tells us the grid set in its own Settings - use it while not activating, unless typed over."""
        grid = fmt_grid(grid)
        if not grid or self._grid_typed or self.activating():
            return
        if grid != fmt_grid(self.v_mygrid.get()) or getattr(self, "_grid_src", "") != "wsjtx":
            self.v_mygrid.set(grid)
            self._grid_src = "wsjtx"
            self._save()
            self._refresh_grid_hint()

    def _roster_msg(self, kind, data, addr):
        r = getattr(self, "roster", None)
        if not r:
            return
        if kind == 1:
            r.on_status(data)
        else:
            r.on_decode(data, addr)

    def port_picker(self, parent=None):
        """List every serial port with its full description, so the right one is easy to pick."""
        if not HAVE_SERIAL:
            messagebox.showinfo(APP, "Radio control over USB needs pyserial:\n\n" + PYSERIAL_CMD, parent=parent)
            return
        w = tk.Toplevel(parent or self.root)
        w.title("Find my radio")
        w.transient(parent or self.root)
        w.geometry("640x340")
        w.columnconfigure(0, weight=1)
        w.rowconfigure(1, weight=1)
        ttk.Label(w, text="Plug the radio in and turn it on, then pick its port and click Use this port.\n"
                          "Yaesu FT-710 / FT-991A: pick the one that says Enhanced.   \u2605 = looks like a radio.",
                  padding=(10, 8, 10, 4), justify="left").grid(row=0, column=0, sticky="w")
        tv = ttk.Treeview(w, columns=("port", "what"), show="headings", selectmode="browse")
        tv.heading("port", text="Port")
        tv.heading("what", text="What it is")
        tv.column("port", width=130, stretch=False)
        tv.column("what", width=480)
        tv.grid(row=1, column=0, sticky="nsew", padx=10)
        radio_words = ("enhanced", "cp210", "silicon labs", "icom", "ftdi", "ch340", "ch34", "prolific", "pl2303",
                       "yaesu", "xiegu", "usb serial", "uart")

        def fill():
            tv.delete(*tv.get_children())
            ports = sorted(serial.tools.list_ports.comports(), key=lambda p: p.device)
            best = None
            for p in ports:
                desc = " ".join(x for x in (p.description, p.manufacturer or "") if x and x != "n/a").strip()
                if p.vid is not None:
                    desc += f"   (USB {p.vid:04X}:{p.pid:04X})"
                likely = any(k in desc.lower() for k in radio_words)
                tv.insert("", "end", iid=p.device, values=(("\u2605 " if likely else "   ") + p.device,
                                                           desc or "serial port"))
                if best is None and "enhanced" in desc.lower():
                    best = p.device
                elif best is None and likely:
                    best = p.device
            if not ports:
                tv.insert("", "end", iid="none", values=("-", "No ports found. Is the radio on and its USB cable "
                                                              "plugged in? Click Refresh."))
            pick = best or (self.v_port.get() if self.v_port.get() in tv.get_children() else None)
            if pick and pick in tv.get_children():
                tv.selection_set(pick)
                tv.see(pick)

        def use(*_):
            sel = tv.selection()
            if sel and sel[0] != "none":
                self.v_port.set(sel[0])
                self._save()
                w.destroy()
        b = ttk.Frame(w, padding=10)
        b.grid(row=2, column=0, sticky="e")
        ttk.Button(b, text="Refresh", command=fill).grid(row=0, column=0, padx=4)
        ttk.Button(b, text="Use this port", command=use).grid(row=0, column=1, padx=4)
        ttk.Button(b, text="Cancel", command=w.destroy).grid(row=0, column=2)
        tv.bind("<Double-1>", use)
        tv.bind("<Return>", use)
        fill()

    def _update_band(self):
        khz = parse_freq_khz(self.v_freq.get())
        self.band_lbl.config(text=band_for(khz) if khz else "")

    def _set_pota_prefix(self):
        global DEFAULT_POTA_PREFIX
        progs = [c for c in re.split(r"[,\s]+", self.d.get("pota_programs", "")) if c]
        DEFAULT_POTA_PREFIX = progs[0] if progs else "US"

    def _tidy_refs(self, var):
        refs = parse_refs(var.get())
        if refs and all(p for p, _ in refs):
            var.set(", ".join(r if guess_program(r) == p else f"{p}:{r}" for p, r in refs))

    def _refresh_refs(self):
        refs = parse_refs(self.v_refs.get())
        unknown = [r for p, r in refs if not p]
        text = ("   \u00b7   ".join(self._ref_desc(p, r) for p, r in refs) if refs and hasattr(self, "db")
                else refs_label(refs))
        if unknown:
            text += "    (put POTA:, SOTA:, GMA:, LLOTA: ... in front of ?? refs)"
        elif refs and hasattr(self, "db"):
            g = self._grid_for(*refs[0])
            if g and g != self.v_grid.get().strip():
                text += f"    \u00b7   my grid {g}"
        self.refs_lbl.config(text=text, foreground=col("#c0392b") if unknown else col("#555"))
        progs = [p for p, _ in refs]
        goal = next((GOALS[p] for p in progs if p in GOALS), None) if self.activating() else None
        self.goal = goal
        self._update_counter()

    def _set_rst_defaults(self, old_mode, new_mode):
        old, new = default_rst(old_mode), default_rst(new_mode)
        for v in (self.q_rs, self.q_rr):
            if v.get().strip() in ("", old):
                v.set(new)

    def _mode_picked(self):
        old = self.d.get("mode", "SSB")
        self._set_rst_defaults(old, self.v_mode.get())
        self._save()
        self._push_to_radio()

    def _freq_enter(self, _e):
        self._push_to_radio()
        self._save()
        return "break"

    def _enter_key(self, e):
        if e.widget is self.freq_entry:
            return
        if e.widget is getattr(self, "spot_cmt_entry", None):
            self._save()
            self.call_entry.focus_set()
            return "break"
        self.log_qso()

    def _clear_form(self):
        if hasattr(self, "photo_btn"):
            self._hide_photo()  # Esc / logging: the photo goes with the contact
        rst = default_rst(self.v_mode.get())
        for v, val in ((self.q_call, ""), (self.q_state, ""), (self.q_their, ""), (self.q_comment, ""),
                       (self.q_rs, rst), (self.q_rr, rst)):
            v.set(val)
        self.q_name.set("")
        self.q_country.set("")
        self._auto_name = ""
        self._auto_state = ""
        self._auto_country = ""
        self.call_entry.focus_set()

    def info_hint(self, text):
        self.info_lbl.config(text=text, fg=col("#c0392b"))

    def _auto_update_refs(self):
        """Refresh park/summit lists in the background when online and they're missing or old."""
        last = self.d.get("refs_updated", "")
        try:
            age = (utc_now() - datetime.strptime(last, "%Y-%m-%d").replace(tzinfo=timezone.utc)).days if last else 999
        except ValueError:
            age = 999
        if age < 30 and self.db.refs_counts() and self.db.refs_have_grids():
            return
        codes = [c for c in re.split(r"[,\s]+", self.d.get("pota_programs", "") or "US") if c]

        def work():
            try:  # quick online check first so nothing happens when you're in the field
                _download("https://api.pota.app/", timeout=6)
            except urllib.error.HTTPError:
                pass  # server answered - we're online
            except Exception:  # noqa: BLE001
                return
            self.ui_q.put((self._run_ref_update, (codes, True)))
        threading.Thread(target=work, daemon=True).start()

    def _spot_msg(self, text, ok=True):
        self.spot_lbl.config(text=text, foreground=col("#1e7d4f") if ok else col("#c0392b"))
        self._status_var.set(text)

    def _pump(self):
        """Hands background results to the screen. One bad result must never stop it - before 1.36 an error here
        stopped spots, lookups and everything else until the app was restarted."""
        try:
            while True:
                try:
                    fn, args = self.ui_q.get_nowait()
                except queue.Empty:
                    break
                try:
                    fn(*args)
                except Exception:  # noqa: BLE001
                    _log_error()
        finally:
            self.root.after(100, self._pump)

    def _tick(self):
        now = utc_now()
        extra = ""
        qs = self.d["qsos"]
        if qs:
            first = datetime.strptime(qs[0]["date"] + qs[0]["time"], "%Y%m%d%H%M").replace(tzinfo=timezone.utc)
            mins = int((now - first).total_seconds() // 60)
            if 0 <= mins < 1440:
                extra = f"  on air {mins // 60}:{mins % 60:02d}"
        self.clock_lbl.config(text=now.strftime("%H:%M:%SZ") + extra)
        self._midnight_check(now)
        self.root.after(1000, self._tick)

    def _midnight_check(self, now):
        """POTA (and WWFF/SOTA) days run on UTC. Warn at 23:50Z, and at 00:00Z offer to start the new day's log."""
        if not (self.activating() and self.d["qsos"]):
            return
        today = now.strftime("%Y%m%d")
        if now.hour == 23 and now.minute >= 50 and getattr(self, "_warned_day", "") != today:
            self._warned_day = today
            self.root.bell()
            self._status("10 minutes to 0000 UTC - a new POTA day starts then (your count goes back to 0).", ok=False)
        if now.hour == 0 and now.minute < 10 and getattr(self, "_asked_day", "") != today \
                and all(q["date"] < today for q in self.d["qsos"]):
            self._asked_day = today
            self.root.bell()
            if messagebox.askyesno(APP, "It's past 0000 UTC - a new POTA day has started.\n\n"
                                        "Export yesterday's log now and start a fresh log for today?\n"
                                        "(Same park - the count starts again from 0.)"):
                if self.export_adif():
                    self.d["qsos"] = []
                    self._save()
                    self._refresh_table()

    def _update_counter(self):
        today = utc_now().strftime("%Y%m%d")
        n = sum(1 for q in self.d["qsos"] if q["date"] == today)
        goal = getattr(self, "goal", None)
        self.count_lbl.config(text=str(n), fg=col("#1e7d4f") if (goal and n >= goal) else
                              (col("#c0392b") if goal else col("#333")))
        hour_ago = (utc_now() - timedelta(hours=1)).strftime("%Y%m%d%H%M")
        rate = sum(1 for q in self.d["qsos"] if q["date"] + q["time"][:4] >= hour_ago)
        self.goal_lbl.config(text=(f"of {goal} today (UTC)" if goal else "QSOs today (UTC)")
                             + (f"   {rate}/hr" if rate else ""))

    def _refresh_table(self):
        self.tree.delete(*self.tree.get_children())
        for i, q in enumerate(self.d["qsos"], 1):
            their = ",".join(r for _p, r in q.get("their", []))
            self.tree.insert("", "end", iid=str(q["id"]), values=(
                f"{i} " + ("Q" if q.get("qrz_sent") else "") + ("L" if q.get("aclog_sent") else "") + ("W" if q.get("lotw_sent") else "") + ("E" if q.get("station_call") else ""), f"{q['time'][:2]}:{q['time'][2:]}", q["call"], q.get("name", ""), q["rst_s"], q["rst_r"],
                q.get("state", ""), their, fmt_khz(q["freq_khz"]), q["band"], q["mode"], q.get("comment", "")))
        kids = self.tree.get_children()
        if kids:
            self.tree.see(kids[-1])
        self._update_counter()
        self._refresh_send_buttons()

    def _check_station(self):
        call = self.v_call.get().strip().upper()
        if not CALL_RE.match(call):
            messagebox.showwarning(APP, "Enter your callsign in 'My call' first.")
            return None
        if not self.activating():
            khz = parse_freq_khz(self.v_freq.get())
            if not khz or not band_for(khz):
                messagebox.showwarning(APP, "Frequency isn't in a ham band (e.g. 14331 or 14.331).")
                return None
            return call, [], khz
        refs = parse_refs(self.v_refs.get())
        if not refs:
            messagebox.showwarning(APP, "Enter at least one reference (e.g. US-1234, KFF-1234, W5/OK-001).\n\n"
                                        "Not at a park? Click 'Activating: On' to turn it off.")
            return None
        unknown = [r for p, r in refs if not p]
        if unknown:
            messagebox.showwarning(APP, f"Which program is {', '.join(unknown)}?\n\n"
                                   "Put the program in front, like  GMA:DL/EW-017  or  LLOTA:US-0001")
            return None
        khz = parse_freq_khz(self.v_freq.get())
        if not khz or not band_for(khz):
            messagebox.showwarning(APP, "Frequency isn't in a ham band (e.g. 14331 or 14.331).")
            return None
        return call, refs, khz

    # ------------------------------------------------ menu, lookups, ACLog, QRZ
    def _build_menu(self):
        mb = tk.Menu(self.root)
        m = tk.Menu(mb, tearoff=0)
        m.add_command(label="Settings...", command=self.settings_dialog)
        m.add_command(label="Find a park or summit...", command=lambda: self.find_ref("mine"))
        m.add_separator()
        m.add_command(label="Update everything now (before you leave home)", command=self._update_everything)
        m.add_separator()
        m.add_command(label="Check for updates...", command=lambda: self.check_updates(quiet=False))
        m.add_command(label="Make desktop shortcut", command=self.make_shortcut)
        m.add_separator()
        m.add_command(label="About / Credits...", command=self.about)
        mb.add_cascade(label="Settings", menu=m)
        self.root.config(menu=mb)

    # --- update check: grey version = up to date, red = a newer one is out
    def check_updates(self, quiet=True):
        if not quiet:
            self.ver_lbl.config(text=f"v{VERSION} - checking...")
        threading.Thread(target=lambda: self.ui_q.put((self._update_result, (fetch_latest(), quiet))),
                         daemon=True).start()

    def _update_result(self, info, quiet):
        newer = bool(info) and ver_tuple(info["pc"]) > ver_tuple(VERSION)
        if newer:
            self._latest = info
            self.ver_lbl.config(text=f"v{VERSION} - v{info['pc']} is out, click to update",
                                fg=col("#c0392b"), font=(UI_FONT, 9, "bold"))
        else:
            self.ver_lbl.config(text=f"v{VERSION}", fg=col("#888"), font=(UI_FONT, 9))
        if quiet:
            return
        if newer:
            self._offer_update(info)
        elif info:
            messagebox.showinfo(APP, f"You're up to date (v{VERSION}).")
        else:
            messagebox.showwarning(APP, "Couldn't reach the update page. Check the internet and try again.")

    def _offer_update(self, info):
        notes = str(info.get("notes", "")).strip()
        msg = f"Version {info['pc']} is out (you have {VERSION}).\n\n" + (notes + "\n\n" if notes else "")
        if os.name == "nt" and getattr(sys, "frozen", False):
            if messagebox.askyesno(APP, msg + "Download and install it now?\n\nThe logger closes while it "
                                   "installs. Your log and settings are kept."):
                self.ver_lbl.config(text="Downloading update...")
                threading.Thread(target=self._download_update, daemon=True).start()
        elif messagebox.askyesno(APP, msg + "Open the download page?"):
            webbrowser.open(DOWNLOAD_PAGE)

    def _download_update(self):
        path = os.path.join(os.environ.get("TEMP") or DATA_DIR, "Raw_Ham_Lite_Logger_Setup.exe")
        try:
            req = urllib.request.Request(SETUP_URL, headers={"User-Agent": f"RawHamsLiteLogger/{VERSION}"})
            with urllib.request.urlopen(req, timeout=60) as r, open(path, "wb") as out:
                while True:
                    b = r.read(1 << 16)
                    if not b:
                        break
                    out.write(b)
            with open(path, "rb") as fh:
                ok = fh.read(2) == b"MZ" and os.path.getsize(path) > 1_000_000
            if not ok:
                raise IOError("the download didn't look right")
            self.ui_q.put((self._run_installer, (path,)))
        except Exception as e:
            self.ui_q.put((self._update_failed, (str(e),)))

    def _run_installer(self, path):
        try:
            os.startfile(path)
        except Exception as e:
            self._update_failed(str(e))
            return
        self.close()

    def _update_failed(self, why):
        self.ver_lbl.config(text=f"v{VERSION} - update failed, click to try again", fg=col("#c0392b"))
        if messagebox.askyesno(APP, f"Couldn't download the update ({why}).\n\nOpen the download page instead?"):
            webbrowser.open(DOWNLOAD_PAGE)

    def _status(self, text, ok=True):
        self._spot_msg(text, ok)

    # --- live lookup while typing a call
    def _schedule_lookup(self):
        if self._lookup_job:
            self.root.after_cancel(self._lookup_job)
        self._lookup_job = self.root.after(250, self._do_lookup)

    def _do_lookup(self):
        self._lookup_job = None
        call = self.q_call.get().strip().upper()
        base = base_call(call)
        self._cur_base, self._cur_name = base, ""
        if len(base) < 3 or not re.search(r"\d", base):
            if self._auto_state and self.q_state.get() == self._auto_state:
                self.q_state.set("")
            self._auto_state = ""
            if self.q_name.get() == self._auto_name:
                self.q_name.set("")
            self._auto_name = ""
            if self.q_country.get() == self._auto_country:
                self.q_country.set("")
            self._auto_country = ""
            self.info_lbl.config(text="", fg=col("#555"))
            return
        info = self.db.callbook_get(base)
        if not (info and info.get("name")):
            info = self.db.offline_get(base) or info
        self._render_lookup(base, info)
        saved = self.db.callbook_get(base)
        stale = not saved or (time.time() - (saved.get("fetched") or 0)) > CALLBOOK_MAX_AGE_DAYS * 86400
        if stale and self.qrz and base not in self._lookup_busy:
            self._lookup_busy.add(base)
            threading.Thread(target=self._qrz_fetch, args=(base,), daemon=True).start()

    def _qrz_fetch(self, base, quiet=False):
        try:
            info = self.qrz.lookup(base)
            self.db.callbook_put(base, info or {"call": base})
            if not quiet:
                self.ui_q.put((self._after_fetch, (base,)))
            return True
        except QRZError as e:
            self.ui_q.put((self._qrz_problem, (str(e),)))
        except Exception:  # noqa: BLE001  offline: just use what's saved
            pass
        finally:
            self._lookup_busy.discard(base)
        return False

    def _after_fetch(self, base):
        if base_call(self.q_call.get()) == base:
            info = self.db.callbook_get(base)
            if not (info and info.get("name")):
                info = self.db.offline_get(base) or info
            self._render_lookup(base, info)

    def _qrz_problem(self, msg):
        if not self._qrz_warned:
            self._qrz_warned = True
            self._status(f"QRZ: {msg}  (Settings > QRZ)", ok=False)

    def _render_lookup(self, base, info):
        khz = parse_freq_khz(self.v_freq.get()) or 0
        band, mode = band_for(khz), self.v_mode.get()
        total, last, same, log_name, log_state = self.db.worked(base, band, mode)
        name = (info or {}).get("name") or log_name
        state = (info or {}).get("state") or log_state
        src = (info or {}).get("src") or ("QRZ" if (info or {}).get("name") else ("your log" if log_name else ""))
        self._cur_name = name
        bits = []
        if name:
            where = ", ".join(x for x in ((info or {}).get("qth", ""), state) if x)
            country = (info or {}).get("country", "")
            if country and country not in ("United States", "USA"):
                where = ", ".join(x for x in (where, country) if x)
            bits.append(f"{where or name}  [{src}]" if where else f"[{src}]")
        else:
            bits.append("not in callbook")
        # fill Name like ACLog does, unless you've typed your own
        if not self.q_name.get() or self.q_name.get() == self._auto_name:
            self.q_name.set(name)
            self._auto_name = name
        if total:
            d, t, b, m = last
            when = f"{d[:4]}-{d[4:6]}-{d[6:8]}" if len(d) == 8 else d
            bits.append(f"Worked {total}x before, last {when} {b} {m}")
            bits.append(f"already worked on {band} {mode}" if same else f"NEW on {band} {mode}")
            note = self.db.last_comment(base)
            if note:
                nd = note[1] or ""
                nd = f"{nd[:4]}-{nd[4:6]}-{nd[6:8]}" if len(nd) == 8 else nd
                text = note[0] if len(note[0]) <= 60 else note[0][:57] + "..."
                bits.append(f'your note ({nd}): "{text}"')
            color = col("#1f4e8c")
        else:
            bits.append("First QSO with this station!")
            color = col("#1e7d4f")
        self.info_lbl.config(text="     ·     ".join(bits), fg=color)
        # fill Country (DXCC country from the call's prefix; the callbook's if the prefix is unknown)
        if not self.q_country.get() or self.q_country.get() == self._auto_country:
            ctry = country_of(self.q_call.get()) or (info or {}).get("country", "")
            self.q_country.set(ctry)
            self._auto_country = ctry
        # fill State if it's empty or we filled it before
        mine = not self.q_state.get() or self.q_state.get() == self._auto_state
        if mine:
            new = state.upper() if state and len(state) <= 3 else ""
            self.q_state.set(new)
            self._auto_state = new

    # --- ACLog log file
    def choose_aclog(self):
        path = filedialog.askopenfilename(title="Choose your ACLog LogData.mdb",
                                          initialdir=os.path.dirname(self.d.get("aclog_path") or HERE),
                                          filetypes=[("ACLog log", "*.mdb"), ("All files", "*.*")])
        if path:
            self.d["aclog_path"] = path
            self._save()
            self.sync_aclog()

    def sync_aclog(self, quiet=False):
        path = self.d.get("aclog_path") or DEFAULT_ACLOG
        if not os.path.exists(path):
            if not quiet:
                messagebox.showinfo(APP, f"Couldn't find your ACLog log at:\n{path}\n\n"
                                    "Use Settings > Offline data > Choose ACLog log file.")
            return
        try:
            import access_parser  # noqa: F401
        except ImportError:
            if not quiet:
                messagebox.showinfo(APP, "Reading the ACLog file needs one free add-on. In Command Prompt run:\n\n"
                                    "    " + ACCESS_CMD + "\n\nthen restart the logger.\n\n"
                                    "Or export an ADIF from ACLog and use 'Import worked-before from an ADIF file'.")
            return
        self._status("Reading your ACLog log...", ok=True)

        def work():
            try:
                n = read_aclog_into(self.db, path)
                self.d["aclog_mtime"] = os.path.getmtime(path)
                msg, ok = f"ACLog synced: {n:,} QSOs available for worked-before checks.", True
            except Exception as e:  # noqa: BLE001
                msg, ok = (f"Couldn't read the ACLog file ({e}). Export an ADIF from ACLog and "
                           "use 'Import worked-before from an ADIF file' instead."), False
            self.ui_q.put((self._status, (msg, ok)))
        threading.Thread(target=work, daemon=True).start()

    def import_adif(self):
        path = filedialog.askopenfilename(title="Choose an ADIF file (e.g. exported from ACLog)",
                                          filetypes=[("ADIF", "*.adi *.adif"), ("All files", "*.*")])
        if not path:
            return
        self._status("Importing ADIF...", ok=True)

        def work():
            try:
                n = self.db.import_adif(path)
                msg, ok = f"Imported {n:,} QSOs for worked-before checks.", True
            except Exception as e:  # noqa: BLE001
                msg, ok = f"ADIF import failed: {e}", False
            self.ui_q.put((self._status, (msg, ok)))
        threading.Thread(target=work, daemon=True).start()

    # --- park & summit lists (offline)
    def _run_ref_update(self, codes, auto):
        if getattr(self, "_refs_busy", False):
            return
        self._refs_busy = True

        def work():
            report = []
            jobs = [(f"POTA {c}", lambda c=c: ("POTA", fetch_pota_parks(c), c)) for c in codes]
            jobs += [("SOTA", lambda: ("SOTA", fetch_sota_summits(), None)),
                     ("WWFF", lambda: ("WWFF", fetch_wwff_refs(), None))]
            for label, fn in jobs:
                self.ui_q.put((self._status, (f"Downloading {label} list...", True)))
                try:
                    prog, rows, prefix = fn()
                    if not rows:
                        raise ValueError("list came back empty")
                    self.db.replace_refs(prog, rows, prefix)
                    report.append(f"{label}: {len(rows):,}")
                except Exception as e:  # noqa: BLE001
                    report.append(f"{label}: FAILED ({e})")
            ok = not any("FAILED" in r for r in report)
            if any("FAILED" not in r for r in report):
                self.d["refs_updated"] = utc_now().strftime("%Y-%m-%d")
                self.ui_q.put((self._save, ()))
            self._refs_busy = False
            self.ui_q.put((self._status, (("Park & summit lists refreshed - " if auto else "Reference lists updated - ")
                                          + "   ".join(report), ok)))
            self.ui_q.put((self._refresh_refs, ()))
        threading.Thread(target=work, daemon=True).start()

    def _ref_desc(self, prog, ref):
        info = self.db.ref_get(prog, ref) if prog else None
        if not info:
            return f"{prog or '??'} {ref}"
        loc = f" ({info['loc']})" if info.get("loc") else ""
        return f"{prog} {ref} {info['name']}{loc}"

    def _refresh_their(self, *_):
        refs = parse_refs(self.q_their.get())
        if not refs:
            self.their_lbl.config(text="")
        elif len(refs) == 1:
            self.their_lbl.config(text=("P2P:  " if self.activating() else "Hunted:  ") + self._ref_desc(*refs[0]))
        else:
            self.their_lbl.config(text=("P2P" if self.activating() else "Hunted") + f" - {len(refs)} parks (one record each in the export):\n" + "\n".join(
                f"   {i}.  {self._ref_desc(p, r)}" for i, (p, r) in enumerate(refs, 1)))

    def find_ref(self, target):
        """Search the saved lists by name or number; target = 'mine' or 'theirs'."""
        var = self.v_refs if target == "mine" else self.q_their
        w = tk.Toplevel(self.root)
        w.title("Find a park or summit")
        w.transient(self.root)
        w.geometry("720x420")
        w.columnconfigure(0, weight=1)
        w.rowconfigure(1, weight=1)
        q = tk.StringVar()
        top = ttk.Frame(w, padding=8)
        top.grid(row=0, column=0, sticky="ew")
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Name or number").grid(row=0, column=0)
        e = ttk.Entry(top, textvariable=q, font=self.mono)
        e.grid(row=0, column=1, sticky="ew", padx=6)
        cnt = self.db.refs_counts()
        hint = ("  ".join(f"{k} {v:,}" for k, v in cnt.items()) if cnt else
                "No lists saved yet - use Settings > Offline data > Update park & summit lists while online.")
        ttk.Label(top, text=hint, foreground=col("#777")).grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        tv = ttk.Treeview(w, columns=("prog", "ref", "name", "loc"), show="headings")
        for k, t, wd in (("prog", "Prog", 60), ("ref", "Reference", 110), ("name", "Name", 280), ("loc", "Location", 220)):
            tv.heading(k, text=t)
            tv.column(k, width=wd, stretch=k in ("name", "loc"))
        tv.grid(row=1, column=0, sticky="nsew", padx=8)
        ttk.Label(w, text="Double-click or Enter to use it" +
                  ("  (adds to your references)" if target == "mine" else ""),
                  foreground=col("#777")).grid(row=2, column=0, sticky="w", padx=8, pady=6)

        def search(*_):
            tv.delete(*tv.get_children())
            for r in self.db.ref_search(q.get()):
                tv.insert("", "end", values=r)
            kids = tv.get_children()
            if kids:
                tv.selection_set(kids[0])
                tv.focus(kids[0])

        def pick(*_):
            sel = tv.selection()
            if not sel:
                return
            prog, ref = tv.item(sel[0])["values"][:2]
            token = ref if guess_program(ref) == prog else f"{prog}:{ref}"
            if target == "mine":
                cur = [t for t in re.split(r"\s*,\s*", var.get().strip()) if t and t.upper() != "K-TEST"]
                if token not in cur:
                    cur.append(token)
                var.set(", ".join(cur))
                self._save()
            else:
                cur = [t for t in re.split(r"\s*,\s*", var.get().strip()) if t]
                # drop a half-typed search word, keep refs already chosen
                cur = [t for t in cur if parse_refs(t) and parse_refs(t)[0][0]]
                if token not in cur:
                    cur.append(token)
                var.set(", ".join(cur))
                self._tidy_refs(var)
            w.destroy()
            (self.call_entry if target == "theirs" else self.call_entry).focus_set()
            return "break"

        q.trace_add("write", search)
        last = var.get().split(",")[-1].strip()
        q.set(last if target == "theirs" and last and not (parse_refs(last) and parse_refs(last)[0][0]) else "")
        e.bind("<Return>", pick)
        e.bind("<Down>", lambda _e: (tv.focus_set(), "break")[1])
        tv.bind("<Double-1>", pick)
        tv.bind("<Return>", pick)
        w.bind("<Escape>", lambda _e: w.destroy())
        e.focus_set()

    # --- offline callbook download
    def update_offline_callbook(self):
        if getattr(self, "_cb_busy", False):
            messagebox.showinfo(APP, "The offline callbook is already downloading.")
            return
        if not messagebox.askyesno(APP, "Download the offline callbook?\n\n"
                                        "  - US: FCC amateur license database (every active US ham)\n"
                                        "  - Canada: ISED amateur call sign list\n\n"
                                        "This is the same free government data ACLog's Calldata uses. "
                                        "The FCC download is large (well over 100 MB) and takes several "
                                        "minutes; it is deleted after processing. The saved callbook uses "
                                        "roughly 60-100 MB.\n\nYou can keep logging while it runs."):
            return
        self._cb_busy = True
        import tempfile

        def work():
            tmpdir = tempfile.mkdtemp(prefix="rawhams_cb_")
            report = []
            try:
                for label, url, fname, parser in (("US (FCC)", FCC_URLS, "l_amat.zip", parse_fcc_zip),
                                                  ("Canada", CANADA_URL, "amateur_delim.zip", parse_canada_zip)):
                    path = os.path.join(tmpdir, fname)
                    try:
                        def prog(got, total, label=label):
                            mb = got / 1e6
                            pct = f" ({got * 100 // total}%)" if total else ""
                            self.ui_q.put((self._status, (f"Callbook: downloading {label} {mb:.0f} MB{pct}...", True)))
                        download_file(url, path, prog)
                        self.ui_q.put((self._status, (f"Callbook: building {label} - this takes a few minutes...", True)))
                        country = "USA" if parser is parse_fcc_zip else "Canada"
                        n = self.db.offline_replace(country, parser(path))
                        if not n:
                            raise ValueError("no call signs found in the file")
                        report.append(f"{label}: {n:,} calls")
                    except Exception as e:  # noqa: BLE001
                        report.append(f"{label}: FAILED ({e})")
                    finally:
                        try:
                            os.remove(path)
                        except OSError:
                            pass
            finally:
                try:
                    os.rmdir(tmpdir)
                except OSError:
                    pass
                self._cb_busy = False
            self.d["callbook_updated"] = utc_now().strftime("%Y-%m-%d")
            ok = not any("FAILED" in r for r in report)
            self.ui_q.put((self._save, ()))
            self.ui_q.put((self._status, ("Offline callbook updated - " + "   ".join(report), ok)))
        threading.Thread(target=work, daemon=True).start()

    # --- logbook connections: QRZ Logbook, other loggers (UDP), WSJT-X
    def _event_blocks_send(self):
        if self.event_call():
            messagebox.showinfo(APP, f"Sending is off while the special event call {self.event_call()} is in use - "
                                     "use Export ADIF and send the file to the event.\n\n"
                                     "(Clear the call in Settings > My station when the event is over.)")
            return True
        return False

    def upload_to_qrz(self):
        if self._event_blocks_send():
            return
        key = self.d.get("qrz_key", "")
        if not key:
            messagebox.showinfo(APP, "Add your QRZ Logbook API key first: Settings > QRZ.")
            return
        todo = [q for q in self.d["qsos"] if not q.get("qrz_sent") and not q.get("station_call")]
        if not todo:
            messagebox.showinfo(APP, "Every QSO in this activation is already on QRZ."
                                + (" (Special event contacts are never sent - use Export ADIF.)"
                                   if any(q.get("station_call") for q in self.d["qsos"]) else ""))
            return
        call = self.v_call.get().strip().upper()
        if not CALL_RE.match(call):
            messagebox.showwarning(APP, "Enter your callsign in 'My call' first.")
            return
        if not messagebox.askyesno(APP, f"Send {len(todo)} QSO(s) to your QRZ logbook?"):
            return
        places = {q["id"]: self._where(q) for q in todo}
        self._status("Sending to QRZ...", ok=True)

        def work():
            done, dupes, fails = [], 0, []
            lb = QRZLogbook(key)
            for q in todo:
                prog, ref, grid = places[q["id"]]
                ok_all = True
                for rec in adif_records(build_adif([q], call, prog, ref, grid)):
                    try:
                        res, why = lb.insert(rec, replace=bool(q.get("qrz_replace")))
                    except Exception as e:  # noqa: BLE001
                        res, why = "fail", str(e)
                    if res == "dupe":
                        dupes += 1
                    elif res == "fail":
                        ok_all = False
                        fails.append(f"{q['call']}: {why}")
                if ok_all:
                    done.append(q["id"])
            self.ui_q.put((self._qrz_uploaded, (done, dupes, fails)))
        threading.Thread(target=work, daemon=True).start()

    def _qrz_uploaded(self, ids, dupes, fails):
        ids = set(ids)
        for q in self.d["qsos"]:
            if q["id"] in ids:
                q["qrz_sent"] = True
                q.pop("qrz_replace", None)
        self._save()
        self._refresh_table()
        msg = f"Sent {len(ids)} QSO(s) to QRZ."
        if dupes:
            msg += f" {dupes} were already there."
        if fails:
            msg += f" {len(fails)} failed: " + "; ".join(fails[:3])
        self._status(msg, ok=not fails)

    # --- other loggers over UDP
    # ------------------------------------------------ log of choice (LOC)
    def _loc_type(self):
        t = self.d.get("loc_type", "none")
        return "n3fjp" if t == "aclog" else t

    def _loc_name(self):
        n = (self.d.get("loc_name") or "").strip()
        if n:
            return n
        return next((x[3] for x in LOC_TYPES if x[0] == self._loc_type()), "your log")

    def _migrate_loc(self):
        """Older versions kept ACLog and the UDP logger separately - carry them over once."""
        if "loc_type" in self.d:
            return
        if self.d.get("udp_fwd") and self.d.get("udp_host"):
            adif = self.d.get("udp_fmt") == "Plain ADIF"
            self.d.update(loc_type="udp_adif" if adif else "udp_wsjtx", loc_host=self.d["udp_host"],
                          loc_port=str(self.d.get("udp_port") or ("2333" if adif else "2237")), loc_auto=True)
        else:
            self.d.update(loc_type="n3fjp", loc_host=self.d.get("aclog_host", "127.0.0.1"),
                          loc_port=str(self.d.get("aclog_port", 1100)), loc_auto=False)
        if "worked_auto" not in self.d:
            self.d["worked_auto"] = bool(self.d.get("aclog_auto", True) or self.d.get("qrz_auto"))

    def _send_loc(self, records, on_ok=None, ask=True, parent=None):
        """Send ADIF records to the log of choice. on_ok runs on the main thread after success."""
        t = self._loc_type()
        web = t == "wavelog"
        host = (self.d.get("wl_url") if web else self.d.get("loc_host") or "").strip()
        if t == "none" or not host:
            if ask and messagebox.askyesno(APP, "Pick your log of choice first (Settings > Log of choice).\n\n"
                                                "Open Settings now?", parent=parent):
                self.settings_dialog("Log of choice")
            return
        default = next((x[2] for x in LOC_TYPES if x[0] == t), "2237")
        try:
            port = int(self.d.get("loc_port") or default or 0)
        except ValueError:
            port = int(default or 0)
        if (not web and t not in ("n3fjp", "dxkeeper") and self.d.get("wsjtx_on") and host in ("127.0.0.1", "localhost")
                and port == int(self.d.get("wsjtx_port") or 2237)):
            self._status(f"Not sent: {self._loc_name()} uses the same port as the WSJT-X listener. "
                         "Change one of them in Settings.", ok=False)
            return
        name = self._loc_name()
        if ask and not messagebox.askyesno(APP, f"Send {len(records)} record(s) to {name}"
                                                + ("?" if web else f" at {host}:{port}?"), parent=parent):
            return
        if ask:
            self._status(f"Sending to {name}...", ok=True)

        def work():
            if t == "n3fjp":
                _n, err = aclog_send_records(host, port, records)
            elif t == "dxkeeper":
                err = dxkeeper_send(host, port, records)
            elif web:
                err = wavelog_send(host, self.d.get("wl_key", ""), self.d.get("wl_station", ""), records)
            else:
                err = udp_send_records(host, port, records, t in ("log4om", "udp_wsjtx"))
            if err:
                self.ui_q.put((self._status, (err, False)))
                if ask:
                    self.ui_q.put((lambda: messagebox.showwarning(APP, err), ()))
            else:
                self.ui_q.put((self._status, (f"Sent {len(records)} record(s) to {name}.", True)))
                if on_ok:
                    self.ui_q.put((on_ok, ()))
        threading.Thread(target=work, daemon=True).start()

    def _grid_for(self, prog, ref):
        """My grid for this activation: the park's own grid square when it's known (and that's turned on),
        otherwise the home grid from Settings."""
        if self.d.get("park_grid", True):
            g = self.db.ref_grid(prog, ref)
            if g:
                return g
        return self.v_grid.get().strip()

    def _where(self, q):
        """(program, reference, my grid) for a contact - no program/reference when not activating."""
        if q.get("refs"):
            prog, ref = q["refs"][0]
            return prog, ref, self._grid_for(prog, ref)
        return "", "", fmt_grid(q.get("my_grid") or self.v_grid.get())

    def _calls_for(self, q):
        """(station call, operator) - a special event call is logged with you as the operator."""
        me = self.v_call.get().strip().upper()
        sc, op = q.get("station_call"), q.get("operator")
        if sc:
            return sc, op or base_call(me)
        if op and base_call(op) != base_call(me):
            return me, op
        return me, ""

    def _records_for(self, qsos):
        out = []
        for q in qsos:
            prog, ref, grid = self._where(q)
            call, op = self._calls_for(q)
            out += adif_records(build_adif([q], call, prog, ref, grid, op))
        return out

    def send_loc_current(self):
        if self._event_blocks_send():
            return
        todo = [q for q in self.d["qsos"] if not q.get("aclog_sent") and not q.get("station_call")]
        if not todo:
            messagebox.showinfo(APP, "No QSOs yet." if not self.d["qsos"] else
                                f"Every QSO in this activation is already in {self._loc_name()}.")
            return
        if not CALL_RE.match(self.v_call.get().strip().upper()):
            self._need_call()
            return
        ids = {q["id"] for q in todo}
        self._send_loc(self._records_for(todo), lambda: self._mark_loc(ids))

    def _mark_loc(self, ids):
        for q in self.d["qsos"]:
            if q["id"] in ids:
                q["aclog_sent"] = True
        self._save()
        self._refresh_table()

    def _forward_qso(self, q):
        """Send each QSO to the log of choice as it is logged, if that's turned on."""
        if self.d.get("loc_auto") and self._loc_type() != "none" and not q.get("station_call"):
            self._send_loc(self._records_for([q]), lambda: self._mark_loc({q["id"]}), ask=False)

    def _need_call(self):
        if messagebox.askyesno(APP, "Set your callsign first (Settings > My station).\n\nOpen Settings now?"):
            self.settings_dialog("My station")

    def event_call(self):
        """The special event call in use (W6J ...), or ''."""
        return (self.d.get("event_call") or "").strip().upper()

    def _refresh_station(self):
        c, g = self.v_call.get().strip().upper(), self.v_grid.get().strip()
        ev, op = self.event_call(), (self.d.get("operator") or "").strip().upper()
        if c and (ev or op):
            self.station_lbl.config(text=f"{ev or c}  (op {op or c})   {g}", fg=col("#b9770e"))
        else:
            self.station_lbl.config(text=(f"{c}   {g}" if c else "Set your call in Settings"),
                                    fg=col("#222") if c else col("#c0392b"))

    def _refresh_send_buttons(self):
        if not hasattr(self, "qrz_btn"):
            return
        if self.event_call():
            self.qrz_btn.config(text="Send to QRZ (off)", state="disabled")
            self.loc_btn.config(text="Send to LOC (off)", state="disabled")
            self.lotw_btn.config(text="Send to LoTW (off)", state="disabled")
            return
        self.qrz_btn.config(state="normal")
        self.loc_btn.config(state="normal")
        self.lotw_btn.config(state="normal")
        nw = sum(1 for q in self.d["qsos"] if not q.get("lotw_sent") and not q.get("station_call"))
        self.lotw_btn.config(text=f"Send to LoTW ({nw})" if nw else "Send to LoTW")
        nq = sum(1 for q in self.d["qsos"] if not q.get("qrz_sent") and not q.get("station_call"))
        nl = sum(1 for q in self.d["qsos"] if not q.get("aclog_sent") and not q.get("station_call"))
        self.qrz_btn.config(text=f"Send to QRZ ({nq})" if nq else "Send to QRZ")
        loc = "Send to LOC" if self._loc_type() == "none" else f"Send to {self._loc_name()}"
        if len(loc) > 22:
            loc = "Send to LOC"
        self.loc_btn.config(text=f"{loc} ({nl})" if nl else loc)

    # ------------------------------------------------ worked-before from QRZ / ACLog / log of choice
    def _loc_can_pull(self):
        t = self._loc_type()
        if t == "wavelog":
            return bool((self.d.get("wl_url") or "").strip())
        if t == "n3fjp":
            return bool((self.d.get("loc_host") or "").strip())
        return False

    def _auto_update_worked(self):
        if self.d.get("worked_auto", True):
            self.update_worked(quiet=True)

    def update_worked(self, quiet=False):
        """Refresh worked-before from QRZ, the ACLog file on this PC and the log of choice."""
        aclog_path = self.d.get("aclog_path") or DEFAULT_ACLOG
        use_file = os.path.exists(aclog_path)
        sources = bool(self.d.get("qrz_key")) or use_file or self._loc_can_pull()
        if not sources:
            if not quiet:
                messagebox.showinfo(APP, "Nothing to update from. Add your QRZ Logbook key (Settings > QRZ), or pick "
                                    "ACLog or Wavelog/Cloudlog as your log of choice. For other loggers, export an "
                                    "ADIF and use Import.")
            return
        if getattr(self, "_worked_busy", False):
            return
        self._worked_busy = True
        if not quiet:
            self._status("Updating worked-before...", ok=True)

        def work():
            report, ok = [], True
            if self.d.get("qrz_key"):
                try:
                    report.append(f"QRZ +{self._pull_qrz():,}")
                except Exception as e:  # noqa: BLE001
                    ok = False
                    report.append(f"QRZ failed ({e})")
            if use_file:
                try:
                    import access_parser  # noqa: F401
                    if quiet and os.path.getmtime(aclog_path) == self.d.get("aclog_mtime"):
                        report.append("ACLog file unchanged")
                    else:
                        n = read_aclog_into(self.db, aclog_path)
                        self.d["aclog_mtime"] = os.path.getmtime(aclog_path)
                        report.append(f"ACLog file {n:,}")
                except ImportError:
                    report.append("ACLog file skipped (run: " + ACCESS_CMD + ")")
                except Exception as e:  # noqa: BLE001
                    ok = False
                    report.append(f"ACLog file failed ({e})")
            if self._loc_can_pull() and not (use_file and self._loc_type() == "n3fjp"):
                try:
                    report.append(f"{self._loc_name()} {self._pull_loc()}")
                except Exception as e:  # noqa: BLE001
                    ok = False
                    report.append(f"{self._loc_name()} failed ({e})")
            self._worked_busy = False
            if ok:
                self.d["worked_updated"] = utc_now().strftime("%Y-%m-%d")
            self.ui_q.put((self._save, ()))
            if ok or not quiet:
                self.ui_q.put((self._status, ("Worked-before updated - " + "   ".join(report), ok)))
        threading.Thread(target=work, daemon=True).start()

    def _pull_qrz(self):
        lb, after, total = QRZLogbook(self.d["qrz_key"]), int(self.d.get("qrz_last_logid", 0) or 0), 0
        # once (v1.10): fetch your whole QRZ log again so past comments come along - the old copy stays
        # until the new one has fully arrived, so nothing is lost if the connection drops
        full = not self.d.get("qrz_has_comments")
        collected = []
        if full:
            after = 0
        while True:
            recs = lb.fetch_page(after)
            if not recs:
                break
            if full:
                collected += recs
            else:
                self.db.add_worked_rows(recs, "qrz")
            total += len(recs)
            ids = [int(r.get("APP_QRZLOG_LOGID", "0") or 0) for r in recs]
            after = max(ids + [after]) + 1
            self.d["qrz_last_logid"] = after - 1
            self.ui_q.put((self._status, (f"Worked-before: {total:,} {'from' if full else 'new from'} QRZ...", True)))
            if len(recs) < 250:
                break
        if full:
            self.db.clear_worked("qrz")
            self.db.add_worked_rows(collected, "qrz")
            self.d["qrz_has_comments"] = True
        return total

    def _pull_loc(self):
        if self._loc_type() == "n3fjp":
            self.ui_q.put((self._status, (f"Worked-before: reading {self._loc_name()} over the network...", True)))
            recs = n3fjp_list(self.d["loc_host"].strip(), int(self.d.get("loc_port") or 1100))
            if not recs:
                raise IOError("no contacts came back - is ACLog open with the TCP API enabled?")
            self.db.clear_worked("loc")
            self.db.add_worked_rows(recs, "loc")
            return f"{len(recs):,}"
        site, key, st = self.d.get("wl_url", ""), self.d.get("wl_key", ""), self.d.get("wl_station", "")
        if not self.d.get("wl_has_comments"):  # once (v1.10): fetch again so past comments come along
            self.d["wl_pull_sig"], self.d["wl_has_comments"] = "", True
        if f"{site}|{st}" != self.d.get("wl_pull_sig"):  # a different site/station: start over
            self.d.update(wl_pull_sig=f"{site}|{st}", wl_last_id=0)
            self.db.clear_worked("loc")
        frm, total = int(self.d.get("wl_last_id", 0) or 0), 0
        for _ in range(100):
            recs, last = wavelog_fetch(site, key, st, frm)
            if not recs or last <= frm:
                break
            self.db.add_worked_rows(recs, "loc")
            total += len(recs)
            frm = self.d["wl_last_id"] = last
            self.ui_q.put((self._status, (f"Worked-before: {total:,} new from {self._loc_name()}...", True)))
        return f"+{total:,}"

    # ------------------------------------------------ settings
    def settings_dialog(self, tab=None):
        if getattr(self, "_settings_win", None) and self._settings_win.winfo_exists():
            self._settings_win.lift()
            return
        w = self._settings_win = tk.Toplevel(self.root)
        w.title(f"Settings - {APP}")
        w.transient(self.root)
        w.geometry("680x660")
        w.minsize(600, 560)
        w.columnconfigure(0, weight=1)
        w.rowconfigure(0, weight=1)
        nb = ttk.Notebook(w)
        nb.grid(row=0, column=0, sticky="nsew", padx=8, pady=(8, 0))
        S = {k: tk.StringVar(value=str(self.d.get(k, "") or "")) for k in (
            "pota_programs", "qrz_key", "qrz_user", "qrz_pass", "loc_name", "loc_host", "loc_port",
            "wl_url", "wl_key", "wl_station", "wsjtx_port", "wsjtx_group", "event_call", "cluster", "operator",
            "tqsl_loc")}
        B = {k: tk.BooleanVar(value=bool(self.d.get(k, d))) for k, d in (
            ("cat_autoconnect", False), ("loc_auto", False), ("wsjtx_on", False), ("worked_auto", True),
            ("wsjtx_remote", False), ("park_grid", True), ("dark", False), ("cluster_ok", False))}
        if not S["pota_programs"].get():
            S["pota_programs"].set("US")
        loc_label = tk.StringVar(value=next(x[1] for x in LOC_TYPES if x[0] == self._loc_type()))
        tabs = {}

        def page(name):
            f = ttk.Frame(nb, padding=14)
            f.columnconfigure(1, weight=1)
            nb.add(f, text=name)
            tabs[name] = f
            return f

        def row(f, r, label, widget, note=None):
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="nw", pady=4, padx=(0, 10))
            widget.grid(row=r, column=1, sticky="ew", pady=4)
            if note:
                ttk.Label(f, text=note, foreground=col("#777"), wraplength=420, justify="left").grid(
                    row=r + 1, column=1, sticky="w")

        def hint(f, r, text):
            lbl = ttk.Label(f, text=text, foreground=col("#777"), wraplength=600, justify="left")
            lbl.grid(row=r, column=0, columnspan=2, sticky="w", pady=(8, 0))
            return lbl

        # 1. my station
        f = page("My station")
        row(f, 0, "Callsign", ttk.Entry(f, textvariable=self.v_call, font=self.mono, width=16))
        row(f, 1, "Home grid", ttk.Entry(f, textvariable=self.v_grid, font=self.mono, width=10))
        row(f, 2, "POTA countries", ttk.Entry(f, textvariable=S["pota_programs"], width=20),
            "Park lists are downloaded for these (US, CA, MX ...). A bare number like 1234 uses the first one.")
        ttk.Checkbutton(f, text="Use the park's or summit's grid square as my grid when it's known",
                        variable=B["park_grid"]).grid(row=4, column=0, columnspan=2, sticky="w", pady=(10, 0))
        ttk.Label(f, text="Goes into your ADIF, QRZ and log of choice (MY_GRIDSQUARE). Your home grid is used "
                          "when the park's isn't known.", foreground=col("#777"), wraplength=560,
                  justify="left").grid(row=5, column=0, columnspan=2, sticky="w")
        ttk.Checkbutton(f, text="Dark mode", variable=B["dark"]).grid(row=6, column=0, columnspan=2, sticky="w",
                                                                    pady=(10, 0))
        row(f, 9, "Operator", ttk.Entry(f, textvariable=S["operator"], font=self.mono, width=16),
            "Leave blank when it's you. Handing the logger to a friend (club activation, two-person trip)? Put "
            "their call here - contacts are logged with them as the operator until you clear it.")
        row(f, 7, "Special event call", ttk.Entry(f, textvariable=S["event_call"], font=self.mono, width=16),
            "Optional - e.g. W6J for Route 66 On The Air. While it's filled in, contacts are logged as that call "
            "with you as the operator, SPOT ME spots it, and Send to QRZ / Send to LOC are switched off so the "
            "event log only leaves by Export ADIF. Clear it when the event is over.")

        # 2. spotting
        f = page("Spotting")
        row(f, 0, "Spot comment", ttk.Entry(f, textvariable=self.v_comment),
            "Optional. Leave blank for an automatic one, like \"Activating US-1234\".")
        ttk.Checkbutton(f, text="Re-spot me after each QSO (POTA, WWBOTA and GMA)",
                        variable=self.v_auto).grid(row=2, column=0, columnspan=2, sticky="w", pady=(10, 0))
        if not S["cluster"].get():
            S["cluster"].set(DEFAULT_CLUSTER)
        ttk.Checkbutton(f, text="Allow SPOT ME to the DX cluster when not activating - special events only, "
                             "never during contests", variable=B["cluster_ok"]).grid(
            row=3, column=0, columnspan=2, sticky="w", pady=(14, 0))
        hint(f, 4, "Self-spotting on DX clusters is frowned on (and against the rules in contests). Better: FT8 shows "
                   "up on PSK Reporter by itself, CW is picked up by the Reverse Beacon Network, or ask a friend to "
                   "spot you. If you do use it: at most one spot every 15 minutes.")
        row(f, 5, "DX cluster", ttk.Entry(f, textvariable=S["cluster"], width=24),
            "host:port. You log in with your own call; the spot is for your special event call if you have one.")

        # 3. radio
        f = page("Radio")
        rig_label = tk.StringVar(value=rig_type(self.d.get("rig_type") or "yaesu")[1])
        for k, dflt in (("civ_addr", ""), ("rig_host", "127.0.0.1"), ("rig_net_port", "")):
            S[k] = tk.StringVar(value=str(self.d.get(k) or dflt))
        rt = ttk.Combobox(f, textvariable=rig_label, values=[r[1] for r in RIG_TYPES], state="readonly")
        row(f, 0, "Radio", rt)
        port_fr = ttk.Frame(f)
        pb = ttk.Combobox(port_fr, textvariable=self.v_port, width=14, postcommand=lambda: pb.configure(
            values=[p.device for p in serial.tools.list_ports.comports()] if HAVE_SERIAL else []))
        pb.grid(row=0, column=0)
        ttk.Button(port_fr, text="Find my radio...", command=lambda: self.port_picker(self._settings_win)).grid(
            row=0, column=1, padx=(8, 0))
        bb = ttk.Combobox(f, textvariable=self.v_baud, width=8, state="readonly",
                          values=["4800", "9600", "19200", "38400", "57600", "115200"])
        civ_w = ttk.Entry(f, textvariable=S["civ_addr"], width=6)
        rh_w = ttk.Entry(f, textvariable=S["rig_host"], width=16)
        rp_w = ttk.Entry(f, textvariable=S["rig_net_port"], width=8)
        drop_cb = ttk.Checkbutton(f, text="DTR/RTS off (tick for the FT-710)", variable=self.v_drop)
        rig_lbls = {}
        for r, (txt, wdg) in enumerate([("CAT port", port_fr), ("Speed", bb), ("CI-V address (hex)", civ_w),
                                        ("Address", rh_w), ("Port", rp_w)], start=1):
            rig_lbls[wdg] = ttk.Label(f, text=txt)
            rig_lbls[wdg].grid(row=r, column=0, sticky="w", pady=4, padx=(0, 10))
            wdg.grid(row=r, column=1, sticky="w", pady=4)
        drop_cb.grid(row=6, column=0, columnspan=2, sticky="w", pady=(8, 0))
        ttk.Checkbutton(f, text="Connect to the radio when the logger starts", variable=B["cat_autoconnect"]).grid(
            row=7, column=0, columnspan=2, sticky="w")
        rig_hint = hint(f, 8, "")
        rig_last = {"key": rig_type(self.d.get("rig_type") or "yaesu")[0]}

        def rig_changed(*_):
            key, _lb, drv, baud, addr = next(r for r in RIG_TYPES if r[1] == rig_label.get())
            old = rig_type(rig_last["key"])
            if key != rig_last["key"]:
                if old[3] and self.v_baud.get() in ("", old[3]) and baud:
                    self.v_baud.set(baud)
                if addr is not None and (S["civ_addr"].get().strip().upper() in
                                         ("", f"{old[4]:02X}" if old[4] is not None else "")):
                    S["civ_addr"].set(f"{addr:02X}")
                if drv in RIG_NET_PORTS and S["rig_net_port"].get().strip() in ("",) + tuple(RIG_NET_PORTS.values()):
                    S["rig_net_port"].set(RIG_NET_PORTS[drv])
            if addr is not None and not S["civ_addr"].get().strip():
                S["civ_addr"].set(f"{addr:02X}")
            if drv in RIG_NET_PORTS and not S["rig_net_port"].get().strip():
                S["rig_net_port"].set(RIG_NET_PORTS[drv])
            rig_last["key"] = key
            net = drv in RIG_NET_PORTS
            for wdg in (port_fr, bb):
                for x in (wdg, rig_lbls[wdg]):
                    x.grid_remove() if net else x.grid()
            for x in (civ_w, rig_lbls[civ_w]):
                x.grid() if drv == "icom" else x.grid_remove()
            for wdg in (rh_w, rp_w):
                for x in (wdg, rig_lbls[wdg]):
                    x.grid() if net else x.grid_remove()
            drop_cb.grid_remove() if net else drop_cb.grid()
            txt = RIG_HINTS[drv]
            if IS_LINUX and not net:
                txt += ("\n\nLinux: the port looks like /dev/ttyUSB0 (FT-710/FT-991A Enhanced is usually ttyUSB0, "
                        "IC-705 is /dev/ttyACM0). If it won't open, add yourself to the dialout group:  "
                        "sudo usermod -aG dialout $USER  then log out and back in.")
            if not net and not HAVE_SERIAL:
                txt += "\n\nRadio control over USB is off until you run:  " + PYSERIAL_CMD
            rig_hint.config(text=txt)
        rt.bind("<<ComboboxSelected>>", rig_changed)
        rig_changed()

        # 4. QRZ
        f = page("QRZ")
        row(f, 0, "Logbook API key", ttk.Entry(f, textvariable=S["qrz_key"], show="•"),
            "For Send to QRZ and to download your QRZ log for worked-before. QRZ > Logbook > Settings. "
            "Needs a QRZ subscription.")
        row(f, 2, "Username", ttk.Entry(f, textvariable=S["qrz_user"], width=20),
            "Name lookups use your QRZ login (XML subscription) - not the API key.")
        row(f, 4, "Password", ttk.Entry(f, textvariable=S["qrz_pass"], show="•", width=20))
        qrz_res = hint(f, 6, "")
        ttk.Button(f, text="Test QRZ", command=lambda: test_qrz()).grid(row=7, column=0, sticky="w", pady=(8, 0))
        ttk.Separator(f).grid(row=8, column=0, columnspan=2, sticky="ew", pady=(16, 8))
        row(f, 9, "LoTW station location", ttk.Combobox(f, textvariable=S["tqsl_loc"], width=30,
                                                         values=tqsl_locations()),
            "For Send to LoTW: pick your TQSL Station Location from the list (it's read from TQSL). "
            "TQSL signs and uploads - your certificate never leaves TQSL. "
            + ("TQSL found." if find_tqsl() else "TQSL wasn't found - install it from arrl.org/tqsl first."))

        # 5. log of choice
        f = page("Log of choice")
        ttk.Label(f, text="Where the Send to LOC button sends your contacts. Useful without a QRZ subscription.",
                  foreground=col("#555"), wraplength=560).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 6))
        lt = ttk.Combobox(f, textvariable=loc_label, values=[x[1] for x in LOC_TYPES], state="readonly")
        row(f, 1, "Logger", lt)
        row(f, 2, "Name on button", ttk.Entry(f, textvariable=S["loc_name"], width=20))
        host_w = ttk.Entry(f, textvariable=S["loc_host"], width=20)
        port_w = ttk.Entry(f, textvariable=S["loc_port"], width=8)
        url_w = ttk.Entry(f, textvariable=S["wl_url"])
        key_w = ttk.Entry(f, textvariable=S["wl_key"], show="•")
        st_w = ttk.Entry(f, textvariable=S["wl_station"], width=8)
        lbls = {}
        for r, (txt, wdg) in enumerate([("PC address", host_w), ("Port", port_w), ("Site address", url_w),
                                        ("API key", key_w), ("Station number", st_w)], start=3):
            lbls[wdg] = ttk.Label(f, text=txt)
            lbls[wdg].grid(row=r, column=0, sticky="w", pady=4)
            wdg.grid(row=r, column=1, sticky="w" if wdg in (port_w, st_w, host_w) else "ew", pady=4)
        auto_cb = ttk.Checkbutton(f, text="Also send each QSO the moment I log it", variable=B["loc_auto"])
        auto_cb.grid(row=8, column=0, columnspan=2, sticky="w", pady=(6, 0))
        loc_hint = hint(f, 9, "")
        loc_res = hint(f, 10, "")
        test_btn = ttk.Button(f, text="Test connection", command=lambda: test_loc())
        test_btn.grid(row=11, column=0, sticky="w", pady=(8, 0))
        last = {"key": self._loc_type()}

        def loc_changed(*_):
            key = next(x[0] for x in LOC_TYPES if x[1] == loc_label.get())
            old_default = next(x[2] for x in LOC_TYPES if x[0] == last["key"])
            if key != last["key"] and S["loc_port"].get().strip() in ("", old_default):
                S["loc_port"].set(next(x[2] for x in LOC_TYPES if x[0] == key))
            if key == "n3fjp" and not S["loc_host"].get().strip():
                S["loc_host"].set("127.0.0.1")
            last["key"] = key
            web, on = key == "wavelog", key != "none"
            for wdg in (host_w, port_w):
                for x in (wdg, lbls[wdg]):
                    x.grid() if on and not web else x.grid_remove()
            for wdg in (url_w, key_w, st_w):
                for x in (wdg, lbls[wdg]):
                    x.grid() if web else x.grid_remove()
            auto_cb.grid() if on else auto_cb.grid_remove()
            test_btn.grid() if on else test_btn.grid_remove()
            extra = ""
            if web and insecure_web_url(S["wl_url"].get()):
                extra = ("\n\u26a0 This address starts with http:// - your API key would cross the internet "
                         "unencrypted. Use https:// for an internet site.")
            loc_hint.config(text=LOC_HINTS[key] + "\nN1MM+ and Nexus can't receive contacts over the network - "
                                                  "use Export ADIF and import the file." + extra)
        lt.bind("<<ComboboxSelected>>", loc_changed)
        url_w.bind("<FocusOut>", loc_changed, add="+")
        loc_changed()

        # 6. WSJT-X
        f = page("WSJT-X")
        ttk.Checkbutton(f, text="Listen to WSJT-X (FT8/FT4 contacts go straight into the activation)",
                        variable=B["wsjtx_on"]).grid(row=0, column=0, columnspan=2, sticky="w")
        row(f, 1, "UDP port", ttk.Entry(f, textvariable=S["wsjtx_port"], width=8))
        row(f, 2, "Multicast address", ttk.Entry(f, textvariable=S["wsjtx_group"], width=16),
            "Usually leave blank - 127.0.0.1 and the common shared addresses (224.0.0.73, 224.0.0.1, 239.255.0.1) "
            "are heard automatically. Only fill this in if WSJT-X's UDP Server is some other 224.x/239.x address. "
            "Works with Nexus too - turn on its WSJT-X UDP output (127.0.0.1:2237).")
        ttk.Checkbutton(f, text="Also accept contacts from other computers on my network",
                        variable=B["wsjtx_remote"]).grid(row=4, column=0, columnspan=2, sticky="w", pady=(10, 0))
        hint(f, 5, "Leave this off unless WSJT-X runs on a different computer. When it's off, only WSJT-X on this "
                   "PC can add contacts - so nobody else on campground or club Wi-Fi can slip fake QSOs into "
                   "your log.")

        # 7. offline data
        f = page("Offline data")
        data_lbl = ttk.Label(f, text="", foreground=col("#555"), justify="left", wraplength=600)
        data_lbl.grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Checkbutton(f, text="When the logger opens online, update automatically\n"
                                "(park lists monthly, worked-before every time)",
                        variable=B["worked_auto"]).grid(row=1, column=0, columnspan=2, sticky="w", pady=(8, 4))
        acts = [("Update everything now (before you leave home)", lambda: (save(), self._update_everything())),
                ("Update worked-before (QRZ, ACLog, log of choice)", lambda: (save(), self.update_worked())),
                ("Update park & summit lists", lambda: (save(), self._run_ref_update(self._codes(), False))),
                ("Download offline callbook (US + Canada)", lambda: (save(), self.update_offline_callbook())),
                ("Choose ACLog log file (LogData.mdb)...", lambda: (save(), self.choose_aclog())),
                ("Import worked-before from an ADIF file...", lambda: (save(), self.import_adif())),
                ("Choose ADIF export folder...", lambda: (save(), self.choose_export_dir()))]
        for i, (txt, fn) in enumerate(acts):
            ttk.Button(f, text=txt, command=fn).grid(row=2 + i, column=0, columnspan=2, sticky="ew", pady=2)
        hint(f, 12, "Worked-before comes from QRZ, the ACLog file on this PC, ACLog over the network and "
                    "Wavelog/Cloudlog. For DXKeeper, Log4OM, HRD and others, export an ADIF and use Import.")

        def refresh_data():
            if not w.winfo_exists():
                return
            rc = self.db.refs_counts()
            oc = self.db.offline_counts()
            data_lbl.config(text=(
                "Park & summit lists: " + ("  ".join(f"{k} {v:,}" for k, v in rc.items()) or "not downloaded")
                + (f"  (updated {self.d['refs_updated']})" if self.d.get("refs_updated") else "")
                + "\nOffline callbook: " + (", ".join(f"{k} {v:,}" for k, v in oc.items()) or "not downloaded")
                + (f"  (updated {self.d['callbook_updated']})" if self.d.get("callbook_updated") else "")
                + f"\nWorked-before: {self.db.worked_count('qrz'):,} from QRZ, {self.db.worked_count('loc'):,} from "
                  f"your log of choice, {self.db.adif_count():,} from the ACLog file / imports"
                + (f"  (updated {self.d['worked_updated']})" if self.d.get("worked_updated") else "")
                + f"\nSaved QRZ name lookups: {self.db.callbook_count():,}"))
            w.after(3000, refresh_data)
        refresh_data()

        status = ttk.Label(w, textvariable=self._status_var, foreground=col("#555"), wraplength=600, padding=(10, 4))
        status.grid(row=1, column=0, sticky="ew")

        def save():
            for k, var in S.items():
                self.d[k] = var.get().strip() if k != "qrz_pass" else var.get()
            was_dark = bool(self.d.get("dark"))
            for k, var in B.items():
                self.d[k] = bool(var.get())
            if self.d["dark"] != was_dark:
                self.apply_appearance(self.d["dark"])
            self.d["loc_type"] = next(x[0] for x in LOC_TYPES if x[1] == loc_label.get())
            self.d["rig_type"] = next(r[0] for r in RIG_TYPES if r[1] == rig_label.get())
            self.d["civ_addr"] = self.d["civ_addr"].upper().rstrip("H")
            if self.d["loc_type"] == "none":
                self.d["loc_auto"] = False
            self.d["pota_programs"] = ",".join(self._codes()) or "US"
            ev = self.d.get("event_call", "").strip().upper()
            if ev and not CALL_RE.match(ev):
                messagebox.showwarning(APP, f"'{ev}' doesn't look like a callsign - special event call not set.",
                                       parent=w)
                ev = ""
                S["event_call"].set("")
            self.d["event_call"] = ev
            op = self.d.get("operator", "").strip().upper()
            if op and not CALL_RE.match(op):
                messagebox.showwarning(APP, f"'{op}' doesn't look like a callsign - operator not set.", parent=w)
                op = ""
                S["operator"].set("")
            self.d["operator"] = op
            if not re.match(r"^[\w.-]+:\d+$", self.d.get("cluster", "")):
                self.d["cluster"] = DEFAULT_CLUSTER
                S["cluster"].set(DEFAULT_CLUSTER)
            self.v_call.set(self.v_call.get().strip().upper())
            self._set_pota_prefix()
            self._make_qrz()
            self._save()
            self._refresh_station()
            self._apply_activating()
            self._refresh_refs()
            self._refresh_send_buttons()

        def test_qrz():
            save()
            qrz_res.config(text="Testing...", foreground=col("#555"))

            def work():
                parts = []
                key = self.d.get("qrz_key")
                if key:
                    try:
                        st = QRZLogbook(key).status()
                        parts.append("Logbook key works." if st.get("RESULT") == "OK"
                                     else f"Logbook key: {st.get('REASON') or 'not accepted'}")
                    except Exception as e:  # noqa: BLE001
                        parts.append(f"Logbook: couldn't reach QRZ ({e})")
                else:
                    parts.append("Logbook key: not set.")
                if self.qrz:
                    try:
                        exp = self.qrz.login()
                        info = self.qrz.lookup("W1AW")
                        parts.append("Name lookups: no XML subscription on this account." if "non-subscriber" in exp.lower()
                                     else ("Name lookups work." if info.get("name") else "Name lookups came back empty."))
                    except Exception as e:  # noqa: BLE001
                        parts.append(f"Name lookups: {e}")
                else:
                    parts.append("Name lookups: login not set.")
                txt = "  ".join(parts)
                good = not any(x in txt for x in ("not ", "couldn't", "empty", "no XML"))
                self.ui_q.put((lambda: qrz_res.config(text=txt, foreground=col("#1e7d4f") if good else col("#c0392b"))
                               if w.winfo_exists() else None, ()))
            threading.Thread(target=work, daemon=True).start()

        def test_loc():
            save()
            t = self._loc_type()
            if t == "wavelog":
                site = self.d.get("wl_url", "")
                if not site:
                    loc_res.config(text="Enter your site address first.", foreground=col("#c0392b"))
                    return

                def work():
                    try:
                        code, _b = _wavelog_post(site, "get_contacts_adif",
                                                 {"key": self.d.get("wl_key", ""), "station_id": self.d.get("wl_station", "0"),
                                                  "fetchfromid": 10 ** 12}, timeout=15)
                        txt, ok = ((f"Wavelog/Cloudlog answered - key and station look right.", True) if code == 200 else
                                   (f"Reached the site, but it answered HTTP {code} - check the key and station number.", False))
                    except Exception as e:  # noqa: BLE001
                        txt, ok = f"Couldn't reach {site}: {e}", False
                    self.ui_q.put((lambda: loc_res.config(text=txt, foreground=col("#1e7d4f") if ok else col("#c0392b"))
                                   if w.winfo_exists() else None, ()))
                threading.Thread(target=work, daemon=True).start()
                return
            host = self.d.get("loc_host", "")
            if not host:
                loc_res.config(text="Enter the PC address first (127.0.0.1 for this PC).", foreground=col("#c0392b"))
                return
            if t not in ("n3fjp", "dxkeeper"):
                loc_res.config(text=f"UDP can't confirm delivery - log a test QSO and look for it in {self._loc_name()}.",
                               foreground=col("#555"))
                return
            port = int(self.d.get("loc_port") or 1100)

            def work():
                try:
                    with socket.create_connection((host, port), timeout=4) as s:
                        if t == "n3fjp":
                            s.sendall(b"\r\n")
                    txt, ok = f"{self._loc_name()} answered - Send to LOC is ready.", True
                except OSError:
                    txt, ok = (f"No answer from {self._loc_name()} at {host}:{port}. Is it open with its network "
                               "option turned on?"), False
                self.ui_q.put((lambda: loc_res.config(text=txt, foreground=col("#1e7d4f") if ok else col("#c0392b"))
                               if w.winfo_exists() else None, ()))
            threading.Thread(target=work, daemon=True).start()

        def done():
            save()
            if self._loc_type() == "wavelog" and insecure_web_url(self.d.get("wl_url")):
                messagebox.showwarning(APP, "Your Wavelog/Cloudlog address starts with http://, so the API key "
                                       "travels over the internet unencrypted.\n\nIf your site supports it, "
                                       "change the address to https://.", parent=w)
            self._restart_wsjtx()
            w.destroy()
        bf = ttk.Frame(w, padding=(8, 4, 8, 8))
        bf.grid(row=2, column=0, sticky="e")
        ttk.Button(bf, text="Done", command=done).grid(row=0, column=0)
        w.protocol("WM_DELETE_WINDOW", done)
        if tab in tabs:
            nb.select(tabs[tab])

    def apply_appearance(self, dark, built=True):
        """Light or dark mode for the whole program (Settings > My station)."""
        DARK["on"] = bool(dark)
        style = ttk.Style()
        r = self.root
        if dark:
            _dark_theme(style, self._body)
            style.theme_use("rawdark")
            for k, v in (("*Background", D_BG), ("*Foreground", D_FG), ("*Listbox.background", D_FIELD),
                         ("*Listbox.foreground", D_FG), ("*TCombobox*Listbox.background", D_FIELD),
                         ("*TCombobox*Listbox.foreground", D_FG), ("*Menu.background", D_PANEL),
                         ("*Menu.foreground", D_FG), ("*Menu.activeBackground", "#2e9e6e"),
                         ("*Menu.activeForeground", "white"), ("*selectBackground", "#2e9e6e")):
                r.option_add(k, v)
            r.configure(bg=D_BG)
        else:
            style.theme_use(self._light_theme)
            r.option_clear()
            r.configure(bg=self._root_bg)
        style.configure("Disconnect.TButton", foreground=col("#c0392b"), font=(UI_FONT, 10, "bold"))
        style.configure("On.TButton", foreground=col("#1e7d4f"), font=(UI_FONT, 10, "bold"))
        if built:
            _retheme(r, bool(dark), self._root_bg)
            self._refresh_station()
            self._refresh_refs()
            self._update_counter()
        r.after(60, lambda: _dark_titlebar(r, bool(dark)))

    def make_shortcut(self, asked=False):
        try:
            made = make_shortcuts()
        except Exception as e:  # noqa: BLE001
            messagebox.showwarning(APP, f"Couldn't make the shortcut:\n{e}\n\nYou can make one by hand - see "
                                        "the Appendix in the guide.")
            return
        where = "your desktop and the Start menu" if IS_WIN else "your desktop and the app menu"
        self._status(f"Shortcut with the logo added to {where}.", ok=True)
        if not asked:
            messagebox.showinfo(APP, f"Done - The Raw Ham's Lite Logger is now on {where}.")

    def _offer_shortcut(self):
        """Once, the first time it starts: offer a desktop shortcut."""
        self.d["shortcut_offered"] = True
        self._save()
        if IS_LINUX and os.path.exists(os.path.join(os.path.expanduser("~"), ".local", "share", "applications",
                                                    "rawham-lite-logger.desktop")):
            return  # the Linux installer already made one
        if messagebox.askyesno(APP, "Add a desktop shortcut with the logo, so you can start the logger with a "
                                    "double-click?\n\n(You can do this any time: Settings > Make desktop shortcut.)"):
            self.make_shortcut(asked=True)

    def _codes(self):
        return [c.strip().upper() for c in re.split(r"[,\s]+", self.d.get("pota_programs") or "US") if c.strip()]

    def _update_everything(self):
        self._run_ref_update(self._codes(), False)
        self.update_worked()

    # --- WSJT-X listener
    def _restart_wsjtx(self):
        self._wsjtx_stop = True
        if self.d.get("wsjtx_on"):
            self.root.after(1200, self._start_wsjtx)

    def _start_wsjtx(self):
        self._wsjtx_stop = False
        port = int(self.d.get("wsjtx_port") or 2237)
        group = (self.d.get("wsjtx_group") or "").strip()

        def work():
            import struct
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                # Listen on all addresses so plain 127.0.0.1 AND multicast both arrive (messages from other
                # computers are still dropped below unless that option is on).
                s.bind(("", port))
                s.settimeout(1.0)
            except OSError as e:
                self.ui_q.put((self._status, (f"WSJT-X: can't listen on UDP {port} ({e}). Another program may "
                                              "have it - try a multicast address.", False)))
                return
            # Join the shared (multicast) addresses WSJT-X / GridTracker / JTAlert use - yours, plus the usual
            # ones - on every interface, including loopback (WSJT-X "Outgoing interfaces: loopback").
            groups = [g for g in [group, "224.0.0.73", "224.0.0.1", "239.255.0.1"] if g]
            joined = []
            for g in dict.fromkeys(groups):
                for ifc in ["127.0.0.1", "0.0.0.0"] + sorted(local_addresses() - {"127.0.0.1"}):
                    try:
                        mreq = struct.pack("4s4s", socket.inet_aton(g), socket.inet_aton(ifc))
                        s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
                        if g not in joined:
                            joined.append(g)
                    except OSError:
                        pass
            self.ui_q.put((self._status, (f"Listening to WSJT-X on UDP {port} (127.0.0.1"
                                          + (", " + ", ".join(joined) if joined else "") + ").", True)))
            mine = local_addresses()
            remote_ok = bool(self.d.get("wsjtx_remote"))
            ignored = 0
            while not self._wsjtx_stop:
                try:
                    data, addr = s.recvfrom(65535)
                except socket.timeout:
                    continue
                except OSError:
                    break
                if not remote_ok and addr[0] not in mine and not addr[0].startswith("127."):
                    ignored += 1  # someone else on the network - not your WSJT-X
                    if ignored == 1:
                        self.ui_q.put((self._status, (f"Ignored a WSJT-X message from {addr[0]} (another "
                                                      "computer). See Settings > WSJT-X.", False)))
                    continue
                self._wsjtx_sock = s
                msg = wsjtx_parse(data)
                if msg and msg[0] == 12 and msg[2]:
                    self.ui_q.put((self._wsjtx_logged, (msg[2],)))
                elif msg and msg[0] in (1, 2):
                    dec = wsjtx_decode_fields(data)
                    if dec and dec[0] == 1 and dec[1].get("de_grid"):
                        self.ui_q.put((self._wsjtx_grid, (dec[1]["de_grid"],)))
                    if dec and getattr(self, "roster", None):
                        self.ui_q.put((self._roster_msg, (dec[0], dec[1], addr)))
            s.close()
        threading.Thread(target=work, daemon=True).start()

    def _wsjtx_logged(self, adif):
        refs = parse_refs(self.v_refs.get()) if self.activating() else []
        if self.activating() and (not refs or not all(p for p, _ in refs)):
            self._status("WSJT-X logged a QSO, but no activation reference is set - enter your park first "
                         "(or turn Activating off).", ok=False)
            return
        for r in parse_adif("<EOH>" + adif):
            call = r.get("CALL", "").strip().upper()
            if not call:
                continue
            date = r.get("QSO_DATE", utc_now().strftime("%Y%m%d"))
            tm = (r.get("TIME_ON", "") or utc_now().strftime("%H%M"))[:4]
            khz = parse_freq_khz(r.get("FREQ", "")) or parse_freq_khz(self.v_freq.get()) or 0
            mode = norm_mode(r.get("MODE"), r.get("SUBMODE")) or "FT8"
            if any(o["call"] == call and o["date"] == date and o["time"] == tm for o in self.d["qsos"]):
                continue  # already have it
            base = base_call(call)
            info = self.db.callbook_get(base)
            if not (info and info.get("name")):
                info = self.db.offline_get(base) or info or {}
            q = {"id": self.d["next_id"], "call": call, "date": date, "time": tm, "freq_khz": khz,
                 "band": (r.get("BAND", "") or band_for(khz)).lower(), "mode": mode,
                 "rst_s": r.get("RST_SENT", "") or default_rst(mode),
                 "rst_r": r.get("RST_RCVD", "") or default_rst(mode),
                 "state": (r.get("STATE", "") or info.get("state", "")).upper()[:3],
                 "country": clean_text(r.get("COUNTRY", "") or country_of(call) or info.get("country", ""), 60),
                 "their": [], "refs": [list(x) for x in refs],
                 "name": r.get("NAME", "") or info.get("name", ""), "src": "wsjtx",
                 "comment": clean_text(r.get("COMMENT", ""))}
            if not refs:
                q["my_grid"] = self._my_grid_now()
            # the call WSJT-X logged it under (W6J ...) - a special event call even if not set here
            sc = (r.get("STATION_CALLSIGN") or r.get("MY_CALL") or "").strip().upper()
            me = self.v_call.get().strip().upper()
            if self.event_call():
                q["station_call"] = self.event_call()
            elif sc and CALL_RE.match(sc) and me and base_call(sc) != base_call(me):
                q["station_call"] = sc
            if self.d.get("operator"):
                q["operator"] = self.d["operator"]
            g = (r.get("GRIDSQUARE") or "").strip()
            if _GRID_RE.match(g):
                q["grid"] = g
            self.d["next_id"] += 1
            self.d["qsos"].append(q)
            self.db.add_app_qso(q)
            self._save()
            self._refresh_table()
            self._after_log(q)
            self._status(f"WSJT-X: logged {call} {q['band']} {mode}" + (" into the activation." if refs else ".")
                         + (f"  (as {q['station_call']} - special event, not sent to QRZ/LOC)"
                            if q.get("station_call") else ""), ok=True)

    # --- edit a contact in the current activation
    def edit_selected(self):
        sel = self.tree.selection()
        if len(sel) != 1:
            if sel:
                messagebox.showinfo(APP, "Select just one contact to edit.")
            return
        q = next((x for x in self.d["qsos"] if str(x["id"]) == sel[0]), None)
        if not q:
            return
        fields = [("call", "Call", q["call"], None), ("name", "Name", q.get("name", ""), None),
                  ("date", "Date (YYYYMMDD)", q["date"], None), ("time", "Time UTC (HHMM)", q["time"], None),
                  ("freq", "Freq kHz", fmt_khz(q["freq_khz"]), None), ("mode", "Mode", q["mode"], MODES),
                  ("rst_s", "Sent", q["rst_s"], None), ("rst_r", "Rcvd", q["rst_r"], None),
                  ("state", "State", q.get("state", ""), None),
                  ("country", "Country", q.get("country", ""), None),
                  ("their", "P2P ref(s)" if q["refs"] else "Their park(s)", refs_text(q.get("their", [])), None),
                  (("refs", "My ref(s)", refs_text(q["refs"]), None) if q["refs"] else
                   ("my_grid", "My grid", q.get("my_grid", ""), None)),
                  ("comment", "Comment", q.get("comment", ""), None)]

        def apply(v):
            err = check_qso_fields(v)
            if err:
                return err
            khz = parse_freq_khz(v["freq"])
            was_sent = q.get("aclog_sent") or q.get("qrz_sent")
            q.update({"call": v["call"].upper(), "name": v["name"], "date": v["date"], "time": v["time"][:4],
                      "freq_khz": khz, "band": band_for(khz), "mode": v["mode"].upper(),
                      "rst_s": v["rst_s"], "rst_r": v["rst_r"], "state": v["state"].upper(),
                      "country": clean_text(v.get("country", ""), 60),
                      "their": [list(t) for t in parse_refs(v["their"])],
                      "comment": clean_text(v["comment"])})
            if "refs" in v:
                q["refs"] = [list(t) for t in parse_refs(v["refs"])]
            else:
                q["my_grid"] = fmt_grid(v["my_grid"])
            if was_sent and messagebox.askyesno(APP, "This contact was already sent to ACLog or QRZ.\n\n"
                                                     "Send the corrected copy again next time you click "
                                                     "Send to QRZ / Send to LOC?\n(QRZ's copy is replaced; "
                                                     "in ACLog, delete the old one by hand.)"):
                if q.pop("qrz_sent", None):
                    q["qrz_replace"] = True
                q.pop("aclog_sent", None)
            self.db.delete_app_qsos([q["id"]])
            self.db.add_app_qso(q)
            self._save()
            self._refresh_table()
            self._status(f"Saved changes to {q['call']}.", ok=True)
            return None
        QsoEditor(self, f"Edit QSO - {q['call']}", fields, apply)

    # --- past activations (exported ADIF files)
    def past_activations(self):
        folder = self._export_dir()
        if not folder:
            return
        files = sorted((f for f in os.listdir(folder) if f.lower().endswith((".adi", ".adif"))),
                       key=lambda f: os.path.getmtime(os.path.join(folder, f)), reverse=True)
        w = tk.Toplevel(self.root)
        w.title("Past activations")
        w.transient(self.root)
        w.geometry("620x420")
        w.columnconfigure(0, weight=1)
        w.rowconfigure(1, weight=1)
        ttk.Label(w, text=f"Exported activations in  {folder}", padding=(8, 8, 8, 4)).grid(row=0, column=0, sticky="w")
        tv = ttk.Treeview(w, columns=("file", "when", "n"), show="headings")
        for k, t, wd in (("file", "Activation file", 330), ("when", "Saved", 140), ("n", "QSOs", 60)):
            tv.heading(k, text=t)
            tv.column(k, width=wd, stretch=k == "file", anchor="w" if k == "file" else "center")
        for f in files:
            p = os.path.join(folder, f)
            try:
                n = len(read_adif_file(p)[1])
            except Exception:  # noqa: BLE001
                n = "?"
            tv.insert("", "end", iid=p, values=(f, datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M"), n))
        tv.grid(row=1, column=0, sticky="nsew", padx=8)
        if not files:
            ttk.Label(w, text="No exported activations yet - use Export ADIF first.", foreground=col("#777"),
                      padding=8).grid(row=2, column=0, sticky="w")

        def open_sel(*_):
            sel = tv.selection()
            if sel:
                self.open_past_file(sel[0])
        b = ttk.Frame(w, padding=8)
        b.grid(row=3, column=0, sticky="e")
        ttk.Button(b, text="Open folder", command=lambda: self._show_in_folder(
            os.path.join(folder, files[0]) if files else folder)).grid(row=0, column=0, padx=4)
        ttk.Button(b, text="Open", command=open_sel).grid(row=0, column=1, padx=4)
        ttk.Button(b, text="Close", command=w.destroy).grid(row=0, column=2)
        tv.bind("<Double-1>", open_sel)
        tv.bind("<Return>", open_sel)

    def open_past_file(self, path):
        try:
            header, recs = read_adif_file(path)
        except Exception as e:  # noqa: BLE001
            messagebox.showwarning(APP, f"Couldn't read {os.path.basename(path)}:\n{e}")
            return
        state = {"dirty": False}
        w = tk.Toplevel(self.root)
        w.title(os.path.basename(path))
        w.geometry("980x480")
        w.columnconfigure(0, weight=1)
        w.rowconfigure(0, weight=1)
        cols = [("n", "#", 36), ("time", "UTC", 110), ("call", "Call", 96), ("name", "Name", 130),
                ("rs", "Sent", 48), ("rr", "Rcvd", 48), ("st", "St", 40), ("their", "P2P", 110),
                ("freq", "Freq", 76), ("band", "Band", 50), ("mode", "Mode", 54), ("comment", "Comment", 120)]
        tv = ttk.Treeview(w, columns=[c[0] for c in cols], show="headings", selectmode="extended")
        for k, t, wd in cols:
            tv.heading(k, text=t)
            tv.column(k, width=wd, anchor="center", stretch=k in ("name", "their"))
        tv.grid(row=0, column=0, sticky="nsew", padx=8, pady=(8, 0))
        status = ttk.Label(w, text="Double-click a contact to edit it.", foreground=col("#777"), padding=(8, 4))
        status.grid(row=1, column=0, sticky="w")

        def their_of(r):
            return r.get("SIG_INFO") or r.get("SOTA_REF") or r.get("WWFF_REF") or ""

        def refresh():
            tv.delete(*tv.get_children())
            for i, r in enumerate(recs):
                d, t = r.get("QSO_DATE", ""), r.get("TIME_ON", "")
                mode = norm_mode(r.get("MODE"), r.get("SUBMODE"))
                khz = parse_freq_khz(r.get("FREQ", "")) or 0
                tv.insert("", "end", iid=str(i), values=(
                    i + 1, f"{d[:4]}-{d[4:6]}-{d[6:8]} {t[:2]}:{t[2:4]}", r.get("CALL", ""), r.get("NAME", ""),
                    r.get("RST_SENT", ""), r.get("RST_RCVD", ""), r.get("STATE", ""), their_of(r),
                    fmt_khz(khz) if khz else "", r.get("BAND", ""), mode, r.get("COMMENT", "")))
            w.title(("* " if state["dirty"] else "") + os.path.basename(path))

        def edit(*_):
            sel = tv.selection()
            if len(sel) != 1:
                return
            r = recs[int(sel[0])]
            their_prog = r.get("SIG", "") or ("SOTA" if r.get("SOTA_REF") else "WWFF" if r.get("WWFF_REF") else "")
            their_txt = ", ".join(x if guess_program(x) == their_prog else f"{their_prog}:{x}"
                                  for x in re.split(r"\s*,\s*", their_of(r)) if x) if their_of(r) else ""
            khz = parse_freq_khz(r.get("FREQ", "")) or 0
            fields = [("call", "Call", r.get("CALL", ""), None), ("name", "Name", r.get("NAME", ""), None),
                      ("date", "Date (YYYYMMDD)", r.get("QSO_DATE", ""), None),
                      ("time", "Time UTC (HHMM)", r.get("TIME_ON", "")[:4], None),
                      ("freq", "Freq kHz", fmt_khz(khz) if khz else "", None),
                      ("mode", "Mode", norm_mode(r.get("MODE"), r.get("SUBMODE")), MODES),
                      ("rst_s", "Sent", r.get("RST_SENT", ""), None), ("rst_r", "Rcvd", r.get("RST_RCVD", ""), None),
                      ("state", "State", r.get("STATE", ""), None), ("their", "P2P ref(s)", their_txt, None),
                      ("comment", "Comment", r.get("COMMENT", ""), None)]

            def apply(v):
                err = check_qso_fields(v)
                if err:
                    return err
                khz2 = parse_freq_khz(v["freq"])
                r["CALL"], r["NAME"], r["QSO_DATE"] = v["call"].upper(), v["name"], v["date"]
                old_t = r.get("TIME_ON", "")
                r["TIME_ON"] = v["time"] + (old_t[4:6] if len(v["time"]) == 4 and len(old_t) == 6 else "")
                r["FREQ"] = f"{khz2 / 1000:.5f}".rstrip("0")
                r["BAND"] = band_for(khz2)
                r.pop("SUBMODE", None)
                r["MODE"], sub = adif_mode_pair(v["mode"].upper())
                if sub:
                    r["SUBMODE"] = sub
                r["RST_SENT"], r["RST_RCVD"], r["STATE"] = v["rst_s"], v["rst_r"], v["state"].upper()
                if clean_text(v["comment"]):
                    r["COMMENT"] = clean_text(v["comment"])
                else:
                    r.pop("COMMENT", None)
                for k in ("SIG", "SIG_INFO", "SOTA_REF", "WWFF_REF"):
                    r.pop(k, None)
                tr = parse_refs(v["their"])
                if tr:
                    their_rec = next(parse_adif("<EOH>" + _their_fields([list(x) for x in tr], tr[0][0]) + "<EOR>"), {})
                    r.update(their_rec)
                state["dirty"] = True
                refresh()
                status.config(text="Changed - click Save file to keep it.", foreground=col("#b9770e"))
                return None
            QsoEditor(self, f"Edit QSO - {r.get('CALL', '')}", fields, apply)

        def delete():
            sel = sorted((int(i) for i in tv.selection()), reverse=True)
            if sel and messagebox.askyesno(APP, f"Delete {len(sel)} contact(s) from this file?", parent=w):
                for i in sel:
                    recs.pop(i)
                state["dirty"] = True
                refresh()

        def save_file():
            try:
                bak = path + ".bak"
                if not os.path.exists(bak):
                    import shutil
                    shutil.copyfile(path, bak)  # keep the original once, just in case
                write_adif_file(path, header, recs)
                state["dirty"] = False
                refresh()
                status.config(text="Saved.", foreground=col("#1e7d4f"))
            except OSError as e:
                messagebox.showwarning(APP, f"Couldn't save:\n{e}", parent=w)

        def records():
            if state["dirty"]:
                save_file()
            return [adif_record_text(r) for r in recs]

        def run(label, fn):
            status.config(text=f"{label}...", foreground=col("#555"))

            def work():
                msg, ok = fn()
                self.ui_q.put((lambda: status.config(text=msg, foreground=col("#1e7d4f") if ok else col("#c0392b"))
                               if w.winfo_exists() else None, ()))
            threading.Thread(target=work, daemon=True).start()

        def to_qrz():
            key = self.d.get("qrz_key", "")
            if not key:
                messagebox.showinfo(APP, "Add your QRZ Logbook API key first (Logbook connections).", parent=w)
                return
            recs_txt = records()
            if not messagebox.askyesno(APP, f"Send {len(recs_txt)} contact(s) to QRZ?\n"
                                            "Contacts already there are replaced with this copy.", parent=w):
                return

            def go():
                lb, ok_n, fails = QRZLogbook(key), 0, []
                for rec in recs_txt:
                    try:
                        res, why = lb.insert(rec, replace=True)
                    except Exception as e:  # noqa: BLE001
                        res, why = "fail", str(e)
                    if res in ("ok", "dupe"):
                        ok_n += 1
                    else:
                        fails.append(why)
                return (f"QRZ: {ok_n} uploaded" + (f", {len(fails)} failed ({fails[0]})" if fails else "") + "."), not fails
            run("Sending to QRZ", go)

        def to_loc():
            self._send_loc(records(), on_ok=None, ask=True, parent=w)

        def close():
            if state["dirty"] and messagebox.askyesno(APP, "Save your changes to this file first?", parent=w):
                save_file()
            w.destroy()

        b = ttk.Frame(w, padding=8)
        b.grid(row=2, column=0, sticky="ew")
        b.columnconfigure(3, weight=1)
        ttk.Button(b, text="Edit", command=edit).grid(row=0, column=0, padx=(0, 4))
        ttk.Button(b, text="Delete", command=delete).grid(row=0, column=1, padx=4)
        ttk.Button(b, text="Save file", command=save_file).grid(row=0, column=2, padx=4)
        ttk.Button(b, text="Send to QRZ", command=to_qrz).grid(row=0, column=4, padx=4)
        ttk.Button(b, text=f"Send to {self._loc_name()}" if self._loc_type() != "none" else "Send to LOC",
                   command=to_loc).grid(row=0, column=5, padx=4)
        def cont():
            if state["dirty"]:
                save_file()
            self.continue_past(path, recs, w)
        ttk.Button(b, text="Continue", command=cont).grid(row=0, column=6, padx=4)
        ttk.Button(b, text="Close", command=close).grid(row=0, column=7, padx=(4, 0))
        tv.bind("<Double-1>", edit)
        tv.bind("<Delete>", lambda e: delete())
        w.protocol("WM_DELETE_WINDOW", close)
        refresh()

    def continue_past(self, path, recs, win=None):
        """Past activations > Continue: that activation becomes the one on screen again - keep logging, Share, send."""
        qs = qsos_from_adif(recs, self.v_call.get().strip().upper())
        if not qs:
            messagebox.showinfo(APP, f"There are no contacts in {os.path.basename(path)}.", parent=win)
            return
        refs = []
        for q in qs:
            for r in q["refs"]:
                _add_ref(refs, list(r))
        if refs:  # a two-fer is saved as one file per park with the same contacts: bring every park back
            keys, folder = _adif_keys(recs), os.path.dirname(path)
            for f in os.listdir(folder):
                p = os.path.join(folder, f)
                if os.path.normcase(p) == os.path.normcase(path) or not f.lower().endswith((".adi", ".adif")):
                    continue
                try:
                    other = read_adif_file(p)[1]
                except Exception:  # noqa: BLE001
                    continue
                if other and _adif_keys(other) == keys:
                    for r in _my_refs(other[0]):
                        _add_ref(refs, r)
            for q in qs:
                if q["refs"]:
                    q["refs"] = [list(r) for r in refs]
        n = len(self.d["qsos"])
        if not messagebox.askyesno(APP, f"Continue this activation?\n\n{len(qs)} contacts"
                                        + (f" at {refs_text(refs)}" if refs else "")
                                        + " come back on screen, so you can keep logging, Share and send them."
                                        + (f"\n\nThe {n} contacts on screen now get saved to a file first "
                                           "(they'll be in Past activations)." if n else ""), parent=win):
            return
        if self.export_adif(quiet=True) is None:
            return  # couldn't save what's on screen - keep everything
        for q in qs:
            q["id"] = self.d["next_id"]
            self.d["next_id"] += 1
            self.db.drop_app_like(q)
            self.db.add_app_qso(q)
        self.d["qsos"] = qs
        self.last_spot_at = 0.0
        if refs:
            self.v_refs.set(refs_text(refs))
            if not self.activating():
                self.toggle_activating()
        self._save()
        self._refresh_table()
        self._update_counter()
        if win:
            win.destroy()
        self._status(f"Back in {refs_text(refs) or os.path.basename(path)} - {len(qs)} contacts. Keep going.", ok=True)

    # --- QRZ
    def _make_qrz(self):
        u, p = self.d.get("qrz_user", ""), self.d.get("qrz_pass", "")
        self.qrz = QRZ(u, p) if u and p else None
        self._qrz_warned = False

    def toggle_preload(self):
        if self._preloading:
            self._preloading = False
            return
        if not self.qrz:
            messagebox.showinfo(APP, "Set up your QRZ login first (Settings > QRZ).")
            return
        todo = [c for c in self.db.unique_calls() if not self.db.callbook_get(c)]
        if not todo:
            messagebox.showinfo(APP, "Everyone in your log already has a saved lookup.\n"
                                "(Sync ACLog first if you haven't.)")
            return
        mins = len(todo) // 60 + 1
        if not messagebox.askyesno(APP, f"Look up {len(todo):,} callsigns on QRZ and save them for offline use?\n\n"
                                        f"About {mins} minute(s) at one lookup per second. You can keep logging, "
                                        "and choose this menu item again to stop."):
            return
        self._preloading = True

        def work():
            done = 0
            for c in todo:
                if not self._preloading:
                    break
                if self._qrz_fetch(c, quiet=True):
                    done += 1
                if done % 10 == 0:
                    self.ui_q.put((self._status, (f"QRZ pre-load: {done:,} of {len(todo):,} saved...", True)))
                time.sleep(1.0)
            self._preloading = False
            self.ui_q.put((self._status, (f"QRZ pre-load finished: {done:,} callsigns saved for offline use.", True)))
        threading.Thread(target=work, daemon=True).start()

    def db_status(self):
        messagebox.showinfo(APP, f"Worked-before QSOs from ACLog/ADIF: {self.db.adif_count():,}\n"
                                 f"Offline callbook: " + (", ".join(f"{k} {v:,}" for k, v in self.db.offline_counts().items()) or "not downloaded") +
                                 (f" (updated {self.d['callbook_updated']})" if self.d.get("callbook_updated") else "") + "\n"
                                 f"Saved QRZ lookups: {self.db.callbook_count():,}\n"
                                 f"QRZ lookups: {'on' if self.qrz else 'off (not set up)'}\n\n"
                                 f"ACLog file: {self.d.get('aclog_path') or DEFAULT_ACLOG}\n"
                                 f"Database: {DB_FILE}")

    # ------------------------------------------------ CAT
    def toggle_cat(self):
        if self.cat and self.cat.running:
            self.cat.stop()
            self.cat = None
            self.cat_btn.config(text="Connect radio", style="TButton")
            self.cat_lbl.config(text="Radio disconnected", foreground=col("#777"))
            self._save()
            return
        port = self.v_port.get().strip()
        net = rig_type(self.d.get("rig_type") or "yaesu")[2] in ("flrig", "rigctld")
        if not port and not net:
            messagebox.showinfo(APP, f"Pick your radio and its {PORT_WORD} first (Settings > Radio).\n\n"
                                "FT-710 / FT-991A: use the 'Enhanced' port" +
                                (" (usually /dev/ttyUSB0)." if IS_LINUX else "."))
            self.settings_dialog("Radio")
            return
        if not net and not HAVE_SERIAL:
            messagebox.showinfo(APP, "Radio control over USB needs pyserial. In a " + ("Command Prompt" if IS_WIN else "terminal") + " run:\n\n"
                                + PYSERIAL_CMD)
            return
        self.cat = make_rig(self.d, port, int(self.v_baud.get() or 38400), self.v_drop.get(),
                            on_update=lambda k, m: self.ui_q.put((self._cat_update, (k, m))),
                            on_status=lambda t, ok: self.ui_q.put((self._cat_status, (t, ok))))
        self.cat.start()
        self.cat_btn.config(text="\u25a0 Disconnect radio", style="Disconnect.TButton")
        self.cat_lbl.config(text=f"Opening {self.cat.where}...", foreground=col("#777"))
        self._save()

    def _cat_status(self, text, ok):
        self.cat_lbl.config(text=text, foreground=col("#1e7d4f") if ok else col("#c0392b"))
        if not (self.cat and self.cat.running):
            self.cat_btn.config(text="Connect radio", style="TButton")

    def _cat_update(self, khz, mode):
        self.cat_khz = khz
        if self.root.focus_get() is not self.freq_entry:
            new = fmt_khz(khz)
            if self.v_freq.get() != new:
                self.v_freq.set(new)
        if mode:
            cur = self.v_mode.get()
            if mode == "DATA":
                mode = cur if cur in ("FT8", "FT4", "PSK31") else "FT8"
            if mode in ("FM", "DATA") and cur in DIGITAL_VOICE:
                mode = cur  # the radio says FM or DATA for digital voice: keep DMR, C4FM ...
            if mode != cur:
                self._set_rst_defaults(cur, mode)
                self.v_mode.set(mode)
                self.d["mode"] = mode

    def _push_to_radio(self):
        if not (self.cat and self.cat.running):
            return
        khz = parse_freq_khz(self.v_freq.get())
        if not khz:
            return
        self.cat.set(khz, self.v_mode.get())

    # ------------------------------------------------ spotting
    def spot(self, auto=False):
        if not auto:
            self._qrt = False  # spotting again after QRT: back on the air
        if not self.activating():
            if not auto:
                self.spot_cluster_dx()
            return
        st = self._check_station()
        if not st:
            return
        call, refs, khz = st
        wait = MIN_SPOT_GAP_SEC - (time.time() - self.last_spot_at)
        if wait > 0:
            if not auto:
                self._spot_msg(f"Just spotted - wait {int(wait)}s before spotting again.", ok=False)
            return
        self.last_spot_at = time.time()
        self._save()
        mode = self.v_mode.get()
        by_prog = {}
        for p, r in refs:
            by_prog.setdefault(p, []).append(r)

        manual = [p for p in by_prog if p in ("SOTA", "LLOTA")]
        if auto:  # automatic re-spots never pop up browser windows
            by_prog = {p: v for p, v in by_prog.items() if p not in manual}
            manual = []

        user_comment = self.v_comment.get().strip()

        def comment_for(prog, prog_refs):
            if user_comment:
                return user_comment
            others = [r for p, r in refs if r != prog_refs[0]]
            c = "QRV" if auto else "Activating"
            return f"{c} {' + '.join([prog_refs[0]] + others)}" if others else c

        jobs = []
        for prog, prog_refs in by_prog.items():
            ref, cmt = prog_refs[0], comment_for(prog, prog_refs)
            if prog == "POTA":
                jobs.append((prog, ref, lambda r=ref, c=cmt: spot_pota(call, khz, r, mode, c)))
            elif prog == "WWBOTA":
                jobs.append((prog, ref, lambda r=ref, c=cmt: spot_wwbota(call, khz, r, mode, c)))
            elif prog == "GMA":
                jobs.append((prog, ref, lambda r=ref, c=cmt: spot_cluster("cqgma.org", 7300, call, khz, r, mode, c)))
            elif prog == "WWFF":
                jobs.append((prog, ref, lambda r=ref, c=cmt: spot_cluster("spots.wwff.co", 7300, call, khz, r, mode, c)))

        if manual:
            text = f"{call} {fmt_khz(khz)} {mode} " + " ".join(r for p, r in refs if p in manual)
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            for p in manual:
                webbrowser.open(MANUAL_SPOT_PAGES[p])

        if not jobs:
            if manual:
                self._spot_msg(f"Opened the {' & '.join(manual)} spot page - spot details are on your clipboard (Ctrl+V).")
            return

        self.spot_btn.config(state="disabled", text="Spotting...")
        self._spot_msg("Sending spots...", ok=True)

        def work():
            results = [(prog, ref, fn()) for prog, ref, fn in jobs]
            self.ui_q.put((self._spot_done, (results, manual, khz, mode, call, refs)))

        threading.Thread(target=work, daemon=True).start()

    def _cluster_allowed(self):
        return bool(self.d.get("cluster_ok"))

    def spot_cluster_dx(self):
        """Not activating (special event, field day ...): spot on the DX cluster. You log in with your own call;
        the spot is for the special event call when there is one."""
        st = self._check_station()
        if not st:
            return
        me, _refs, khz = st
        dx = self.event_call() or me
        if not self._cluster_allowed():
            return
        wait = CLUSTER_GAP_SEC - (time.time() - self.last_spot_at)
        if wait > 0:
            self._spot_msg(f"DX cluster: one spot every 15 minutes - next in {int(wait // 60) + 1} min.", ok=False)
            return
        host, _, port = (self.d.get("cluster") or DEFAULT_CLUSTER).rpartition(":")
        mode = self.v_mode.get()
        comment = clean_text(self.v_comment.get(), 30) or "QRV"
        if not messagebox.askyesno(APP, f"Spot {dx} on {fmt_khz(khz)} {mode} on the DX cluster ({host})?\n\n"
                                        f"Comment: {comment}   (Settings > Spotting)\n\n"
                                        "Before you send - self-spotting on DX clusters is frowned on:\n"
                                        "  - never during a contest (it's against the rules)\n"
                                        "  - only for a special event or rare call, and rarely\n"
                                        "  - FT8 already shows on PSK Reporter; CW is picked up by the RBN\n\n"
                                        "Send this spot?", icon="warning"):
            return
        self.last_spot_at = time.time()
        self._save()
        self.spot_btn.config(state="disabled", text="Spotting...")
        self._spot_msg(f"Sending spot to {host}...", ok=True)

        def work():
            err = spot_cluster(host, int(port or 23), me, khz, "", mode, comment, dx_call=dx)
            self.ui_q.put((self._cluster_done, (err, dx, khz, mode, host)))
        threading.Thread(target=work, daemon=True).start()

    def _cluster_done(self, err, dx, khz, mode, host):
        self.spot_btn.config(state="normal", text="SPOT ME")
        if err:
            self.last_spot_at = 0.0
            self._spot_msg(f"DX cluster spot failed ({err}).", ok=False)
        else:
            self._spot_msg(f"Spotted {dx} {utc_now().strftime('%H:%MZ')} on {fmt_khz(khz)} {mode} via {host}.", ok=True)

    # ------------------------------------------------ spotting the station you're working (hunter / DX spots)
    def spot_them(self):
        """Spot the station in the Call box - at their park (P2P / Their park box) on that program's spot site,
        or as a DX spot on the cluster when there's no park. Sent as you."""
        them = self.q_call.get().strip().upper()
        me = self.v_call.get().strip().upper()
        if not CALL_RE.match(me):
            self._need_call()
            return
        if not CALL_RE.match(them):
            messagebox.showinfo(APP, "Type the call of the station you want to spot in the Call box first.")
            return
        if base_call(them) == base_call(me) or (self.event_call() and them == self.event_call()):
            messagebox.showinfo(APP, "That's you - use SPOT ME to spot yourself.")
            return
        khz = parse_freq_khz(self.v_freq.get())
        if not khz or not band_for(khz):
            messagebox.showwarning(APP, "Frequency isn't in a ham band (e.g. 14331 or 14.331).")
            return
        refs = parse_refs(self.q_their.get())
        if [r for p, r in refs if not p]:
            messagebox.showwarning(APP, "Which program is their reference? Put e.g. SOTA: or GMA: in front.")
            return
        last = getattr(self, "_spotted_them", {}).get(them, 0)
        if time.time() - last < MIN_SPOT_GAP_SEC:
            self._spot_msg(f"Just spotted {them} - wait a minute before spotting them again.", ok=False)
            return
        mode = self.v_mode.get()
        comment = clean_text(self.q_comment.get(), 40)
        where = ", ".join(f"{p} {r}" for p, r in refs) if refs else "DX cluster"
        if not messagebox.askyesno(APP, f"Spot {them} on {fmt_khz(khz)} {mode}  -  {where}?\n\n"
                                        f"Spotted by {base_call(me)}"
                                        + (f"\nComment: {comment}" if comment else "\n(Comment box is empty - "
                                           "type one first if you like, e.g. 'tnx 59 in OK')")):
            return
        self._spotted_them = getattr(self, "_spotted_them", {})
        self._spotted_them[them] = time.time()
        spotter = base_call(me)
        jobs, manual = [], []
        for prog, ref in refs:
            if prog == "POTA":
                jobs.append((prog, ref, lambda r=ref: spot_pota(them, khz, r, mode, comment, spotter=spotter)))
            elif prog == "WWBOTA":
                jobs.append((prog, ref, lambda r=ref: spot_wwbota(them, khz, r, mode, comment, spotter=spotter)))
            elif prog == "GMA":
                jobs.append((prog, ref, lambda r=ref: spot_cluster("cqgma.org", 7300, spotter, khz, r, mode, comment,
                                                                   dx_call=them)))
            elif prog == "WWFF":
                jobs.append((prog, ref, lambda r=ref: spot_cluster("spots.wwff.co", 7300, spotter, khz, r, mode,
                                                                   comment, dx_call=them)))
            elif prog in MANUAL_SPOT_PAGES:
                manual.append((prog, ref))
        if not refs:
            host, _, port = (self.d.get("cluster") or DEFAULT_CLUSTER).rpartition(":")
            jobs.append(("DX", host, lambda: spot_cluster(host, int(port or 23), spotter, khz, "", mode, comment,
                                                          dx_call=them)))
        if manual:
            text = f"{them} {fmt_khz(khz)} {mode} " + " ".join(r for p, r in manual) + (f" {comment}" if comment else "")
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            for p in dict.fromkeys(p for p, _ in manual):
                webbrowser.open(MANUAL_SPOT_PAGES[p])
        if not jobs:
            self._spot_msg(f"Opened the {' & '.join(dict.fromkeys(p for p, _ in manual))} spot page - "
                           "the spot is on your clipboard (Ctrl+V).", ok=True)
            return
        self.spot_them_btn.config(state="disabled", text="Spotting...")
        self._spot_msg(f"Spotting {them}...", ok=True)

        def work():
            results = [(p, r, fn()) for p, r, fn in jobs]
            self.ui_q.put((self._spot_them_done, (them, khz, mode, results, manual)))
        threading.Thread(target=work, daemon=True).start()

    def _spot_them_done(self, them, khz, mode, results, manual):
        self.spot_them_btn.config(state="normal", text="Spot them")
        ok = [f"{p} {r}" if p != "DX" else f"DX ({r})" for p, r, err in results if not err]
        bad = [f"{p} failed ({err})" for p, r, err in results if err]
        parts = []
        if ok:
            parts.append(f"Spotted {them} {utc_now().strftime('%H:%MZ')} on {fmt_khz(khz)} {mode}: " + ", ".join(ok))
        parts += bad
        if manual:
            parts.append(f"{' & '.join(dict.fromkeys(p for p, _ in manual))}: page opened, spot on clipboard")
        self._spot_msg("   |   ".join(parts), ok=not bad)
        if bad and not ok:
            self._spotted_them.pop(them, None)

    # ------------------------------------------------ QRT: tell hunters you're done
    def qrt(self):
        st = self._check_station()
        if not st:
            return
        call, refs, khz = st
        mode = self.v_mode.get()
        where = ", ".join(f"{p} {r}" for p, r in refs)
        comment = qrt_comment(self.v_comment.get())
        if not messagebox.askyesno(APP, f"Send a QRT spot for {where}?\n\nComment: {comment}\n\n"
                                        "Hunters will see you've gone off the air, "
                                        "and automatic re-spots stop. (SPOT ME puts you back on.)"):
            return
        self._qrt = True
        self.last_spot_at = time.time()
        by_prog = {}
        for p, r in refs:
            by_prog.setdefault(p, []).append(r)
        jobs, manual = [], []
        for prog, prog_refs in by_prog.items():
            ref = prog_refs[0]
            if prog == "POTA":
                for r in prog_refs:  # every park of a two-fer
                    jobs.append((prog, r, lambda r=r: spot_pota(call, khz, r, mode, comment)))
            elif prog == "WWBOTA":
                jobs.append((prog, ref, lambda: spot_wwbota(call, khz, ref, mode, comment)))
            elif prog == "GMA":
                jobs.append((prog, ref, lambda: spot_cluster("cqgma.org", 7300, call, khz, ref, mode, comment)))
            elif prog == "WWFF":
                jobs.append((prog, ref, lambda: spot_cluster("spots.wwff.co", 7300, call, khz, ref, mode, comment)))
            elif prog in MANUAL_SPOT_PAGES:
                manual.append(prog)
        if manual:
            self.root.clipboard_clear()
            self.root.clipboard_append(f"{call} {fmt_khz(khz)} {mode} "
                                       + " ".join(r for p, r in refs if p in manual) + " " + comment)
            for p in manual:
                webbrowser.open(MANUAL_SPOT_PAGES[p])
        if not jobs:
            self._spot_msg(f"Opened the {' & '.join(manual)} spot page - the QRT spot is on your clipboard (Ctrl+V).")
            return
        self.qrt_btn.config(state="disabled", text="Sending...")

        def work():
            results = [(p, r, fn()) for p, r, fn in jobs]
            self.ui_q.put((self._qrt_done, (results, manual)))
        threading.Thread(target=work, daemon=True).start()

    def _qrt_done(self, results, manual):
        self.qrt_btn.config(state="normal", text="QRT")
        ok = [f"{p} {r}" for p, r, err in results if not err]
        bad = [f"{p} failed ({err})" for p, r, err in results if err]
        parts = [f"QRT sent {utc_now().strftime('%H:%MZ')}: " + ", ".join(ok)] if ok else []
        parts += bad
        if manual:
            parts.append(f"{' & '.join(manual)}: page opened, QRT spot on clipboard")
        self._spot_msg("   |   ".join(parts) + ("   -   73!" if ok and not bad else ""), ok=not bad)

    def _spot_done(self, results, manual, khz, mode, call, refs):
        self.spot_btn.config(state="normal", text="SPOT ME")
        stamp = utc_now().strftime("%H:%MZ")
        ok = [f"{p} {r}" for p, r, err in results if not err]
        bad = [(p, r, err) for p, r, err in results if err]
        parts = []
        if ok:
            parts.append(f"Spotted {stamp} on {fmt_khz(khz)} {mode}: " + ", ".join(ok))
        for p, r, err in bad:
            parts.append(f"{p} failed ({err})")
        if manual:
            parts.append(f"{' & '.join(manual)}: page opened, details on clipboard")
        self._spot_msg("   |   ".join(parts), ok=not bad)
        # WWFF cluster refused?  Send them to the web page instead.
        wwff_fail = [r for p, r, err in bad if p == "WWFF"]
        if wwff_fail and "WWFF" not in manual:
            self.root.clipboard_clear()
            self.root.clipboard_append(f"{call} {fmt_khz(khz)} {mode} {wwff_fail[0]}")
            webbrowser.open(MANUAL_SPOT_PAGES["WWFF"])
        if bad and not ok:
            self.last_spot_at = 0.0

    # ------------------------------------------------ logging
    def log_qso(self):
        hunter = self.q_call.get().strip().upper()
        if not hunter:
            return
        if not CALL_RE.match(hunter) and not messagebox.askyesno(
                APP, f"'{hunter}' doesn't look like a callsign. Log it anyway?"):
            return
        st = self._check_station()
        if not st:
            return
        _me, refs, khz = st
        their = parse_refs(self.q_their.get())
        unknown = [r for p, r in their if not p]
        if unknown:
            if any(re.search(r"[A-Z]{3,}", u) and not re.search(r"\d", u) for u in unknown):
                self.find_ref("theirs")  # looks like a park name - search for it
            else:
                messagebox.showwarning(APP, f"Which program is their reference {', '.join(unknown)}?\n\n"
                                       "Put it in front, like  SOTA:W5/OK-001  or  GMA:DL/EW-017")
            return
        if base_call(hunter) != getattr(self, "_cur_base", ""):
            if self._lookup_job:
                self.root.after_cancel(self._lookup_job)
            self._do_lookup()
        now = utc_now()
        mode = self.v_mode.get()
        q = {"id": self.d["next_id"], "call": hunter, "date": now.strftime("%Y%m%d"),
             "time": now.strftime("%H%M"), "freq_khz": khz, "band": band_for(khz), "mode": mode,
             "rst_s": self.q_rs.get().strip() or default_rst(mode),
             "rst_r": self.q_rr.get().strip() or default_rst(mode),
             "state": self.q_state.get().strip().upper(),
             "country": clean_text(self.q_country.get(), 60),
             "their": [list(t) for t in their], "refs": [list(r) for r in refs],
             "name": self.q_name.get().strip(), "comment": clean_text(self.q_comment.get())}
        if not refs:
            q["my_grid"] = self._my_grid_now()
        if self.event_call():
            q["station_call"] = self.event_call()
        if self.d.get("operator"):
            q["operator"] = self.d["operator"]
        cb = self.db.callbook_get(base_call(hunter)) or {}
        if _GRID_RE.match(cb.get("grid") or ""):
            q["grid"] = cb["grid"]
        dupe = any(o["call"] == hunter and o["band"] == q["band"] and o["mode"] == mode
                   and o["date"] == q["date"] and o["refs"] == q["refs"] for o in self.d["qsos"])
        if dupe and not messagebox.askyesno(APP, f"{hunter} is already logged on {q['band']} {mode} "
                                                 "today. Log again?"):
            return
        self.d["next_id"] += 1
        self.d["qsos"].append(q)
        self.db.add_app_qso(q)
        self._save()
        self._refresh_table()
        self._clear_form()
        self._forward_qso(q)
        self._after_log(q)
        self._hide_photo()
        if self.v_auto.get() and self.activating() and not getattr(self, "_qrt", False):
            self.spot(auto=True)

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        calls = [self.tree.set(i, "call") for i in sel]
        if not messagebox.askyesno(APP, f"Delete {len(sel)} QSO(s)?\n{', '.join(calls)}"):
            return
        ids = {int(i) for i in sel}
        self.d["qsos"] = [q for q in self.d["qsos"] if q["id"] not in ids]
        self.db.delete_app_qsos(ids)
        self._save()
        self._refresh_table()

    def export_adif(self, quiet=False):
        """quiet = the automatic save before New activation / Continue: no pop-up, the folder doesn't open, and it
        never writes over a file that has contacts this save doesn't. Returns the files written, None if it failed."""
        qsos = self.d["qsos"]
        if not qsos:
            if quiet:
                return []
            messagebox.showinfo(APP, "No QSOs to export yet.")
            return
        call = self.v_call.get().strip().upper()
        if not CALL_RE.match(call):
            messagebox.showwarning(APP, "Enter your callsign in 'My call' first.")
            return
        folder = self._export_dir()
        if not folder:
            return
        refs = []
        for q in qsos:
            for p, r in q["refs"]:
                if [p, r] not in refs:
                    refs.append([p, r])
        groups = []
        for sc in dict.fromkeys(self._calls_for(q)[0] for q in qsos):  # your call, and any special event call
            mine_sc = [q for q in qsos if self._calls_for(q)[0] == sc]
            op = self._calls_for(mine_sc[0])[1]
            for prog, ref in refs:
                g = [q for q in mine_sc if [prog, ref] in q["refs"]]
                if g:
                    groups.append((sc, op, prog, ref, g))
            for day in sorted({q["date"] for q in mine_sc if not q["refs"]}):  # not activating: one log per day
                groups.append((sc, op, "", "", [q for q in mine_sc if not q["refs"] and q["date"] == day]))
        written, paths = [], []
        for sc, op, prog, ref, mine in groups:
            name = adif_filename(sc, prog, ref, mine[0]["date"])
            if prog:
                text = build_adif(mine, sc, prog, ref, self._grid_for(prog, ref), op)
            else:  # each contact keeps the grid it was made from
                text = build_adif([], sc, "", "") + "".join(
                    build_adif([q], sc, "", "", self._where(q)[2], op).split("<EOH>\n\n", 1)[1] for q in mine)
            path = self._safe_path(folder, name, text) if quiet else os.path.join(folder, name)
            name = os.path.basename(path)
            try:
                with open(path, "w", encoding="utf-8", newline="\n") as fh:
                    fh.write(text)
            except OSError as e:
                messagebox.showwarning(APP, f"Couldn't save {name}:\n{e}\n\n"
                                            "Choose another folder: Settings > Offline data > Choose ADIF export folder.")
                return
            paths.append(path)
            written.append(f"{prog or 'Log':7} {name}   ({len(mine)} QSOs)")
        if quiet:
            self._status("Saved a copy: " + ", ".join(os.path.basename(p) for p in paths), ok=True)
            return paths
        self._show_in_folder(paths[0])
        self._last_export = paths
        messagebox.showinfo(APP, f"Saved in  {folder}\n\n" + "\n".join(written) +
                            "\n\nThe folder is open - drag each file onto the upload page:\n"
                            "   POTA - pota.app  > My Logs (Upload)\n"
                            "   SOTA - sotadata.org.uk  > Upload log\n"
                            "   WWFF - logsearch / your national WWFF coordinator\n"
                            "   GMA, WWBOTA, LLOTA - their websites")
        return paths

    @staticmethod
    def _safe_path(folder, name, text):
        """The usual file name - unless that file has contacts this save doesn't (two activations at the same park
        the same day): then name-2.adi, -3 ..."""
        path = os.path.join(folder, name)
        if not os.path.exists(path):
            return path
        try:
            if _adif_keys(list(parse_adif(text))) >= _adif_keys(read_adif_file(path)[1]):
                return path
        except Exception:  # noqa: BLE001
            pass
        stem, i = name[:-4], 2
        while os.path.exists(os.path.join(folder, f"{stem}-{i}.adi")):
            i += 1
        return os.path.join(folder, f"{stem}-{i}.adi")

    def _export_dir(self):
        folder = self.d.get("export_dir") or os.path.join(os.path.expanduser("~"), "Documents",
                                                          "Raw Ham Logger ADIF")
        try:
            os.makedirs(folder, exist_ok=True)
            return folder
        except OSError:
            return self.choose_export_dir()

    def choose_export_dir(self):
        folder = filedialog.askdirectory(title="Where should ADIF exports be saved?",
                                         initialdir=self.d.get("export_dir") or os.path.expanduser("~"))
        if folder:
            self.d["export_dir"] = folder
            self._save()
            self._status(f"ADIF files will be saved in {folder}", ok=True)
        return folder or None

    def _show_in_folder(self, path):
        try:
            if os.name == "nt":
                import subprocess
                subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            elif sys.platform == "darwin":
                import subprocess
                subprocess.Popen(["open", "-R", path])
            else:
                import subprocess
                subprocess.Popen(["xdg-open", os.path.dirname(path) or "."],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:  # noqa: BLE001
            pass

    def new_activation(self):
        n = len(self.d["qsos"])
        if n:
            if not messagebox.askyesno(APP, f"Start a new activation?\n\nYour {n} contacts get saved to a file first. "
                                            "Get them back any time: Past activations > open it > Continue."):
                return
            if self.export_adif(quiet=True) is None and not messagebox.askyesno(
                    APP, f"Couldn't save a copy. Clear the {n} contacts anyway?"):
                return
        self.d["qsos"] = []
        self.last_spot_at = 0.0
        self._qrt = False
        self._spot_msg("Comment is optional - leave blank for an automatic one.")
        self.spot_lbl.config(foreground=col("#777"))
        self._save()
        self._refresh_table()

    def close(self):
        try:
            self._save()
        finally:
            self._preloading = False
            self._wsjtx_stop = True
            if self.cat:
                self.cat.stop()
            self.db.close()
            self.root.destroy()


def set_icon(root):
    """Use logo.ico / logo.png next to this file as the window and taskbar icon."""
    ico = os.path.join(RES_DIR, "logo.ico")
    png = os.path.join(RES_DIR, "logo.png")
    try:
        if os.name == "nt" and os.path.exists(ico):
            root.iconbitmap(default=ico)
            return
        if os.path.exists(png):
            img = tk.PhotoImage(file=png)
            root.iconphoto(True, img)
            root._icon_img = img  # keep a reference
    except tk.TclError:
        pass


def main():
    if os.name == "nt":  # crisp text on high-DPI laptop screens
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
            # own taskbar button (and icon) instead of the generic Python one
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("RawHams.LiteLogger")
        except Exception:  # noqa: BLE001
            pass
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    root = tk.Tk()
    set_icon(root)
    app = OtaLite(root)
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()


def selftest():
    """Used by the build: start the program with a throw-away log, check its parts load, close it.
    Exit code 0 = all good."""
    global DATA_FILE, DB_FILE
    import tempfile
    tmp = tempfile.mkdtemp(prefix="rawham-selftest-")
    DATA_FILE, DB_FILE = os.path.join(tmp, "d.json"), os.path.join(tmp, "d.db")
    with open(DATA_FILE, "w", encoding="utf-8") as fh:
        json.dump({"callsign": "N0CALL", "grid": "EM15", "worked_auto": False, "shortcut_offered": True}, fh)
    problems = []
    if not HAVE_SERIAL:
        problems.append("pyserial missing")
    try:
        import access_parser  # noqa: F401
    except ImportError:
        problems.append("access-parser missing")
    if not os.path.exists(os.path.join(RES_DIR, "logo.png")):
        problems.append("logo missing")
    try:
        root = tk.Tk()
        set_icon(root)
        app = OtaLite(root)
        app.v_refs.set("US-0001")
        app.q_call.set("W1AW")
        app.log_qso()
        if not app.d["qsos"]:
            problems.append("couldn't log a QSO")
        root.after(1200, app.close)
        root.mainloop()
    except Exception as e:  # noqa: BLE001
        problems.append(f"start-up failed: {e}")
    with open(os.path.join(tmp, "result.txt"), "w", encoding="utf-8") as fh:
        fh.write("; ".join(problems) or "OK")
    print("; ".join(problems) or "OK", tmp)
    return 1 if problems else 0


if __name__ == "__main__":
    main()
